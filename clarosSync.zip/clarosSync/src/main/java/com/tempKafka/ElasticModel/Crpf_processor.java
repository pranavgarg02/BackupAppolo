package com.tempKafka.ElasticModel;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.tempKafka.MySqlRepo.deploymentRepository.ArmsEquipmentRepository;
import com.tempKafka.modelMySql.deployment.Dep_um_food_details;
import com.tempKafka.modelMySql.deployment.Deploymentdetails;

public class Crpf_processor {
	
	
	private List<DeploymentList> dlslist;
	
	@Autowired
	ArmsEquipmentRepository armsrepo;
	
	private CRPF_Deployment crpfdeploy = new CRPF_Deployment();
	private Crpf_processor cp1 = new Crpf_processor();
	
	public CRPF_Deployment getCrpfdeploy() {
		return crpfdeploy;
	}


	public void setCrpfdeploy(CRPF_Deployment crpfdeploy) {
		this.crpfdeploy = crpfdeploy;
	}

	
public Crpf_processor() {
	super();
	// TODO Auto-generated constructor stub
}


public Crpf_processor setDepFoodDetails(Crpf_processor cp, String foodCategory, String recOfficerName, String recOfficerUnit,
		String recOfficerRank) {
	this.cp1=cp;
	this.cp1.crpfdeploy.setFood_category(foodCategory);
	this.cp1.crpfdeploy.setRec_officer_name(recOfficerRank);
	this.cp1.crpfdeploy.setRec_officer_rank(recOfficerRank);
	this.cp1.crpfdeploy.setRec_officer_unit(recOfficerUnit);
	return this.cp1;
}

public Crpf_processor setDeploymentdetails(String coycommander, String depStatus, String coy) {
	// TODO Auto-generated method stub
	this.cp1.crpfdeploy.setCoy_commander(coycommander);
	this.cp1.crpfdeploy.setDepStatus(depStatus);
	this.cp1.crpfdeploy.setCoy(coy);
	return this.cp1;
}


public void setPersonnelDetails(String personnelName, String personnelrank, String unit) {
	// TODO Auto-generated method stub
	this.cp1.crpfdeploy.setPersonnel_name(personnelName);
	this.cp1.crpfdeploy.setPersonnel_rank(personnelrank);
	this.cp1.crpfdeploy.setUnit(unit);
}

public void setArmsDetails(String armsEqptCategory, String armsEqptType) {
	// TODO Auto-generated method stub
	this.cp1.crpfdeploy.setEvent_equipment_category(armsEqptCategory);
	this.cp1.crpfdeploy.setEvent_equipment_type(armsEqptType);
}


public List<DeploymentList> getDlslist() {
	return dlslist;
}


public void setDlslist(List<DeploymentList> dlslist) {
	this.dlslist = dlslist;
}

}
