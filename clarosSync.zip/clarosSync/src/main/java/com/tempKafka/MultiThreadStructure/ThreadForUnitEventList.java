package com.tempKafka.MultiThreadStructure;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.tempKafka.ElasticModel.Crpf_processor;
import com.tempKafka.MySqlRepo.PersonnelRepo;
import com.tempKafka.modelMySql.deployment.Event_arms_equipment;
import com.tempKafka.modelMySql.deployment.Personnel;
import com.tempKafka.modelMySql.deployment.eventUnitInvolved;

public class ThreadForUnitEventList extends Thread {
	@Autowired
	private PersonnelRepo personnelrepo;
	private List<eventUnitInvolved> eventunitlist;
	private List<Event_arms_equipment> li2;
	private  Crpf_processor cprefrenced;
	
	public ThreadForUnitEventList(List<Event_arms_equipment> li2,List<eventUnitInvolved> eventunitlist, Crpf_processor cprefrenced) {
		this.eventunitlist = eventunitlist;
		this.li2 = li2;
		this.cprefrenced =  cprefrenced;
	}


	@Override
	public void run() {
		try {
			System.out.println("Unit Event List " + Thread.currentThread().getId() + " " + Thread.currentThread().getName());
			Set<String> units = eventunitlist.stream().map(eventUnitInvolved::getUnit).collect(Collectors.toSet());
			List<Personnel> allPersonnel = personnelrepo.findByUnitIn(units);
			Map<String, List<Personnel>> personnelMap = allPersonnel.stream().collect(Collectors.groupingBy(Personnel::getUnit));
			for (eventUnitInvolved eventunit : eventunitlist) {
			    List<Personnel> personnelList = personnelMap.get(eventunit.getUnit());
			    if (personnelList != null) {
			    	
			    }
		}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
