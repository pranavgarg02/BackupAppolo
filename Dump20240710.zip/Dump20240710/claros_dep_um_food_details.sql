-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 3.7.32.64    Database: claros
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dep_um_food_details`
--

DROP TABLE IF EXISTS `dep_um_food_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dep_um_food_details` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `dep_id` varchar(200) NOT NULL,
  `sub_dep_id` varchar(200) NOT NULL,
  `row_id` varchar(200) NOT NULL,
  `proposed_food_halt_irctc` varchar(200) NOT NULL,
  `food_category` varchar(200) NOT NULL,
  `actual_halt_food_was_provided` varchar(200) NOT NULL,
  `no_of_food_packets_demanded` varchar(200) NOT NULL,
  `reports` text NOT NULL,
  `remark` longtext NOT NULL,
  `rec_officer_force_no` varchar(200) NOT NULL,
  `rec_officer_name` varchar(200) NOT NULL,
  `rec_officer_rank` varchar(200) NOT NULL,
  `rec_officer_unit` varchar(200) NOT NULL,
  `rec_officer_phone` varchar(200) NOT NULL,
  `rec_officer_email` varchar(200) NOT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dep_um_food_details`
--

LOCK TABLES `dep_um_food_details` WRITE;
/*!40000 ALTER TABLE `dep_um_food_details` DISABLE KEYS */;
INSERT INTO `dep_um_food_details` VALUES (1,'DEP#001','SDEP-000DEP#001','rowid@-1','proposed_food_halt_irctc-TJ6396','Food Category FC#: C','actual_halt_food_was_provided-MV6978','230','','Remarks-R12deAfSx','RF-8779','Sg. Luxedo Frixido','Director General','Un-F','7734145506','rec_Director General91@example.com'),(3,'DEP#003','SDEP-000DEP#003','rowid@-3','proposed_food_halt_irctc-UN3336','Food Category FC#: E','actual_halt_food_was_provided-YM5481','90','','Remarks-R12deAfSx','RF-1912','Rg. Minsube Frixido','Deputy Inspector General','Un-J','7592315769','rec_Director General42@example.com'),(4,'DEP#004','SDEP-000DEP#004','rowid@-4','proposed_food_halt_irctc-MS2315','Food Category FC#: A','actual_halt_food_was_provided-OZ3004','20','','Remarks-R12deAfSx','RF-2634','Fg. Luxedo Extorio','Deputy Commandant','Un-A','7485463873','rec_Director General21@example.com'),(5,'DEP#005','SDEP-000DEP#005','rowid@-5','proposed_food_halt_irctc-PO1998','Food Category FC#: C','actual_halt_food_was_provided-XZ2707','250','','Remarks-R12deAfSx','RF-1057','Sg. Luxedo Extorio','Inspector General','Un-I','8185713032','rec_Director General111@example.com'),(7,'DEP#007','SDEP-000DEP#007','rowid@-7','proposed_food_halt_irctc-CV9275','Food Category FC#: B','actual_halt_food_was_provided-OO1827','110','','Remarks-R12deAfSx','RF-8402','Rg. Luxedo Extorio','Deputy Commandant','Un-A','1142457856','rec_Director General64@example.com'),(9,'DEP#009','SDEP-000DEP#009','rowid@-9','proposed_food_halt_irctc-IR4541','Food Category FC#: E','actual_halt_food_was_provided-NT3270','270','','Remarks-R12deAfSx','RF-9838','Sg. Mannhaur Extorio','Sub Inspector','Un-D','2549854653','rec_Director General15@example.com'),(10,'DEP#0010','SDEP-000DEP#0010','rowid@-10','proposed_food_halt_irctc-EQ6118','Food Category FC#: A','actual_halt_food_was_provided-HK2583','200','','Remarks-R12deAfSx','RF-7054','Sg. Luxedo Alex','Deputy Inspector General','Un-J','7464799590','rec_Director General101@example.com'),(13,'DEP#0013','SDEP-000DEP#0013','rowid@-13','proposed_food_halt_irctc-RV1880','Food Category FC#: A','actual_halt_food_was_provided-WE3314','290','','Remarks-R12deAfSx','RF-8222','Fg. Samson Frixido','Director General','Un-G','8574183206','rec_Director General32@example.com'),(18,'DEP#0018','SDEP-000DEP#0018','rowid@-18','proposed_food_halt_irctc-CY4832','Food Category FC#: D','actual_halt_food_was_provided-IQ2719','240','','Remarks-R12deAfSx','RF-1630','Sg. Luxedo Alex','Director General','Un-G','7203775273','rec_Director General89@example.com'),(22,'DEP#0022','SDEP-000DEP#0022','rowid@-2','proposed_food_halt_irctc-VT3993','Food Category FC#: A','actual_halt_food_was_provided-YM6706','260','','Remarks-R12deAfSx','RF-7477','Hg. Minsube Lubia','Special Director General','Un-E','8905378155','rec_Director General103@example.com'),(30,'DEP#0030','SDEP-000DEP#0030','rowid@-10','proposed_food_halt_irctc-FL6777','Food Category FC#: C','actual_halt_food_was_provided-KK8181','0','','Remarks-R12deAfSx','RF-8138','Sg. Samson Extorio','Director General','Un-F','2703297373','rec_Director General155@example.com'),(41,'DEP#0041','SDEP-000DEP#0041','rowid@-1','proposed_food_halt_irctc-TL9542','Food Category FC#: A','actual_halt_food_was_provided-GZ2912','130','','Remarks-R12deAfSx','RF-1758','Hg. Samson ferrosko','Sub Inspector','Un-D','4744989678','rec_Director General98@example.com'),(44,'DEP#0044','SDEP-000DEP#0044','rowid@-4','proposed_food_halt_irctc-OK3404','Food Category FC#: D','actual_halt_food_was_provided-XB5781','220','','Remarks-R12deAfSx','RF-5800','Fg. Minsube Frixido','Additional Director General','Un-H','5867933105','rec_Director General171@example.com');
/*!40000 ALTER TABLE `dep_um_food_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-10 15:27:30
