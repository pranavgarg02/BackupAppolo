package com.tempKafka.modelMySql.Events;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "eventied")
public class Eventied {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
     int sno; // AI PK means Auto Increment Primary Key

    @Column(name = "event_id")
     String eventId;

    @Column(name = "ied_id")
     String iedId;

    @Column(name = "ied_state")
     String iedState;

    @Column(name = "ied_district")
     String iedDistrict;

    @Column(name = "ied_police_station")
     String iedPoliceStation;

    @Column(name = "ied_location")
     String iedLocation;

    @Column(name = "ied_latitude")
     String iedLatitude;

    @Column(name = "ied_longitude")
     String iedLongitude;

    @Column(name = "ied_status")
     String iedStatus;

    @Column(name = "ied_date_time")
     String iedDateTime;

    @Column(name = "ied_position")
     String iedPosition;

    @Column(name = "depth_of_burial")
     String depthOfBurial;

    @Column(name = "pattern_of_placement")
     String patternOfPlacement;

    @Column(name = "type_of_terrain")
     String typeOfTerrain;

    @Column(name = "type_of_explosive")
     String typeOfExplosive;

    @Column(name = "type_of_alignment")
     String typeOfAlignment;

    @Column(name = "mechanism_of_ied")
     String mechanismOfIed;

    @Column(name = "length_of_wire")
     String lengthOfWire;

    @Column(name = "device_used_rx")
     String deviceUsedRx;

    @Column(name = "device_used_tx")
     String deviceUsedTx;

    @Column(name = "no_of_ied")
     String noOfIed;

    @Column(name = "quantity_of_ied")
     String quantityOfIed;

    @Column(name = "type_of_detonator")
     String typeOfDetonator;

    @Column(name = "length_ied_wire")
     String lengthIedWire;

    @Column(name = "distance_from_camp")
     String distanceFromCamp;

    @Column(name = "container_of_ied")
     String containerOfIed;

    @Column(name = "shrapnels_used")
     String shrapnelsUsed;

    @Column(name = "ied_recovered_from")
     String iedRecoveredFrom;

    @Column(name = "mode_disposal_of_ied")
     String modeDisposalOfIed;

    @Column(name = "ied_mode_of_detection")
     String iedModeOfDetection;

    @Column(name = "ied_residual_item")
     String iedResidualItem;

    @Column(name = "dimensions_of_creator")
     String dimensionsOfCreator;

    @Column(name = "aiming_point_used")
     String aimingPointUsed;

    @Column(name = "distance_from_ied")
     String distanceFromIed;

    @Column(name = "no_of_spikes")
     String noOfSpikes;

    @Column(name = "distance_from_camp_spike")
     String distanceFromCampSpike;

    @Column(name = "ied_details")
     String iedDetails;

    @Column(name = "desc_of_creator")
     String descOfCreator;

    @Column(name = "desc_of_spikes")
     String descOfSpikes;

    @Column(name = "created_by")
     String createdBy;

    @Column(name = "created_at")
     String createdAt;

    @Column(name = "updated_by")
     String updatedBy;

    @Column(name = "updated_at")
     String updatedAt;

	public Eventied() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Eventied [sno=" + sno + ", eventId=" + eventId + ", iedId=" + iedId + ", iedState=" + iedState
				+ ", iedDistrict=" + iedDistrict + ", iedPoliceStation=" + iedPoliceStation + ", iedLocation="
				+ iedLocation + ", iedLatitude=" + iedLatitude + ", iedLongitude=" + iedLongitude + ", iedStatus="
				+ iedStatus + ", iedDateTime=" + iedDateTime + ", iedPosition=" + iedPosition + ", depthOfBurial="
				+ depthOfBurial + ", patternOfPlacement=" + patternOfPlacement + ", typeOfTerrain=" + typeOfTerrain
				+ ", typeOfExplosive=" + typeOfExplosive + ", typeOfAlignment=" + typeOfAlignment + ", mechanismOfIed="
				+ mechanismOfIed + ", lengthOfWire=" + lengthOfWire + ", deviceUsedRx=" + deviceUsedRx
				+ ", deviceUsedTx=" + deviceUsedTx + ", noOfIed=" + noOfIed + ", quantityOfIed=" + quantityOfIed
				+ ", typeOfDetonator=" + typeOfDetonator + ", lengthIedWire=" + lengthIedWire + ", distanceFromCamp="
				+ distanceFromCamp + ", containerOfIed=" + containerOfIed + ", shrapnelsUsed=" + shrapnelsUsed
				+ ", iedRecoveredFrom=" + iedRecoveredFrom + ", modeDisposalOfIed=" + modeDisposalOfIed
				+ ", iedModeOfDetection=" + iedModeOfDetection + ", iedResidualItem=" + iedResidualItem
				+ ", dimensionsOfCreator=" + dimensionsOfCreator + ", aimingPointUsed=" + aimingPointUsed
				+ ", distanceFromIed=" + distanceFromIed + ", noOfSpikes=" + noOfSpikes + ", distanceFromCampSpike="
				+ distanceFromCampSpike + ", iedDetails=" + iedDetails + ", descOfCreator=" + descOfCreator
				+ ", descOfSpikes=" + descOfSpikes + ", createdBy=" + createdBy + ", createdAt=" + createdAt
				+ ", updatedBy=" + updatedBy + ", updatedAt=" + updatedAt + "]";
	}

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getIedId() {
		return iedId;
	}

	public void setIedId(String iedId) {
		this.iedId = iedId;
	}

	public String getIedState() {
		return iedState;
	}

	public void setIedState(String iedState) {
		this.iedState = iedState;
	}

	public String getIedDistrict() {
		return iedDistrict;
	}

	public void setIedDistrict(String iedDistrict) {
		this.iedDistrict = iedDistrict;
	}

	public String getIedPoliceStation() {
		return iedPoliceStation;
	}

	public void setIedPoliceStation(String iedPoliceStation) {
		this.iedPoliceStation = iedPoliceStation;
	}

	public String getIedLocation() {
		return iedLocation;
	}

	public void setIedLocation(String iedLocation) {
		this.iedLocation = iedLocation;
	}

	public String getIedLatitude() {
		return iedLatitude;
	}

	public void setIedLatitude(String iedLatitude) {
		this.iedLatitude = iedLatitude;
	}

	public String getIedLongitude() {
		return iedLongitude;
	}

	public void setIedLongitude(String iedLongitude) {
		this.iedLongitude = iedLongitude;
	}

	public String getIedStatus() {
		return iedStatus;
	}

	public void setIedStatus(String iedStatus) {
		this.iedStatus = iedStatus;
	}

	public String getIedDateTime() {
		return iedDateTime;
	}

	public void setIedDateTime(String iedDateTime) {
		this.iedDateTime = iedDateTime;
	}

	public String getIedPosition() {
		return iedPosition;
	}

	public void setIedPosition(String iedPosition) {
		this.iedPosition = iedPosition;
	}

	public String getDepthOfBurial() {
		return depthOfBurial;
	}

	public void setDepthOfBurial(String depthOfBurial) {
		this.depthOfBurial = depthOfBurial;
	}

	public String getPatternOfPlacement() {
		return patternOfPlacement;
	}

	public void setPatternOfPlacement(String patternOfPlacement) {
		this.patternOfPlacement = patternOfPlacement;
	}

	public String getTypeOfTerrain() {
		return typeOfTerrain;
	}

	public void setTypeOfTerrain(String typeOfTerrain) {
		this.typeOfTerrain = typeOfTerrain;
	}

	public String getTypeOfExplosive() {
		return typeOfExplosive;
	}

	public void setTypeOfExplosive(String typeOfExplosive) {
		this.typeOfExplosive = typeOfExplosive;
	}

	public String getTypeOfAlignment() {
		return typeOfAlignment;
	}

	public void setTypeOfAlignment(String typeOfAlignment) {
		this.typeOfAlignment = typeOfAlignment;
	}

	public String getMechanismOfIed() {
		return mechanismOfIed;
	}

	public void setMechanismOfIed(String mechanismOfIed) {
		this.mechanismOfIed = mechanismOfIed;
	}

	public String getLengthOfWire() {
		return lengthOfWire;
	}

	public void setLengthOfWire(String lengthOfWire) {
		this.lengthOfWire = lengthOfWire;
	}

	public String getDeviceUsedRx() {
		return deviceUsedRx;
	}

	public void setDeviceUsedRx(String deviceUsedRx) {
		this.deviceUsedRx = deviceUsedRx;
	}

	public String getDeviceUsedTx() {
		return deviceUsedTx;
	}

	public void setDeviceUsedTx(String deviceUsedTx) {
		this.deviceUsedTx = deviceUsedTx;
	}

	public String getNoOfIed() {
		return noOfIed;
	}

	public void setNoOfIed(String noOfIed) {
		this.noOfIed = noOfIed;
	}

	public String getQuantityOfIed() {
		return quantityOfIed;
	}

	public void setQuantityOfIed(String quantityOfIed) {
		this.quantityOfIed = quantityOfIed;
	}

	public String getTypeOfDetonator() {
		return typeOfDetonator;
	}

	public void setTypeOfDetonator(String typeOfDetonator) {
		this.typeOfDetonator = typeOfDetonator;
	}

	public String getLengthIedWire() {
		return lengthIedWire;
	}

	public void setLengthIedWire(String lengthIedWire) {
		this.lengthIedWire = lengthIedWire;
	}

	public String getDistanceFromCamp() {
		return distanceFromCamp;
	}

	public void setDistanceFromCamp(String distanceFromCamp) {
		this.distanceFromCamp = distanceFromCamp;
	}

	public String getContainerOfIed() {
		return containerOfIed;
	}

	public void setContainerOfIed(String containerOfIed) {
		this.containerOfIed = containerOfIed;
	}

	public String getShrapnelsUsed() {
		return shrapnelsUsed;
	}

	public void setShrapnelsUsed(String shrapnelsUsed) {
		this.shrapnelsUsed = shrapnelsUsed;
	}

	public String getIedRecoveredFrom() {
		return iedRecoveredFrom;
	}

	public void setIedRecoveredFrom(String iedRecoveredFrom) {
		this.iedRecoveredFrom = iedRecoveredFrom;
	}

	public String getModeDisposalOfIed() {
		return modeDisposalOfIed;
	}

	public void setModeDisposalOfIed(String modeDisposalOfIed) {
		this.modeDisposalOfIed = modeDisposalOfIed;
	}

	public String getIedModeOfDetection() {
		return iedModeOfDetection;
	}

	public void setIedModeOfDetection(String iedModeOfDetection) {
		this.iedModeOfDetection = iedModeOfDetection;
	}

	public String getIedResidualItem() {
		return iedResidualItem;
	}

	public void setIedResidualItem(String iedResidualItem) {
		this.iedResidualItem = iedResidualItem;
	}

	public String getDimensionsOfCreator() {
		return dimensionsOfCreator;
	}

	public void setDimensionsOfCreator(String dimensionsOfCreator) {
		this.dimensionsOfCreator = dimensionsOfCreator;
	}

	public String getAimingPointUsed() {
		return aimingPointUsed;
	}

	public void setAimingPointUsed(String aimingPointUsed) {
		this.aimingPointUsed = aimingPointUsed;
	}

	public String getDistanceFromIed() {
		return distanceFromIed;
	}

	public void setDistanceFromIed(String distanceFromIed) {
		this.distanceFromIed = distanceFromIed;
	}

	public String getNoOfSpikes() {
		return noOfSpikes;
	}

	public void setNoOfSpikes(String noOfSpikes) {
		this.noOfSpikes = noOfSpikes;
	}

	public String getDistanceFromCampSpike() {
		return distanceFromCampSpike;
	}

	public void setDistanceFromCampSpike(String distanceFromCampSpike) {
		this.distanceFromCampSpike = distanceFromCampSpike;
	}

	public String getIedDetails() {
		return iedDetails;
	}

	public void setIedDetails(String iedDetails) {
		this.iedDetails = iedDetails;
	}

	public String getDescOfCreator() {
		return descOfCreator;
	}

	public void setDescOfCreator(String descOfCreator) {
		this.descOfCreator = descOfCreator;
	}

	public String getDescOfSpikes() {
		return descOfSpikes;
	}

	public void setDescOfSpikes(String descOfSpikes) {
		this.descOfSpikes = descOfSpikes;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

}
