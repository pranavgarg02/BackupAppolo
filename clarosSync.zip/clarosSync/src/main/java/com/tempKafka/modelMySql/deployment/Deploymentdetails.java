package com.tempKafka.modelMySql.deployment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import javax.persistence.Id;
@Entity
@Table(name = "dep_details")
public class Deploymentdetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	    private int sno; 
	    @Column(name="dep_id")
	    private String depid;
	    @Column(name="row_order")
	    private boolean roworder;
	    private String coy;
	    
	    @Column(name="coy_commander")
	    private String coycommander;
	    
	    @Column(name="nature_of_duty")
	    private String natureOfDuty;
	    
	    @Column(name="place_location")
	    private String placelocation;
	    
	    private String latitude;
	    private String longitude;
	    private String state;
	    private String district;
	    
	    @Column(name="police_station")
	    private String policestation;
	    
	    @Column(name="available_strength")
	    private String availableStrength;
//	    private String availableGo;
//	    private String availableSo;
//	    private String availableOr;
	    @Column(name="dep_status")
	    private String depStatus;
	    
	    @Column(name="dep_sub_status")
	    private String depSubStatus;
	    
	    @Column(name="created_at")
	    private String createdAt;

		public int getSno() {
			return sno;
		}

		public void setSno(int sno) {
			this.sno = sno;
		}

		public String getDepid() {
			return depid;
		}

		public void setDepid(String depid) {
			this.depid = depid;
		}

		public boolean isRoworder() {
			return roworder;
		}

		public void setRoworder(boolean roworder) {
			this.roworder = roworder;
		}

		public String getCoy() {
			return coy;
		}

		public void setCoy(String coy) {
			this.coy = coy;
		}

		public String getCoycommander() {
			return coycommander;
		}

		public void setCoycommander(String coycommander) {
			this.coycommander = coycommander;
		}

		public String getNatureOfDuty() {
			return natureOfDuty;
		}

		public void setNatureOfDuty(String natureOfDuty) {
			this.natureOfDuty = natureOfDuty;
		}

		public String getPlacelocation() {
			return placelocation;
		}

		public void setPlacelocation(String placelocation) {
			this.placelocation = placelocation;
		}

		public String getLatitude() {
			return latitude;
		}

		public void setLatitude(String latitude) {
			this.latitude = latitude;
		}

		public String getLongitude() {
			return longitude;
		}

		public void setLongitude(String longitude) {
			this.longitude = longitude;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getDistrict() {
			return district;
		}

		public void setDistrict(String district) {
			this.district = district;
		}

		public String getPolicestation() {
			return policestation;
		}

		public void setPolicestation(String policestation) {
			this.policestation = policestation;
		}

		public String getAvailableStrength() {
			return availableStrength;
		}

		public void setAvailableStrength(String availableStrength) {
			this.availableStrength = availableStrength;
		}

		public String getDepStatus() {
			return depStatus;
		}

		public void setDepStatus(String depStatus) {
			this.depStatus = depStatus;
		}

		public String getDepSubStatus() {
			return depSubStatus;
		}

		public void setDepSubStatus(String depSubStatus) {
			this.depSubStatus = depSubStatus;
		}

		public String getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(String createdAt) {
			this.createdAt = createdAt;
		}

		@Override
		public String toString() {
			return "Deploymentdetails [sno=" + sno + ", depid=" + depid + ", roworder=" + roworder + ", coy=" + coy
					+ ", coycommander=" + coycommander + ", natureOfDuty=" + natureOfDuty + ", placelocation="
					+ placelocation + ", latitude=" + latitude + ", longitude=" + longitude + ", state=" + state
					+ ", district=" + district + ", policestation=" + policestation + ", availableStrength="
					+ availableStrength + ", depStatus=" + depStatus + ", depSubStatus=" + depSubStatus + ", createdAt="
					+ createdAt + "]";
		}

		public Deploymentdetails(int sno, String depid, boolean roworder, String coy, String coycommander,
				String natureOfDuty, String placelocation, String latitude, String longitude, String state,
				String district, String policestation, String availableStrength, String depStatus, String depSubStatus,
				String createdAt) {
			super();
			this.sno = sno;
			this.depid = depid;
			this.roworder = roworder;
			this.coy = coy;
			this.coycommander = coycommander;
			this.natureOfDuty = natureOfDuty;
			this.placelocation = placelocation;
			this.latitude = latitude;
			this.longitude = longitude;
			this.state = state;
			this.district = district;
			this.policestation = policestation;
			this.availableStrength = availableStrength;
			this.depStatus = depStatus;
			this.depSubStatus = depSubStatus;
			this.createdAt = createdAt;
		}

		public Deploymentdetails() {
			super();
			// TODO Auto-generated constructor stub
		}

	    // Constructor, getters, and setters
	    // Constructor can be generated based on the fields
	    // Getters and setters are omitted for brevity
	    
	    
}
