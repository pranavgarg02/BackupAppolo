package com.tempKafka.MySqlRepo;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.tempKafka.ElasticModel.IedBlasts_details;

public interface IedBlasts_details_Repository extends ElasticsearchRepository<IedBlasts_details, String> {
}
