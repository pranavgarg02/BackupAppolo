package com.tempKafka.MySqlRepo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.PersonJ;

public interface PersonJRepo  extends JpaRepository<PersonJ,Integer>{

	Optional<PersonJ> findFirstByName(String name);

	List<PersonJ> findByName(String username);


}
