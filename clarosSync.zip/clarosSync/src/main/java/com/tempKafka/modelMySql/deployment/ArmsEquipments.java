package com.tempKafka.modelMySql.deployment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import javax.persistence.Id;
@Entity
@Table(name = "arms_eqpt")
public class ArmsEquipments {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "arms_eqpt_id")
	private int armsEqptId; // Assuming arms_eqpt_id is the primary key with auto-increment
	
	@Column(name = "arms_issued_irla")
    private String armsIssuedIrla;
	
	@Column(name = "arms_eqpt_category")
    private String armsEqptCategory;
	
	@Column(name = "arms_eqpt_sub_category")
    private String armsEqptSubCategory;
	
	@Column(name = "arms_eqpt_type")
    private String armsEqptType;
	
	@Column(name = "arms_eqpt_status")
    private String armsEqptStatus;
	
	@Column(name = "arms_eqpt_count")
    private String armsEqptCount;
	
	@Column(name = "arms_eqpt_quantity")
    private String armsEqptQuantity;
	
	@Column(name = "arms_eqpt_body_number")
    private String armsEqptBodyNumber; // Assuming this can contain a longer text
	
	@Column(name = "arms_eqpt_details")
    private String armsEqptDetails;   // Assuming this can contain a longer text'
	
	@Column(name = "created_by_unit")
    private String createdByUnit;
	
	@Column(name = "created_at")
    private String createdAt;


	public int getArmsEqptId() {
		return armsEqptId;
	}

	public void setArmsEqptId(int armsEqptId) {
		this.armsEqptId = armsEqptId;
	}

	public String getArmsIssuedIrla() {
		return armsIssuedIrla;
	}

	public void setArmsIssuedIrla(String armsIssuedIrla) {
		this.armsIssuedIrla = armsIssuedIrla;
	}

	public String getArmsEqptCategory() {
		return armsEqptCategory;
	}

	public void setArmsEqptCategory(String armsEqptCategory) {
		this.armsEqptCategory = armsEqptCategory;
	}

	public String getArmsEqptSubCategory() {
		return armsEqptSubCategory;
	}

	public void setArmsEqptSubCategory(String armsEqptSubCategory) {
		this.armsEqptSubCategory = armsEqptSubCategory;
	}

	public String getArmsEqptType() {
		return armsEqptType;
	}

	public void setArmsEqptType(String armsEqptType) {
		this.armsEqptType = armsEqptType;
	}

	public String getArmsEqptStatus() {
		return armsEqptStatus;
	}

	public void setArmsEqptStatus(String armsEqptStatus) {
		this.armsEqptStatus = armsEqptStatus;
	}

	public String getArmsEqptCount() {
		return armsEqptCount;
	}

	public void setArmsEqptCount(String armsEqptCount) {
		this.armsEqptCount = armsEqptCount;
	}

	public String getArmsEqptQuantity() {
		return armsEqptQuantity;
	}

	public void setArmsEqptQuantity(String armsEqptQuantity) {
		this.armsEqptQuantity = armsEqptQuantity;
	}

	public String getArmsEqptBodyNumber() {
		return armsEqptBodyNumber;
	}

	public void setArmsEqptBodyNumber(String armsEqptBodyNumber) {
		this.armsEqptBodyNumber = armsEqptBodyNumber;
	}

	public String getArmsEqptDetails() {
		return armsEqptDetails;
	}

	public void setArmsEqptDetails(String armsEqptDetails) {
		this.armsEqptDetails = armsEqptDetails;
	}

	public String getCreatedByUnit() {
		return createdByUnit;
	}

	public void setCreatedByUnit(String createdByUnit) {
		this.createdByUnit = createdByUnit;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public ArmsEquipments(int armsEqptId, String armsIssuedIrla, String armsEqptCategory, String armsEqptSubCategory,
			String armsEqptType, String armsEqptStatus, String armsEqptCount, String armsEqptQuantity,
			String armsEqptBodyNumber, String armsEqptDetails, String createdByUnit, String createdAt) {
		super();
		this.armsEqptId = armsEqptId;
		this.armsIssuedIrla = armsIssuedIrla;
		this.armsEqptCategory = armsEqptCategory;
		this.armsEqptSubCategory = armsEqptSubCategory;
		this.armsEqptType = armsEqptType;
		this.armsEqptStatus = armsEqptStatus;
		this.armsEqptCount = armsEqptCount;
		this.armsEqptQuantity = armsEqptQuantity;
		this.armsEqptBodyNumber = armsEqptBodyNumber;
		this.armsEqptDetails = armsEqptDetails;
		this.createdByUnit = createdByUnit;
		this.createdAt = createdAt;
	}

	@Override
	public String toString() {
		return "ArmsEquipments [armsEqptId=" + armsEqptId + ", armsIssuedIrla="
				+ armsIssuedIrla + ", armsEqptCategory=" + armsEqptCategory + ", armsEqptSubCategory="
				+ armsEqptSubCategory + ", armsEqptType=" + armsEqptType + ", armsEqptStatus=" + armsEqptStatus
				+ ", armsEqptCount=" + armsEqptCount + ", armsEqptQuantity=" + armsEqptQuantity
				+ ", armsEqptBodyNumber=" + armsEqptBodyNumber + ", armsEqptDetails=" + armsEqptDetails
				+ ", createdByUnit=" + createdByUnit + ", createdAt=" + createdAt + "]";
	}

	public ArmsEquipments() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    
	
}
