package com.tempKafka.modelMySql.deployment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import javax.persistence.Id;
@Entity
@Table(name = "event_unitinvolved")
public class eventUnitInvolved {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 	private int sno; // AI PK means Auto Increment Primary Key

	    @Column(name = "event_id", length = 200)
	    private String eventId;

	    @Column(name = "party_id", length = 200)
	    private String partyId;

	    @Column(name = "unit", length = 200)
	    private String unit;

	    @Column(name = "company", length = 200)
	    private String company;

	    @Column(name = "unit_control_room_no", length = 200)
	    private String unitControlRoomNo;

	    @Column(name = "irla_force_no", length = 200)
	    private String irlaForceNo;

	    @Column(name = "commander_name", length = 200)
	    private String commanderName;

	    @Column(name = "commander_rank", length = 200)
	    private String commanderRank;

	    @Column(name = "commander_mobile_no", length = 200)
	    private String commanderMobileNo;

	    @Column(name = "strength_of_party", length = 200)
	    private String strengthOfParty;

	    @Column(name = "created_at", length = 200)
	    private String createdAt;

	    @Column(name = "created_by", length = 200)
	    private String createdBy;

	    @Column(name = "updated_at")
	    private String updatedAt;

	    @Column(name = "updated_by", length = 200)
	    private String updatedBy;


		public int getSno() {
			return sno;
		}

		public void setSno(int sno) {
			this.sno = sno;
		}

		public String getEventId() {
			return eventId;
		}

		public void setEventId(String eventId) {
			this.eventId = eventId;
		}

		public String getPartyId() {
			return partyId;
		}

		public void setPartyId(String partyId) {
			this.partyId = partyId;
		}

		public String getUnit() {
			return unit;
		}

		public void setUnit(String unit) {
			this.unit = unit;
		}

		public String getCompany() {
			return company;
		}

		public void setCompany(String company) {
			this.company = company;
		}

		public String getUnitControlRoomNo() {
			return unitControlRoomNo;
		}

		public void setUnitControlRoomNo(String unitControlRoomNo) {
			this.unitControlRoomNo = unitControlRoomNo;
		}

		public String getIrlaForceNo() {
			return irlaForceNo;
		}

		public void setIrlaForceNo(String irlaForceNo) {
			this.irlaForceNo = irlaForceNo;
		}

		public String getCommanderName() {
			return commanderName;
		}

		public void setCommanderName(String commanderName) {
			this.commanderName = commanderName;
		}

		public String getCommanderRank() {
			return commanderRank;
		}

		public void setCommanderRank(String commanderRank) {
			this.commanderRank = commanderRank;
		}

		public String getCommanderMobileNo() {
			return commanderMobileNo;
		}

		public void setCommanderMobileNo(String commanderMobileNo) {
			this.commanderMobileNo = commanderMobileNo;
		}

		public String getStrengthOfParty() {
			return strengthOfParty;
		}

		public void setStrengthOfParty(String strengthOfParty) {
			this.strengthOfParty = strengthOfParty;
		}

		public String getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(String createdAt) {
			this.createdAt = createdAt;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public String getUpdatedAt() {
			return updatedAt;
		}

		public void setUpdatedAt(String updatedAt) {
			this.updatedAt = updatedAt;
		}

		public String getUpdatedBy() {
			return updatedBy;
		}

		public void setUpdatedBy(String updatedBy) {
			this.updatedBy = updatedBy;
		}

		public eventUnitInvolved(int sno, String eventId, String partyId, String unit, String company,
				String unitControlRoomNo, String irlaForceNo, String commanderName, String commanderRank,
				String commanderMobileNo, String strengthOfParty, String createdAt, String createdBy, String updatedAt,
				String updatedBy) {
			super();
			this.sno = sno;
			this.eventId = eventId;
			this.partyId = partyId;
			this.unit = unit;
			this.company = company;
			this.unitControlRoomNo = unitControlRoomNo;
			this.irlaForceNo = irlaForceNo;
			this.commanderName = commanderName;
			this.commanderRank = commanderRank;
			this.commanderMobileNo = commanderMobileNo;
			this.strengthOfParty = strengthOfParty;
			this.createdAt = createdAt;
			this.createdBy = createdBy;
			this.updatedAt = updatedAt;
			this.updatedBy = updatedBy;
		}

		public eventUnitInvolved() {
			super();
			// TODO Auto-generated constructor stub
		}

		@Override
		public String toString() {
			return "eventUnitInvolved [sno=" + sno + ", eventId=" + eventId + ", partyId=" + partyId
					+ ", unit=" + unit + ", company=" + company + ", unitControlRoomNo=" + unitControlRoomNo
					+ ", irlaForceNo=" + irlaForceNo + ", commanderName=" + commanderName + ", commanderRank="
					+ commanderRank + ", commanderMobileNo=" + commanderMobileNo + ", strengthOfParty="
					+ strengthOfParty + ", createdAt=" + createdAt + ", createdBy=" + createdBy + ", updatedAt="
					+ updatedAt + ", updatedBy=" + updatedBy + "]";
		}
	    

}
