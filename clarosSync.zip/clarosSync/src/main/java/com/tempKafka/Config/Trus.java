//package com.tempKafka.Config;
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.security.GeneralSecurityException;
//import java.security.KeyStore;
//import java.security.cert.CertificateFactory;
//import java.security.cert.X509Certificate;
//import javax.net.ssl.TrustManager;
//import javax.net.ssl.TrustManagerFactory;
//import javax.net.ssl.X509TrustManager;
//
//public class Trus {
//
//    public static TrustManager[] build(InputStream certStream) throws GeneralSecurityException, IOException {
//        CertificateFactory cf = CertificateFactory.getInstance("X.509");
//        X509Certificate cert;
//        try (InputStream in = certStream) {
//            cert = (X509Certificate) cf.generateCertificate(in);
//        }
//
//        KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
//        keyStore.load(null, null);
//        keyStore.setCertificateEntry("elasticsearch-cert", cert);
//
//        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
//        tmf.init(keyStore);
//
//        return tmf.getTrustManagers();
//    }
//}