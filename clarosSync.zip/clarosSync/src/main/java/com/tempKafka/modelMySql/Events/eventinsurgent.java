package com.tempKafka.modelMySql.Events;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "eventinsurgentdetail")
public class eventinsurgent {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	  private int sno; // AI PK means Auto Increment Primary Key

	    @Column(name = "event_id", length = 200)
	    private String eventId;

	    @Column(name = "insurgent_information_type", length = 200)
	    private String insurgentInformationType;

	    @Column(name = "insurgent_specific_target", length = 200)
	    private String insurgentSpecificTarget;

	    @Column(name = "insurgent_theatre", length = 200)
	    private String insurgentTheatre;

	    @Column(name = "insurgent_orgname", length = 200)
	    private String insurgentOrgName;

	    @Column(name = "insurgent_location", length = 200)
	    private String insurgentLocation;

	    @Column(name = "insurgent_topographical_detail", length = 200)
	    private String insurgentTopographicalDetail;

	    @Column(name = "insurgent_camp_type", length = 200)
	    private String insurgentCampType;

	    @Column(name = "insurgent_leader_name", length = 200)
	    private String insurgentLeaderName;

	    @Column(name = "insurgent_training_nature", length = 200)
	    private String insurgentTrainingNature;

	    @Column(name = "insurgent_camp_strength", length = 200)
	    private String insurgentCampStrength;

	    @Column(name = "insurgent_weapons_type", length = 200)
	    private String insurgentWeaponsType;

	    @Column(name = "insurgent_number_of_weapons", length = 200)
	    private String insurgentNumberOfWeapons;

	    @Column(name = "insurgent_eqp_type", length = 200)
	    private String insurgentEqpType;

	    @Column(name = "insurgent_number_of_eqpt", length = 200)
	    private String insurgentNumberOfEqpt;

	    @Column(name = "insurgent_foreign_agency", length = 200)
	    private String insurgentForeignAgency;

	    @Column(name = "insurgent_place_of_infiltration", length = 200)
	    private String insurgentPlaceOfInfiltration;

	    @Column(name = "insurgent_route_of_infiltration", length = 200)
	    private String insurgentRouteOfInfiltration;

	    @Column(name = "insurgent_destination_of_infiltration", length = 200)
	    private String insurgentDestinationOfInfiltration;

	    @Column(name = "insurgent_communication_station", length = 200)
	    private String insurgentCommunicationStation;

	    @Column(name = "communication_control_station", length = 200)
	    private String communicationControlStation;

	    @Column(name = "insurgent_communication_station_loc", length = 200)
	    private String insurgentCommunicationStationLoc;

	    @Column(name = "insurgent_sat_mob_no", length = 200)
	    private String insurgentSatMobNo;

	    @Column(name = "insurgent_detail_sat_mob", length = 200)
	    private String insurgentDetailSatMob;

	    @Column(name = "insurgent_communication_schedule", length = 200)
	    private String insurgentCommunicationSchedule;

	    @Column(name = "insurgent_freq_radio", length = 200)
	    private String insurgentFreqRadio;

	    @Column(name = "insurgent_email", length = 200)
	    private String insurgentEmail;

	    @Column(name = "insurgent_website", length = 200)
	    private String insurgentWebsite;

	    @Column(name = "insurgent_amount_demanded", length = 200)
	    private String insurgentAmountDemanded;

	    @Column(name = "insurgent_amount_demanded_from", length = 200)
	    private String insurgentAmountDemandedFrom;

	    @Column(name = "created_at", length = 200)
	    private String createdAt;

	    @Column(name = "updated_at", length = 200)
	    private String updatedAt;

	    @Column(name = "createdby", length = 200)
	    private String createdBy;

	    @Column(name = "updatedby", length = 200)
	    private String updatedBy;


		public int getSno() {
			return sno;
		}

		public void setSno(int sno) {
			this.sno = sno;
		}

		public String getEventId() {
			return eventId;
		}

		public void setEventId(String eventId) {
			this.eventId = eventId;
		}

		public String getInsurgentInformationType() {
			return insurgentInformationType;
		}

		public void setInsurgentInformationType(String insurgentInformationType) {
			this.insurgentInformationType = insurgentInformationType;
		}

		public String getInsurgentSpecificTarget() {
			return insurgentSpecificTarget;
		}

		public void setInsurgentSpecificTarget(String insurgentSpecificTarget) {
			this.insurgentSpecificTarget = insurgentSpecificTarget;
		}

		public String getInsurgentTheatre() {
			return insurgentTheatre;
		}

		public void setInsurgentTheatre(String insurgentTheatre) {
			this.insurgentTheatre = insurgentTheatre;
		}

		public String getInsurgentOrgName() {
			return insurgentOrgName;
		}

		public void setInsurgentOrgName(String insurgentOrgName) {
			this.insurgentOrgName = insurgentOrgName;
		}

		public String getInsurgentLocation() {
			return insurgentLocation;
		}

		public void setInsurgentLocation(String insurgentLocation) {
			this.insurgentLocation = insurgentLocation;
		}

		public String getInsurgentTopographicalDetail() {
			return insurgentTopographicalDetail;
		}

		public void setInsurgentTopographicalDetail(String insurgentTopographicalDetail) {
			this.insurgentTopographicalDetail = insurgentTopographicalDetail;
		}

		public String getInsurgentCampType() {
			return insurgentCampType;
		}

		public void setInsurgentCampType(String insurgentCampType) {
			this.insurgentCampType = insurgentCampType;
		}

		public String getInsurgentLeaderName() {
			return insurgentLeaderName;
		}

		public void setInsurgentLeaderName(String insurgentLeaderName) {
			this.insurgentLeaderName = insurgentLeaderName;
		}

		public String getInsurgentTrainingNature() {
			return insurgentTrainingNature;
		}

		public void setInsurgentTrainingNature(String insurgentTrainingNature) {
			this.insurgentTrainingNature = insurgentTrainingNature;
		}

		public String getInsurgentCampStrength() {
			return insurgentCampStrength;
		}

		public void setInsurgentCampStrength(String insurgentCampStrength) {
			this.insurgentCampStrength = insurgentCampStrength;
		}

		public String getInsurgentWeaponsType() {
			return insurgentWeaponsType;
		}

		public void setInsurgentWeaponsType(String insurgentWeaponsType) {
			this.insurgentWeaponsType = insurgentWeaponsType;
		}

		public String getInsurgentNumberOfWeapons() {
			return insurgentNumberOfWeapons;
		}

		public void setInsurgentNumberOfWeapons(String insurgentNumberOfWeapons) {
			this.insurgentNumberOfWeapons = insurgentNumberOfWeapons;
		}

		public String getInsurgentEqpType() {
			return insurgentEqpType;
		}

		public void setInsurgentEqpType(String insurgentEqpType) {
			this.insurgentEqpType = insurgentEqpType;
		}

		public String getInsurgentNumberOfEqpt() {
			return insurgentNumberOfEqpt;
		}

		public void setInsurgentNumberOfEqpt(String insurgentNumberOfEqpt) {
			this.insurgentNumberOfEqpt = insurgentNumberOfEqpt;
		}

		public String getInsurgentForeignAgency() {
			return insurgentForeignAgency;
		}

		public void setInsurgentForeignAgency(String insurgentForeignAgency) {
			this.insurgentForeignAgency = insurgentForeignAgency;
		}

		public String getInsurgentPlaceOfInfiltration() {
			return insurgentPlaceOfInfiltration;
		}

		public void setInsurgentPlaceOfInfiltration(String insurgentPlaceOfInfiltration) {
			this.insurgentPlaceOfInfiltration = insurgentPlaceOfInfiltration;
		}

		public String getInsurgentRouteOfInfiltration() {
			return insurgentRouteOfInfiltration;
		}

		public void setInsurgentRouteOfInfiltration(String insurgentRouteOfInfiltration) {
			this.insurgentRouteOfInfiltration = insurgentRouteOfInfiltration;
		}

		public String getInsurgentDestinationOfInfiltration() {
			return insurgentDestinationOfInfiltration;
		}

		public void setInsurgentDestinationOfInfiltration(String insurgentDestinationOfInfiltration) {
			this.insurgentDestinationOfInfiltration = insurgentDestinationOfInfiltration;
		}

		public String getInsurgentCommunicationStation() {
			return insurgentCommunicationStation;
		}

		public void setInsurgentCommunicationStation(String insurgentCommunicationStation) {
			this.insurgentCommunicationStation = insurgentCommunicationStation;
		}

		public String getCommunicationControlStation() {
			return communicationControlStation;
		}

		public void setCommunicationControlStation(String communicationControlStation) {
			this.communicationControlStation = communicationControlStation;
		}

		public String getInsurgentCommunicationStationLoc() {
			return insurgentCommunicationStationLoc;
		}

		public void setInsurgentCommunicationStationLoc(String insurgentCommunicationStationLoc) {
			this.insurgentCommunicationStationLoc = insurgentCommunicationStationLoc;
		}

		public String getInsurgentSatMobNo() {
			return insurgentSatMobNo;
		}

		public void setInsurgentSatMobNo(String insurgentSatMobNo) {
			this.insurgentSatMobNo = insurgentSatMobNo;
		}

		public String getInsurgentDetailSatMob() {
			return insurgentDetailSatMob;
		}

		public void setInsurgentDetailSatMob(String insurgentDetailSatMob) {
			this.insurgentDetailSatMob = insurgentDetailSatMob;
		}

		public String getInsurgentCommunicationSchedule() {
			return insurgentCommunicationSchedule;
		}

		public void setInsurgentCommunicationSchedule(String insurgentCommunicationSchedule) {
			this.insurgentCommunicationSchedule = insurgentCommunicationSchedule;
		}

		public String getInsurgentFreqRadio() {
			return insurgentFreqRadio;
		}

		public void setInsurgentFreqRadio(String insurgentFreqRadio) {
			this.insurgentFreqRadio = insurgentFreqRadio;
		}

		public String getInsurgentEmail() {
			return insurgentEmail;
		}

		public void setInsurgentEmail(String insurgentEmail) {
			this.insurgentEmail = insurgentEmail;
		}

		public String getInsurgentWebsite() {
			return insurgentWebsite;
		}

		public void setInsurgentWebsite(String insurgentWebsite) {
			this.insurgentWebsite = insurgentWebsite;
		}

		public String getInsurgentAmountDemanded() {
			return insurgentAmountDemanded;
		}

		public void setInsurgentAmountDemanded(String insurgentAmountDemanded) {
			this.insurgentAmountDemanded = insurgentAmountDemanded;
		}

		public String getInsurgentAmountDemandedFrom() {
			return insurgentAmountDemandedFrom;
		}

		public void setInsurgentAmountDemandedFrom(String insurgentAmountDemandedFrom) {
			this.insurgentAmountDemandedFrom = insurgentAmountDemandedFrom;
		}

		public String getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(String createdAt) {
			this.createdAt = createdAt;
		}

		public String getUpdatedAt() {
			return updatedAt;
		}

		public void setUpdatedAt(String updatedAt) {
			this.updatedAt = updatedAt;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public String getUpdatedBy() {
			return updatedBy;
		}

		public void setUpdatedBy(String updatedBy) {
			this.updatedBy = updatedBy;
		}

		public eventinsurgent() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
	    
}
