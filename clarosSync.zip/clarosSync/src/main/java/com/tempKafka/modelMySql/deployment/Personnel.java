package com.tempKafka.modelMySql.deployment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import javax.persistence.Id;

@Entity
@Table(name = "personnel")
public class Personnel {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	 private int id;
	
	
		@Column(name= "rank")
		private String personnelrank;
	
		@Column(name = "user_name")
	    private String username;
	    
		@Column(name = "name")
	    private String personnelName;
	    
		@Column(name = "f_no")
	    private String fNo;
	    
		@Column(name = "contact_no")
	    private String contactNo;
	    
		@Column(name = "email")
	    private String email;
	    
		@Column(name = "unit")
	    private String unit;
		
		@Column(name = "status")
	    private String status;
	    
	    @Column(name ="created_at")
	    private String createdAt;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getPersonnelrank() {
			return personnelrank;
		}

		public void setPersonnelrank(String personnelrank) {
			this.personnelrank = personnelrank;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getPersonnelName() {
			return personnelName;
		}

		public void setPersonnelName(String personnelName) {
			this.personnelName = personnelName;
		}

		public String getfNo() {
			return fNo;
		}

		public void setfNo(String fNo) {
			this.fNo = fNo;
		}

		public String getContactNo() {
			return contactNo;
		}

		public void setContactNo(String contactNo) {
			this.contactNo = contactNo;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getUnit() {
			return unit;
		}

		public void setUnit(String unit) {
			this.unit = unit;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getCreatedAt() {
			return createdAt;
		}

		public void setCreatedAt(String createdAt) {
			this.createdAt = createdAt;
		}

		public Personnel(String personnelrank, String username, String personnelName, String fNo, String contactNo,
				String email, String unit, String status, String createdAt) {
			super();
			this.personnelrank = personnelrank;
			this.username = username;
			this.personnelName = personnelName;
			this.fNo = fNo;
			this.contactNo = contactNo;
			this.email = email;
			this.unit = unit;
			this.status = status;
			this.createdAt = createdAt;
		}

		@Override
		public String toString() {
			return "Personnel [id=" + id + ", personnelrank=" + personnelrank + ", username=" + username
					+ ", personnelName=" + personnelName + ", fNo=" + fNo + ", contactNo=" + contactNo + ", email="
					+ email + ", unit=" + unit + ", status=" + status + ", createdAt=" + createdAt + "]";
		}

		public Personnel() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
		
	    
}