package com.tempKafka.MultiThreadStructure;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import com.tempKafka.ElasticModel.Crpf_processor;
import com.tempKafka.ElasticModel.DeploymentList;
import com.tempKafka.MySqlRepo.deploymentRepository.Dep_um_food_details_Repo;
import com.tempKafka.MySqlRepo.deploymentRepository.DeploymentDetailsRepository;
import com.tempKafka.modelMySql.deployment.Dep_um_food_details;
import com.tempKafka.modelMySql.deployment.Deployment;
import com.tempKafka.modelMySql.deployment.Deploymentdetails;

public class ThreadForDeploymentList extends Thread implements Runnable {
	@Autowired
	private DeploymentDetailsRepository depdetailsrepo;
	@Autowired
	private Dep_um_food_details_Repo depfoodrepo;
	
	Crpf_processor cp ;
	List<Deployment> li3 = new ArrayList<>();
	private DeploymentList dls;

	public ThreadForDeploymentList(List<Deployment> li3, Crpf_processor cp) {
		super();
		this.li3 = li3;
		this.cp = cp;
	}
	public DeploymentList setDetails(List<Deploymentdetails> detailsList, List<Dep_um_food_details> foodList) {
		this.dls.setDem(foodList);
		this.dls.setDet(detailsList);
		return this.dls;
	}
	@Override
	public void run() {
		try {
			System.out.println("Deployment List : " + Thread.currentThread().getId() + " " + Thread.currentThread().getName());
			List<String> depIds = li3.stream().map(Deployment::getDepId).collect(Collectors.toList());
			List<Deploymentdetails> allDetails = depdetailsrepo.findByDepidIn(depIds);
			List<Dep_um_food_details> alldepfood = depfoodrepo.findByDepIdIn(depIds);
			
			Map<String, List<Deploymentdetails>> detailsMap = allDetails.stream().collect(Collectors.groupingBy(Deploymentdetails::getDepid));
			Map<String, List<Dep_um_food_details>> foodDetailsMap = alldepfood.stream().collect(Collectors.groupingBy(Dep_um_food_details::getDepId));
				
			for(String depId : depIds) {
				List<Deploymentdetails> detailsList = detailsMap.get(depId);
				List<Dep_um_food_details> foodList = foodDetailsMap.get(depId);
				if (detailsList != null && foodList!=null ) {
					this.cp.getDlslist().add(setDetails(detailsList, foodList));
			    }
			 }
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	public Crpf_processor getCp() {
		return cp;
	}
	public void setCp(Crpf_processor cp) {
		this.cp = cp;
	}
			
}
