-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 3.7.32.64    Database: claros
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `arms_eqpt`
--

DROP TABLE IF EXISTS `arms_eqpt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `arms_eqpt` (
  `arms_eqpt_id` int NOT NULL AUTO_INCREMENT,
  `arms_issued_irla` varchar(200) NOT NULL,
  `arms_eqpt_category` varchar(200) NOT NULL DEFAULT '',
  `arms_eqpt_sub_category` varchar(200) NOT NULL,
  `arms_eqpt_type` varchar(500) DEFAULT NULL,
  `arms_eqpt_status` varchar(500) DEFAULT NULL,
  `arms_eqpt_count` varchar(100) DEFAULT NULL,
  `arms_eqpt_quantity` varchar(100) DEFAULT NULL,
  `arms_eqpt_body_number` text,
  `arms_eqpt_details` text,
  `created_by` varchar(200) NOT NULL,
  `created_by_unit` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(200) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`arms_eqpt_id`),
  KEY `index` (`arms_eqpt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arms_eqpt`
--

LOCK TABLES `arms_eqpt` WRITE;
/*!40000 ALTER TABLE `arms_eqpt` DISABLE KEYS */;
INSERT INTO `arms_eqpt` VALUES (1,'IRLA-0Ae#14','Sub Machine Guns (SMGs)','Cat-#S0 D1626','P6','Ready for deployment','1178','1272960','#B0Ae- N4014114U','Bullets 0.9mm and 7.62mm','GunjanSharma','unit-SSF','2024-06-27 12:52:26','AV-Zone Force','2024-06-27 12:46:44'),(2,'IRLA-0Ae#2','ShotGuns','Cat-#S0 D1392','12 Bore PAG','In Inventory','819','1130620','#B0Ae- W7565061B','Bullets 0.9mm and 7.62mm','PriyaVerma','unit-ASF','2024-06-27 12:52:27','UOM-Force','2024-06-27 12:46:44'),(3,'IRLA-0Ae#3','Sniper Rifles','Cat-#S0 A1527','Dragunov SVD','Ready for deployment','257','1404663','#B0Ae- X154389D','Bullets 0.9mm and 7.62mm','KajolKhandelwal','unit-HSF','2024-06-27 12:55:45','AV-Zone Force','2024-06-27 12:46:44'),(4,'IRLA-0Ae#16','Anti-Material Rifles ','Cat-#S0 D1292','Barret M82','Under Deployment and Inactive','768','1288067','#B0Ae- U10652841J','Bullets 0.9mm and 7.62mm','TarunChaurasia','unit-ASF','2024-06-27 12:54:42','UOM-Force','2024-06-27 12:46:44'),(5,'IRLA-0Ae#17','Assault Rifles (ARs)','Cat-#S0 B1294','AK-203','Under Deployment and Inactive','1027','1426221','#B0Ae- S12659898J','Bullets 0.9mm and 7.62mm','AmritaKhandelwal','unit-ESF','2024-06-27 12:54:42','Survelliance Force','2024-06-27 12:46:44'),(6,'IRLA-0Ae#9','Assault Rifles (ARs)','Cat-#S0 D1700','M4-Carbine','Ready for deployment','948','1520238','#B0Ae- L2624613M','Bullets 0.9mm and 7.62mm','SoniyaSharma','unit-ESF','2024-06-27 12:54:42','Deployed Security Force','2024-06-27 12:46:44'),(7,'IRLA-0Ae#1','Assault Rifles (ARs)','Cat-#S0 B1422','AKM','Already Deployed and Active','911','1279865','#B0Ae- J6175560D','Bullets 0.9mm and 7.62mm','TarunVerma','unit-ESF','2024-06-27 12:54:42','UOM-Force','2024-06-27 12:46:44'),(8,'IRLA-0Ae#5','Sub Machine Guns (SMGs)','Cat-#S0 D1642','MICRO UZI','Ready for deployment','374','1302925','#B0Ae- D463167T','Bullets 0.9mm and 7.62mm','PriyaBhardwaj','unit-DSF','2024-06-27 12:49:05','UOM-Force','2024-06-27 12:46:44'),(9,'IRLA-0Ae#16','Sub Machine Guns (SMGs)','Cat-#S0 C1572','ASMI','Ready for deployment','1123','1529715','#B0Ae- A10344063U','Bullets 0.9mm and 7.62mm','MohitaKhandelwal','unit-ASF','2024-06-27 12:55:45','UOM-Force','2024-06-27 12:46:44'),(10,'IRLA-0Ae#18','Sniper Rifles','Cat-#S0 B1595','Koch PSG1','Already Deployed and Active','648','795432','#B0Ae- S10498452O','Bullets 0.9mm and 7.62mm','AmritaSharma','unit-HSF','2024-06-27 12:55:45','UOM-Force','2024-06-27 12:46:44'),(11,'IRLA-0Ae#9','Anti-Material Rifles ','Cat-#S0 C1182','Barret M95','In Inventory','463','1355431','#B0Ae- C11270397V','Bullets 0.9mm and 7.62mm','AmritaKhandelwal','unit-BSF','2024-06-27 12:54:42','AV-Zone Force','2024-06-27 12:46:44'),(12,'IRLA-0Ae#6','Assault Rifles (ARs)','Cat-#S0 C1496','AR-M1','Ready for deployment','1119','1452742','#B0Ae- P2007057U','Bullets 0.9mm and 7.62mm','TarunChoubey','unit-SSF','2024-06-27 12:54:42','Deployed Security Force','2024-06-27 12:46:44'),(13,'IRLA-0Ae#17','Machine Guns','Cat-#S0 D916','MG 2A1','Deployed and present in Inventory','841','912173','#B0Ae- S5866782W','Bullets 0.9mm and 7.62mm','ParagVerma','unit-DSF','2024-06-27 12:56:30','Survelliance Force','2024-06-27 12:46:44'),(14,'IRLA-0Ae#3','Assault Rifles (ARs)','Cat-#S0 C1071','AK-47','Already Deployed and Active','280','955978','#B0Ae- Q10961619C','Bullets 0.9mm and 7.62mm','SoniyaSharma','unit-DSF','2024-06-27 12:54:42','AV-Zone Force','2024-06-27 12:46:44'),(15,'IRLA-0Ae#8','Sub Machine Guns (SMGs)','Cat-#S0 A1296','SAF Carbine','Already Deployed and Active','309','1264684','#B0Ae- D2161446K','Bullets 0.9mm and 7.62mm','GunjanSharma','unit-ASF','2024-06-27 12:52:27','Survelliance Force','2024-06-27 12:46:44'),(16,'IRLA-0Ae#98','Sub Machine Guns (SMGs)','Cat-#S0 B907','Thormet MP9','Under Deployment and Inactive','469','1292340','#B0Ae- S5094837N','Bullets 0.9mm and 7.62mm','MalikaVerma','unit-BSF','2024-06-27 12:56:30','Deployed Security Force','2024-06-27 12:46:44'),(17,'IRLA-0Ae#1','Sniper Rifles','Cat-#S0 A766','Mauser SP66','Ready for deployment','882','1171858','#B0Ae- W7256283U','Bullets 0.9mm and 7.62mm','HatimChaurasia','unit-SSF','2024-06-27 12:55:45','Survelliance Force','2024-06-27 12:46:44'),(18,'IRLA-0Ae#4','Anti-Material Rifles ','Cat-#S0 B1528','OSV-96','Under Deployment and Inactive','824','1295560','#B0Ae- R1543890J','Bullets 0.9mm and 7.62mm','GunjanSharma','unit-ASF','2024-06-27 12:54:42','UOM-Force','2024-06-27 12:46:44'),(19,'IRLA-0Ae#12','Machine Guns','Cat-#S0 B1059','MG 5A','Under Deployment and Inactive','990','1705261','#B0Ae- G8337006G','Bullets 0.9mm and 7.62mm','SoniyaSharma','unit-DSF','2024-06-27 12:56:30','AV-Zone Force','2024-06-27 12:46:44');
/*!40000 ALTER TABLE `arms_eqpt` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-10 15:22:52
