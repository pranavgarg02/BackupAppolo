package com.tempKafka.MySqlRepo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.Village;

public interface VillageRepo extends JpaRepository<Village,Integer>{

	List<Village> findByName(String name);

}
