package com.tempKafka.MySqlRepo.EventsRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.Events.eventinsurgent;

public interface EventInsurgentRepo extends JpaRepository<eventinsurgent, Integer>{

}
