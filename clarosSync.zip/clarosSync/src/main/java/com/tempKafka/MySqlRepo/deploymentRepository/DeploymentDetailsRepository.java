package com.tempKafka.MySqlRepo.deploymentRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.deployment.Deploymentdetails;
import java.util.List;



public interface DeploymentDetailsRepository extends JpaRepository<Deploymentdetails, Integer> {

//	  List<Deploymentdetails> findByDepidIn(List<String> depid);
	List<Deploymentdetails> findByDepidIn(List<String> depid);
}
