//package com.tempKafka.Config;
//import org.apache.http.Header;
//import org.apache.http.HttpHost;
//import org.apache.http.auth.AuthScope;
//import org.apache.http.auth.UsernamePasswordCredentials;
//import org.apache.http.client.CredentialsProvider;
//import org.apache.http.impl.client.BasicCredentialsProvider;
//import org.apache.http.message.BasicHeader;
//import org.elasticsearch.client.RestClient;
//import org.elasticsearch.client.RestClientBuilder;
//import org.elasticsearch.client.RestHighLevelClient;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpHeaders;
//import org.springframework.security.config.annotation.method.configuration.EnableReactiveMethodSecurity;
//import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
//import org.springframework.security.config.web.server.ServerHttpSecurity;
//import org.springframework.security.web.server.SecurityWebFilterChain;
//
//@Configuration
//@EnableWebFluxSecurity
//@EnableReactiveMethodSecurity
//public class SecurityConfig {
//	
//	
//	@Value("${elastic.host}")
//	private String host;
//	@Value("${elastic.port}")
//	private int port;
//
//	@Value("${spring.elasticsearch.rest.password}")
//	private String password;
//	@Value("${spring.elasticsearch.rest.username}")
//	private String username;
//	
//	
////   for xpack 
//	@Bean(destroyMethod = "close")
//	public RestHighLevelClient restClient() {
//		final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
//		credentialsProvider.setCredentials(AuthScope.ANY,
//				new UsernamePasswordCredentials(username, password));
//
//		RestClientBuilder builder = RestClient.builder(new HttpHost(host, port))
//				.setDefaultHeaders(compatibilityHeaders()).setHttpClientConfigCallback(httpClientBuilder -> {
//					httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
//					return httpClientBuilder;
//				});
//
//		return new RestHighLevelClient(builder);
//	}
//	
//	private Header[] compatibilityHeaders() {
//		return new Header[] {
//				new BasicHeader(HttpHeaders.ACCEPT, "application/vnd.elasticsearch+json;compatible-with=7"),
//				new BasicHeader(HttpHeaders.CONTENT_TYPE, "application/vnd.elasticsearch+json;compatible-with=7") };
//	}
//	
//	
//	@Bean
//	public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) throws Exception {
//		
//		http.cors();
//		http.csrf().disable()
//				.authorizeExchange()
//				.pathMatchers("/actuator/**").permitAll()
//				.anyExchange()
//				.authenticated()
//			.and()
//				.oauth2Login()
//			.and()
//				.oauth2ResourceServer()
//				.jwt();
//		
//		return http.build();
//	}
//
//}
