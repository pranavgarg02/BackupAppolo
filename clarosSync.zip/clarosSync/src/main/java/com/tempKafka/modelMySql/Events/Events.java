package com.tempKafka.modelMySql.Events;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "events")
public class Events {
//	 (event_id, created_at, created_by, infotype, typeofinput, typeofincident
//             ,eventtype, subject, description) 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sno;
	@Column(name="event_id")
	String eventid;
	@Column(name="created_at")
	String createdAt;
	String infotype;
	String typeofinput;
	String typeofincident;
	String eventtype;
	String subject;
	String description;
	String latitude;
	String longitude;
	String informationsource;
	String priority;
	String state;
	String district;
	String theatre;
	@Column(name = "eventsubtype")
    private String eventSubType;

    @Column(name = "eventrelatedto")
    private String eventRelatedTo;

    @Column(name = "sister_agency")
    private String sisterAgency;

    public String getEventSubType() {
		return eventSubType;
	}



	public void setEventSubType(String eventSubType) {
		this.eventSubType = eventSubType;
	}



	public String getEventRelatedTo() {
		return eventRelatedTo;
	}



	public void setEventRelatedTo(String eventRelatedTo) {
		this.eventRelatedTo = eventRelatedTo;
	}



	public String getSisterAgency() {
		return sisterAgency;
	}



	public void setSisterAgency(String sisterAgency) {
		this.sisterAgency = sisterAgency;
	}



	public String getOrganization() {
		return organization;
	}



	public void setOrganization(String organization) {
		this.organization = organization;
	}



	public String getOrgSubZone() {
		return orgSubZone;
	}



	public void setOrgSubZone(String orgSubZone) {
		this.orgSubZone = orgSubZone;
	}



	@Column(name = "organization")
    private String organization;

    @Column(name = "org_sub_zone")
    private String orgSubZone;

	    
	
	public String getTheatre() {
		return theatre;
	}



	public void setTheatre(String theatre) {
		this.theatre = theatre;
	}



	public Events() {
		super();
	}



	public int getSno() {
		return sno;
	}



	public void setSno(int sno) {
		this.sno = sno;
	}



	public String getEventid() {
		return eventid;
	}



	public void setEventid(String eventid) {
		this.eventid = eventid;
	}



	public String getCreatedAt() {
		return createdAt;
	}



	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}



	public String getInfotype() {
		return infotype;
	}



	public void setInfotype(String infotype) {
		this.infotype = infotype;
	}



	public String getTypeofinput() {
		return typeofinput;
	}



	public void setTypeofinput(String typeofinput) {
		this.typeofinput = typeofinput;
	}



	public String getTypeofincident() {
		return typeofincident;
	}



	public void setTypeofincident(String typeofincident) {
		this.typeofincident = typeofincident;
	}



	public String getEventtype() {
		return eventtype;
	}



	public void setEventtype(String eventtype) {
		this.eventtype = eventtype;
	}



	public String getSubject() {
		return subject;
	}



	public void setSubject(String subject) {
		this.subject = subject;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getLatitude() {
		return latitude;
	}



	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}



	public String getLongitude() {
		return longitude;
	}



	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}



	public String getInformationsource() {
		return informationsource;
	}



	public void setInformationsource(String informationsource) {
		this.informationsource = informationsource;
	}



	public String getPriority() {
		return priority;
	}



	public void setPriority(String priority) {
		this.priority = priority;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getDistrict() {
		return district;
	}



	public void setDistrict(String district) {
		this.district = district;
	}



	@Override
	public String toString() {
		return "Events [sno=" + sno + ", eventid=" + eventid + ", createdAt=" + createdAt + ", infotype=" + infotype
				+ ", typeofinput=" + typeofinput + ", typeofincident=" + typeofincident + ", eventtype=" + eventtype
				+ ", subject=" + subject + ", description=" + description + ", latitude=" + latitude + ", longitude="
				+ longitude + ", informationsource=" + informationsource + ", priority=" + priority + ", state=" + state
				+ ", district=" + district + "]";
	}
	

	
	
}
