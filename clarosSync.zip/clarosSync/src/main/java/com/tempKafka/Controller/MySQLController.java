package com.tempKafka.Controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tempKafka.ElasticModel.CRPF_Theatres;
import com.tempKafka.ElasticModel.Crpf_processor;
import com.tempKafka.ElasticModel.IedBlasts_details;
import com.tempKafka.ElasticModelRepository.CRPF_DeploymentRepository;
import com.tempKafka.ElasticModelRepository.CRPF_Theatres_Repository;
import com.tempKafka.MultiThreadStructure.ThreadForDeploymentList;
import com.tempKafka.MultiThreadStructure.ThreadForUnitEventList;
import com.tempKafka.MySqlRepo.IedBlasts_details_Repository;
import com.tempKafka.MySqlRepo.PersonJRepo;
import com.tempKafka.MySqlRepo.PersonnelRepo;
import com.tempKafka.MySqlRepo.VillageRepo;
import com.tempKafka.MySqlRepo.EventsRepository.EventVictimJRepo;
import com.tempKafka.MySqlRepo.EventsRepository.EventsRepoJ;
import com.tempKafka.MySqlRepo.deploymentRepository.ArmsEquipmentRepository;
import com.tempKafka.MySqlRepo.deploymentRepository.Dep_um_food_details_Repo;
import com.tempKafka.MySqlRepo.deploymentRepository.DeploymentDetailsRepository;
import com.tempKafka.MySqlRepo.deploymentRepository.DeploymentRepository;
import com.tempKafka.MySqlRepo.deploymentRepository.EventArmsRepository;
import com.tempKafka.MySqlRepo.deploymentRepository.EventsUnitInvolvedRepository;
import com.tempKafka.MySqlRepo.deploymentRepository.crpf_locRepo;
import com.tempKafka.Repo.AlertRepo;
import com.tempKafka.Repo.ClarosUsersRepo;
import com.tempKafka.Repo.CrimeRepo;
import com.tempKafka.Repo.Sentt;
import com.tempKafka.dto.GeoPoint;
import com.tempKafka.dto.InformationDTO;
import com.tempKafka.elastic.ElasticService;
import com.tempKafka.model.Alerts;
import com.tempKafka.model.ClarosUsers;
import com.tempKafka.model.Crime;
import com.tempKafka.model.Sntt;
import com.tempKafka.modelMySql.PersonJ;
import com.tempKafka.modelMySql.Village;
import com.tempKafka.modelMySql.Events.EventVictim;
import com.tempKafka.modelMySql.Events.Events;
import com.tempKafka.modelMySql.deployment.Deployment;
import com.tempKafka.modelMySql.deployment.Event_arms_equipment;
import com.tempKafka.modelMySql.deployment.eventUnitInvolved;

@RestController
@RequestMapping("/clarosTwo")
public class MySQLController {

	@Autowired
	EventVictimJRepo eventVicRepo;
	@Autowired
	Sentt sntRepo;
	@Autowired
	CrimeRepo crimeRepo;
	@Autowired
	AlertRepo alertRepo;

	@Autowired
	PersonJRepo personJRepo;
	
	@Autowired
	EventsRepoJ eventsJRepo;
	
	@Autowired
	EventsUnitInvolvedRepository eventunitinvrepo;
	
	@Autowired
	crpf_locRepo crpfrepo;
	
	@Autowired
	CRPF_Theatres_Repository crpftheatresrepo;
	
	@Autowired
	DeploymentDetailsRepository depdetailsrepo;
	
	@Autowired
	DeploymentRepository deprepo;
	
	@Autowired
	Dep_um_food_details_Repo depfoodrepo;
	
	@Autowired
	EventArmsRepository evearmsrepo;
	
	@Autowired
	ArmsEquipmentRepository armsrepo;

	@Autowired
	PersonnelRepo personnelrep;
	

	@Autowired
	CRPF_DeploymentRepository crpfdeprepo;
	@Autowired
	IedBlasts_details_Repository iedelasticrepo;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");

	@DeleteMapping("/clearDB")
	public ResponseEntity<?> clearEDB() {
		sntRepo.deleteAll();
		return null;
		
	}

	public int createSignal(Events a, String name, String userid, Date date) {
		try {
			Sntt signal = new Sntt(null, a.getDescription(), a.getEventtype(), null, a.getCreatedAt(), date.getTime());

			signal.setUserNames(Arrays.asList(name));
			signal.setUserids(Arrays.asList(userid));

			System.out.println("Signal: " + sntRepo.save(signal).getId());
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		return 1;

	}

	public int createAlert(Events a, String name, Date date, String userid) {
		try {
			System.out.println("Alert");
			Alerts b = new Alerts("High", "DB", a.getDescription(), date, a.getCreatedAt(), date.getTime(),
					new ArrayList<>());
			b.setUsernames(Arrays.asList(name));
			b.setUserid(Arrays.asList(userid));
			b.setFileobjects(new ArrayList<>());
			b.setType(a.getEventtype());
			b.setGis(a.getLatitude() + ":" + a.getLongitude());
			if (a.getInformationsource() != null && a.getInformationsource().length() > 0)
				b.setSourceofalert(a.getInformationsource());
			b.setPriority(a.getPriority());
			System.out.println(alertRepo.save(b).getId());
			System.out.println("Alert: " + alertRepo.save(b).getId());
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		return 1;

	}

	public String getAlphaNumericString(int n) {

		// choose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";

		// create StringBuffer size of AlphaNumericString
		StringBuilder sb = new StringBuilder(n);

		for (int i = 0; i < n; i++) {

			// generate a random number between
			// 0 to AlphaNumericString variable length
			int index = (int) (AlphaNumericString.length() * Math.random());

			// add Character one by one in end of sb
			sb.append(AlphaNumericString.charAt(index));
		}

		return sb.toString();
	}

	@Autowired
	VillageRepo vmRepo;

	@PostMapping("/villageSyncRev")
	public ResponseEntity<?> villSync() {
		LocalDateTime fr = LocalDateTime.now();
		System.out.println("VillageHit");
		try {
			List<Village> findAll = vmRepo.findAll();
			int i=0;
			for (Village v : findAll) {
				GeoPoint location = new GeoPoint();
				if (v.getLat().length() > 0 && v.getLng().length() > 0) {
					Double lat = Double.parseDouble(v.getLat());
					Double lon = Double.parseDouble(v.getLng());
					if (lat < -90)
						lat = -90.0;
					if (lat > 90)
						lat = lat % 90;
					if (lon < -90)
						lon = -90.0;
					if (lon > 90)
						lon = lon % 90;

					if (lat >= -90 && lat <= 90 && lon >= -90 && lon <= 90) {
						location.setLat(lat);
						location.setLon(lon);
						System.out.println("loatlong" + lat + ":" + lon);
						// Parse the time string into a Date object
						Crime amapCrime = new Crime(location, String.valueOf(v.getVillageId()), v.getName(), v.getCreatedAt(), psDateS(v.getCreatedAt()),
								v.getDistrict(), v.getName(), "Village");
						crimeRepo.save(amapCrime);
						i++;
					}
				}

			}
			return new ResponseEntity<>(findAll.size()+":"+i+"\n"+fr+":"+LocalDateTime.now(), HttpStatus.OK);

		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(""+e.getMessage(), HttpStatus.OK);
		}
	}

	public String createUser(PersonJ a) {

		System.out.println("CreateUser");
		ClarosUsers cUser = new ClarosUsers(a.getName().replace(" ", "_"), a.getPid(), a.getAge());
		Optional<ClarosUsers> findByUserid = cUserRepo.findByUserid(a.getPid());
		if (findByUserid.isPresent()) {
			System.out.println("UserExist: " + a.getName() + ":" + a.getPid());
			return a.getPid();
		}

//		
		InformationDTO info = new InformationDTO(a.getName(), a.getGender(), a.getEyecolor(), a.getAddress(),
				"" + a.getAge(), "");
		cUser.setInformation(info);
		cUser.setDescription(cUser.getDescription() + ":" + "fatherName: " + a.getFatherName());
		String uId = cUserRepo.save(cUser).getUserid();
		System.out.println("cuserSave" + uId);
		return uId;

	}

	@Autowired
	ElasticService elasticService;

	public Date psDateS(String dateS) {
		Date date = new Date();
		try {
			boolean condition = dateS != null && ((dateS.contains("T") && dateS.length() <= 19) ||dateS.contains(" "));
			if (condition) {
				String[] split = dateS.split(":");
				if (split.length == 3) {
					dateS = dateS + ".000000";
				} else if (split.length == 2) {
					dateS = dateS + ":00.000000";
				} else if (split.length == 1) {
					dateS = dateS + ":00:00:00.000000";
				}
				date = sdf.parse(dateS.replace(" ", "T"));
			}
//				} else if (dateS.contains(" ")) {
//
//					String[] split = dateS.split(":");
//					if (split.length == 3)
//						dateS = dateS + ".000000";
//					else if (split.length == 2)
//						dateS = dateS + ":00.000000";
//					else if (split.length == 1)
//						dateS = dateS + ":00:00:00.000000";
//					date = sdf.parse(dateS.replace(" ", "T"));
//				}

		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return date;
	}

	@PostMapping("/syncUserRev")
	public ResponseEntity<?> syncUserRev() {
		int i = 0;
		try {
			List<PersonJ> findAllPerson = personJRepo.findAll();

			for (PersonJ personJ : findAllPerson) {
				String userid = createUser(personJ);
				i++;

			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return new ResponseEntity<>(i, HttpStatus.OK);
	}

	@PostMapping("/syncRevEvents")
	public ResponseEntity<?> eventsApiRev() {
		LocalDateTime fr = LocalDateTime.now();
		int signalCount = 0, crimeCount = 0;
		
		try {
			List<EventVictim> findAllEventVic = eventVicRepo.findAll();
			for (EventVictim eveC : findAllEventVic) {
				
				String district = eveC.getDistrict();
				String username = eveC.getName();
				String userid = null;
				
				List<PersonJ> findAllPerson = personJRepo.findByName(username);
				
				for (PersonJ personJ : findAllPerson) {
					userid = createUser(personJ);
					String pid1 = personJ.getPid();
					String fatherName = personJ.getFatherName();

					if (fatherName == null || fatherName.length() == 0)
						fatherName = "nobody";
					
					List<PersonJ> findFirstByName = personJRepo.findByName(fatherName);
					
					for (PersonJ father : findFirstByName) {
						System.out.println("FatherFound" + fatherName);
						String pid2 = createUser(father);

						Optional<ClarosUsers> findById = cUserRepo.findByUserid(pid2);//
						
						if (findById.isPresent()) {
							System.out.println("addRelation: " + pid1 + ":" + pid2);
							addRelation(pid1, pid2);
						}
						break;
					}
					if (findFirstByName.size() == 0)
						System.err.println("FatherNotFound" + fatherName);
					break;
				}
				List<Events> eventOpt = eventsJRepo.findByEventid(eveC.getEventid());

				for (Events eventP : eventOpt) {
					//

					Date date = new Date();
					String dateS = eventP.getCreatedAt();

					if (eventP.getCreatedAt() != null) {
						date = psDateS(dateS);
					}

					String name = username;
					String description = eventP.getDescription();
					String eventtype = eventP.getEventtype();
					// Signal
					signalCount += createSignal(eventP, name, userid, date);
					// Alert
					crimeCount += createAlert(eventP, name, date, userid);
					if (eventP.getLatitude() != null && eventP.getLongitude() != null) {
						GeoPoint location = new GeoPoint();
						if (eventP.getLatitude().length() > 0 && eventP.getLongitude().length() > 0) {
							Double lat = Double.parseDouble(eventP.getLatitude());
							Double lon = Double.parseDouble(eventP.getLatitude());
							if (lat < -90) lat = -90.0;
							if (lat > 90)  lat = lat % 90;
							if (lon < -90) lon = -90.0;
							if (lon > 90)  lon = lon % 90;

							if (lat >= -90 && lat <= 90 && lon >= -90 && lon <= 90) {
								location.setLat(lat);
								location.setLon(lon);
								System.out.println("latlong" + lat + ":" + lon);
								// Parse the time string into a Date object
								Crime amapCrime = new Crime(location, userid, name, eventP.getCreatedAt(), date,
										district, description, eventtype);
								crimeRepo.save(amapCrime);
							}

						}

					}
				}

			}

			return new ResponseEntity<>(signalCount + ":" + crimeCount + "\n" + fr + ":" + LocalDateTime.now(),
					HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
	
	
	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------

	@PostMapping("/syncRevEvents2")
	public ResponseEntity<?> eventsApiRev2() {
		this.crpfdeprepo.deleteAll();
		
		LocalDateTime fr = LocalDateTime.now();
		int deploymentcount = 0;
		try {
				for(Events event : eventsJRepo.findAll() ) 
				{ 	
					Crpf_processor cp = new Crpf_processor();
					List<eventUnitInvolved> li1 = eventunitinvrepo.findByEventId(event.getEventid());
					List<Event_arms_equipment> li2 = evearmsrepo.findByEventId(event.getEventid());
					List<Deployment> li3  = deprepo.findByLatitude(event.getLatitude()).get();
					ThreadForDeploymentList T3 = new ThreadForDeploymentList(li3,cp);
					T3.start();
					Crpf_processor cprefrenced = T3.getCp();
					ThreadForUnitEventList T2 = new ThreadForUnitEventList(li2,li1,cprefrenced);
					T2.start();
					T2.join();
					T3.join();
					Date date = new Date();
					String dateS = event.getCreatedAt();
					if (event.getCreatedAt() != null) {
						date = psDateS(dateS);
					}
//					System.out.println(
//							cpd.getCoy() + " " +
//							cpd.getCoy_commander() + " "+
//							cpd.getDepStatus()
//							
//							);
//					cpd.setCompanyname("---------");
//					cpd.setDistrict(event.getDistrict());
//					cpd.setLocation(setlocation(event));
//					cpd.setTime(date);
//					cpd.setUnit_commander_name("-----");
//					cpd.setUnit_commander_rank("Commander");
//					
//					crpfdeprepo.save(cpd);
					}
			return new ResponseEntity<>(deploymentcount + ":" + "\n" + fr + ":" + LocalDateTime.now(),
					HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}
	
	@PostMapping("/CRPFTheatresStrength")
	public ResponseEntity<?> crpfstrength() {
		LocalDateTime fr = LocalDateTime.now();
		try {
			crpftheatresrepo.deleteAll();
			for(Events e : eventsJRepo.findAll()) {
				CRPF_Theatres crpftheatres = new CRPF_Theatres(e.getTheatre(), crpfrepo.findByEventId(e.getEventid()),setlocation(e));
				crpftheatresrepo.save(crpftheatres);
			}
			
			
		}catch (Exception e) {
			// TODO: handle exception
		}
		return new ResponseEntity<>(":" + "\n" + fr + ":" + LocalDateTime.now(),
				HttpStatus.OK);
	}
	
	@PostMapping("/IEDBlastsDetail")
	public ResponseEntity<?> iedblasts() {
		LocalDateTime fr = LocalDateTime.now();
		try {
			for(Events e : eventsJRepo.findAll()) {
				IedBlasts_details iedevent = new IedBlasts_details(null,e.getEventSubType(), e.getEventRelatedTo(), e.getSisterAgency(), e.getOrganization(), e.getOrgSubZone());
				iedelasticrepo.save(iedevent);
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return new ResponseEntity<>(":" + "\n" + fr + ":" + LocalDateTime.now(),
				HttpStatus.OK);
	}
//for(Deployment dep : deprepo.findAllByUnit(unit)) {
//	String depid = dep.getDepId();
//	
//	Deploymentdetails depdetails= depdetailsrepo.findByDepid(depid);
//	Dep_um_food_details depf = depfoodrepo.findByDepId(depid);
//	String coycommandername = depdetails.getCoycommander();
//		String Foodcategory = depf.getFoodCategory();
//		String recofficername = depf.getRecOfficerName();
//		String recofficerrank =depf.getRecOfficerRank();
//		String recofficeremail =depf.getRecOfficerEmail();
	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------

	private GeoPoint setlocation(Events event) {
		if (event.getLatitude() != null && event.getLongitude() != null) {
			GeoPoint location = new GeoPoint();
			if (event.getLatitude().length() > 0 && event.getLongitude().length() > 0) 
			{
				Double lat = Double.parseDouble(event.getLatitude());
				Double lon = Double.parseDouble(event.getLatitude());
				if (lat < -90) lat = -90.0;
				if (lat > 90)  lat = lat % 90;
				if (lon < -90) lon = -90.0;
				if (lon > 90)  lon = lon % 90;

				if (lat >= -90 && lat <= 90 && lon >= -90 && lon <= 90) {
					location.setLat(lat);    location.setLon(lon);
					System.out.println("latitude:longitude" + lat + ":" + lon);
					return location;
					// Parse the time string into a Date object
				}
			}
		}
		return null;
	}

	private Boolean fetchdetails(List<?>[] listobjects) {
		// TODO Auto-generated method stub
		return null;
	}

	private boolean addRelation(String pid1, String pid2) {
		String pids[] = {pid1,pid2};
		boolean flag = false;
		int i=1;
		System.out.println("addRelation");
		try {
			for(String pid : pids) {
				ClarosUsers userpid = cUserRepo.findByUserid(pid).get();
				Set<String> friendsID = new HashSet<>(userpid.getFriendsID());
				friendsID.add(pids[pids.length-i]);
				i++;
				userpid.setFriendsID(new ArrayList<>(friendsID));
				cUserRepo.save(userpid);
			}
// ElasticSearch USER Repo -- INDEXNAME = new_crime_user
//			ClarosUsers userP = cUserRepo.findByUserid(pid1).get();
//			Set<String> friendsID = new HashSet<>(userP.getFriendsID());
//			friendsID.add(pid2);
//			userP.setFriendsID(new ArrayList<>(friendsID));
//
//			ClarosUsers usert = cUserRepo.findByUserid(pid2).get();
//			
//			friendsID = new HashSet<>(usert.getFriendsID());
//			friendsID.add(pid1);
//			usert.setFriendsID(new ArrayList<>(friendsID));
//			cUserRepo.save(userP);
//			cUserRepo.save(usert);
		} catch (Exception e) {
			e.printStackTrace();
			flag = true;
		}

		if (flag) return false;
//			HashMap<String, Object> ans = null;
//			ans = new HashMap<>();
//			ans.put("message", "Success");
//			ans.put("dataSent", "");
		return true;
	}

//	
	public ResponseEntity<?> eventsApi3(String username, String userid) {
		try {
			System.out.println("event" + userid);
			List<EventVictim> findByusername = eventVicRepo.findByName(username);
			int signalCount = 0, crimeCount = 0;

			for (EventVictim eVic : findByusername) {
				System.out.println("eventfound" + userid);
				String eventId = eVic.getEventid();
				String district = eVic.getDistrict();

				List<Events> eventOpt = eventsJRepo.findByEventid(eventId);

				for (Events eventP : eventOpt) {
//

					Date date = new Date();
					String dateS = eventP.getCreatedAt();

					if (eventP.getCreatedAt() != null) {
						date = psDateS(dateS);
					}

					String name = username;
					String description = eventP.getDescription();
					// Signal
					signalCount += createSignal(eventP, name, userid, date);
					// Alert
					crimeCount += createAlert(eventP, name, date, userid);
					if (eventP.getLatitude() != null && eventP.getLongitude() != null) {
						GeoPoint location = new GeoPoint();
						if (eventP.getLatitude().length() > 0 && eventP.getLongitude().length() > 0) {
							Double lat = Double.parseDouble(eventP.getLatitude());
							Double lon = Double.parseDouble(eventP.getLatitude());
							if (lat >= -90 && lat <= 90) {
								location.setLat(Double.parseDouble(eventP.getLatitude()));
								location.setLon(Double.parseDouble(eventP.getLongitude()));
								System.out.println("loatlong" + location);
								// Parse the time string into a Date object
								Crime amapCrime = new Crime(location, userid, name, eventP.getCreatedAt(), date,
										district, description, null);
								crimeRepo.save(amapCrime);
							}

						}

					}
				}
			}
			//
			System.err.println("SignalCOunt: " + signalCount + ":crimeCount" + crimeCount);

			return new ResponseEntity<>(eventsJRepo.findFirst100ByOrderByCreatedAtDesc(), HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	@Autowired
	private ClarosUsersRepo cUserRepo;

	@GetMapping("/syncUser")
	public List<String> syncUsers() {
		List<PersonJ> findAllEvent = personJRepo.findAll();

		int i = findAllEvent.size();
		int counts = 0;
		List<String> dupUser = new ArrayList<>();
		int signalCount = 0;
		Map<String, String> topHundred = new HashMap<>();
		for (PersonJ a : findAllEvent) {
			System.out.println("personFor");
			topHundred.put(a.getName(), a.getPid());
			String userid = createUser(a);
			eventsApi3(a.getName(), userid);
			counts++;
			System.out.println("personend");
		}
		findAllEvent = personJRepo.findAll();
		i = findAllEvent.size() - i;
		dupUser.add("Changes: " + i);
		return dupUser;
	}

	@GetMapping("/syncEvents")
	public ResponseEntity<?> syncEventsApi() {
		List<Events> findAllEvent = eventsJRepo.findFirst100ByOrderByInfotype();
		List<Sntt> fans = new ArrayList<>();
		List<Crime> fcrime = new ArrayList<>();
		int i = 0, signalCount = 0, crimeCount = 0;
		for (Events a : findAllEvent) {
			i++;
			Optional<EventVictim> findById = eventVicRepo.findByEventid(a.getEventid());
			Date date = new Date();

			try {
				if (a.getCreatedAt() != null)
					date = sdf.parse(a.getCreatedAt().replace(" ", "T") + ".000000");
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			String name = null;
			String district = null;
			String description = a.getDescription();
			String userid = "";
			if (findById.isPresent()) {
				name = findById.get().getName();
				district = findById.get().getDistrict();
				// createUser
				Optional<PersonJ> person = personJRepo.findFirstByName(name);
				if (person.isPresent()) {
					// createUser
					userid = createUser(person.get());
					System.out.println(userid);
				}
			}
			// Signal
			signalCount += createSignal(a, name, userid, date);
			// Alert
			crimeCount += createAlert(a, name, date, userid);
			if (a.getLatitude() != null && a.getLongitude() != null) {
				GeoPoint location = new GeoPoint();
				if (a.getLatitude().length() > 0 && a.getLongitude().length() > 0) {
					location.setLat(Double.parseDouble(a.getLatitude()));
					location.setLon(Double.parseDouble(a.getLongitude()));
					System.out.println("loatlong" + location);
					// Parse the time string into a Date object
					Crime amapCrime = new Crime(location, userid, name, a.getCreatedAt(), date, district, description,
							null);
					crimeRepo.save(amapCrime);

				}

			}

			if (i == 10)
				break;
		}
		Map<String, Object> ans = new HashMap<>();
		ans.put("Signal", signalCount);
		ans.put("CrimeLocation", crimeCount);
//		sntRepo.saveAll(fans);
//		crimeRepo.saveAll(fcrime);
		return new ResponseEntity<>(ans, HttpStatus.OK);
	}
}
