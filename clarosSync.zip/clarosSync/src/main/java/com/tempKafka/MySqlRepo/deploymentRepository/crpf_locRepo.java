package com.tempKafka.MySqlRepo.deploymentRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.deployment.crpf_location;
import java.util.List;


public interface crpf_locRepo extends JpaRepository<crpf_location, Integer>{
	
	public crpf_location findByEventId(String eventId);
	


}
