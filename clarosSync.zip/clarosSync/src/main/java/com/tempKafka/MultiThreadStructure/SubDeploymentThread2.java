package com.tempKafka.MultiThreadStructure;

public class SubDeploymentThread2 extends Thread {
	


}
