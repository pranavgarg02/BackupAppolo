package com.tempKafka.Repo;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.tempKafka.model.Sntt;

public interface Sentt extends ElasticsearchRepository<Sntt,String>{

}
