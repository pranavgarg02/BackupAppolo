package com.tempKafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaTestProjecttApplicationTests {

	@Test
	void contextLoads() {
	}

}
