package com.tempKafka.MySqlRepo.deploymentRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.deployment.ArmsEquipments;

public interface ArmsEquipmentRepository extends JpaRepository<ArmsEquipments, Integer> {

//	public ArmsEquipments findByArmsEqptId(int armsEqptId);
	
	ArmsEquipments findByArmsEqptId(int armsEqptId);
}
