-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 3.7.32.64    Database: claros
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `status` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'Afghanistan',0),(2,'Albania',0),(3,'Algeria',1),(4,'Andorra',0),(5,'Angola',0),(6,'Antigua and Barbuda',1),(7,'Argentina',0),(8,'Armenia',0),(9,'Australia',1),(10,'Austria',0),(11,'Azerbaijan',0),(12,'Bahamas',1),(13,'Bahrain',0),(14,'Bangladesh',0),(15,'Barbados',1),(16,'Belarus',0),(17,'Belgium',0),(18,'Belize',1),(19,'Benin',0),(20,'Bhutan',0),(21,'Bolivia',1),(22,'Bosnia and Herzegovina',0),(23,'Botswana',0),(24,'Brazil',1),(25,'Brunei',0),(26,'Bulgaria',0),(27,'Burkina Faso',1),(28,'Burundi',0),(29,'Cabo Verde',0),(30,'Cambodia',1),(31,'Cameroon',0),(32,'Canada',0),(33,'Central African Republic',1),(34,'Chad',0),(35,'Chile',0),(36,'China',1),(37,'Colombia',0),(38,'Comoros',0),(39,'Congo, Democratic Republic of the',1),(40,'Congo, Republic of the',0),(41,'Costa Rica',0),(42,'Croatia',1),(43,'Cuba',0),(44,'Cyprus',0),(45,'Czech Republic',1),(46,'Denmark',0),(47,'Djibouti',0),(48,'Dominica',1),(49,'Dominican Republic',0),(50,'Ecuador',0),(51,'Egypt',1),(52,'El Salvador',0),(53,'Equatorial Guinea',0),(54,'Eritrea',1),(55,'Estonia',0),(56,'Eswatini',0),(57,'Ethiopia',1),(58,'Fiji',0),(59,'Finland',0),(60,'France',1),(61,'Gabon',0),(62,'Gambia',0),(63,'Georgia',1),(64,'Germany',0),(65,'Ghana',0),(66,'Greece',1),(67,'Grenada',0),(68,'Guatemala',0),(69,'Guinea',1),(70,'Guinea-Bissau',0),(71,'Guyana',0),(72,'Haiti',1),(73,'Honduras',0),(74,'Hungary',0),(75,'Iceland',1),(76,'India',0),(77,'Indonesia',0),(78,'Iran',1),(79,'Iraq',0),(80,'Ireland',0),(81,'Israel',1),(82,'Italy',0),(83,'Jamaica',0),(84,'Japan',1),(85,'Jordan',0),(86,'Kazakhstan',0),(87,'Kenya',1),(88,'Kiribati',0),(89,'Korea, North',0),(90,'Korea, South',1),(91,'Kosovo',0),(92,'Kuwait',0),(93,'Kyrgyzstan',1),(94,'Laos',0),(95,'Latvia',0),(96,'Lebanon',1),(97,'Lesotho',0),(98,'Liberia',0),(99,'Libya',1);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-10 15:26:52
