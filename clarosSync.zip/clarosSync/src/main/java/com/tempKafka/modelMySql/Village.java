package com.tempKafka.modelMySql;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import javax.persistence.Id;

@Entity
@Table(name = "village")
public class Village {

	@Id
	@Column(name = "sno")
	private int villageId;
	
	private String district;
	@Column(name = "village")
	private String name;
	private String state;
	private String lat;
	private String lng;
	@Column(name = "created_at")
	private String createdAt;

	public Village() {
		super();
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getLat() {
		return lat;
	}

	public void setLat(String lat) {
		this.lat = lat;
	}

	public String getLng() {
		return lng;
	}

	public void setLng(String lng) {
		this.lng = lng;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public int getVillageId() {
		return villageId;
	}

	public void setVillageId(int villageId) {
		this.villageId = villageId;
	}

	@Override
	public String toString() {
		return "Village [villageId=" + villageId + ", district=" + district + ", name=" + name + ", state=" + state
				+ ", lat=" + lat + ", lng=" + lng + ", createdAt=" + createdAt + "]";
	}

}