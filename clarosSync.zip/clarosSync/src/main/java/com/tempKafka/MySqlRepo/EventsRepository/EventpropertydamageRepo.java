package com.tempKafka.MySqlRepo.EventsRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.Events.Eventpropertydamage;

public interface EventpropertydamageRepo extends JpaRepository<Eventpropertydamage, Integer>{

}
