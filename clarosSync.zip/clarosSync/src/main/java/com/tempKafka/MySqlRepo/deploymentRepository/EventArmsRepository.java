package com.tempKafka.MySqlRepo.deploymentRepository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.deployment.Event_arms_equipment;
import java.util.List;


public interface EventArmsRepository extends JpaRepository<Event_arms_equipment, Integer> {
	
//	Optional<Event_arms_equipment> findByEventId(String eventid);
	
	List<Event_arms_equipment> findByEventId(String eventId);
	
}
