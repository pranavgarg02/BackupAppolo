package com.tempKafka.modelMySql.deployment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import javax.persistence.Id;

@Entity
@Table(name = "Deployment")
public class Deployment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int sno;
	
		@Column(name = "dep_id")
	    private String depId;
	    private String theatre;
	    private String dte;
	    private String zone;
	    private String unit;
	    private String latitude;
	    private String longitude;
	    private boolean viewed;
	    @Column(name="created_at")
	    private String createdAt;
		public int getSno() {
			return sno;
		}
		public void setSno(int sno) {
			this.sno = sno;
		}
		public String getDepId() {
			return depId;
		}
		public void setDepId(String depId) {
			this.depId = depId;
		}
		public String getTheatre() {
			return theatre;
		}
		public void setTheatre(String theatre) {
			this.theatre = theatre;
		}
		public String getDte() {
			return dte;
		}
		public void setDte(String dte) {
			this.dte = dte;
		}
		public String getZone() {
			return zone;
		}
		public void setZone(String zone) {
			this.zone = zone;
		}
		public String getUnit() {
			return unit;
		}
		public void setUnit(String unit) {
			this.unit = unit;
		}
		public String getLatitude() {
			return latitude;
		}
		public void setLatitude(String latitude) {
			this.latitude = latitude;
		}
		public String getLongitude() {
			return longitude;
		}
		public void setLongitude(String longitude) {
			this.longitude = longitude;
		}
		public boolean isViewed() {
			return viewed;
		}
		public void setViewed(boolean viewed) {
			this.viewed = viewed;
		}
		public String getCreatedAt() {
			return createdAt;
		}
		public void setCreatedAt(String createdAt) {
			this.createdAt = createdAt;
		}
		@Override
		public String toString() {
			return "Deployment [sno=" + sno + ", depId=" + depId + ", theatre="
					+ theatre + ", dte=" + dte + ", zone=" + zone + ", unit=" + unit + ", latitude=" + latitude
					+ ", longitude=" + longitude + ", viewed=" + viewed + ", createdAt=" + createdAt + "]";
		}
		public Deployment(int sno, String depId, String theatre, String dte, String zone, String unit, String latitude,
				String longitude, boolean viewed, String createdAt) {
			super();
			this.sno = sno;
			this.depId = depId;
			this.theatre = theatre;
			this.dte = dte;
			this.zone = zone;
			this.unit = unit;
			this.latitude = latitude;
			this.longitude = longitude;
			this.viewed = viewed;
			this.createdAt = createdAt;
		}
		public Deployment() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
		
	    
}
