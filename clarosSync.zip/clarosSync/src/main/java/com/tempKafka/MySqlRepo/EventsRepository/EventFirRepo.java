package com.tempKafka.MySqlRepo.EventsRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.Events.Eventfir;

public interface EventFirRepo extends JpaRepository<Eventfir, Integer>{

}
