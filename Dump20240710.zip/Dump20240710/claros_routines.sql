-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 3.7.32.64    Database: claros
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping events for database 'claros'
--

--
-- Dumping routines for database 'claros'
--
/*!50003 DROP PROCEDURE IF EXISTS `armseqpt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `armseqpt`()
BEGIN
DECLARE counter int default 1;
WHILE counter<20 DO
INSERT INTO arms_eqpt 
(arms_issued_irla, arms_eqpt_category, arms_eqpt_sub_category, arms_eqpt_type, 
 arms_eqpt_status, arms_eqpt_count, arms_eqpt_quantity, arms_eqpt_body_number, 
 arms_eqpt_details, created_by, created_by_unit, created_at, updated_by, updated_at)
SELECT 
concat("IRLA-0Ae#",FLOOR(RAND()*20)+1 ) as arms_issued_irla,
CASE (counter)%7
		WHEN 0 THEN "Assault Rifles (ARs)"
        WHEN 1 THEN "Sub Machine Guns (SMGs)"
        WHEN 2 THEN "ShotGuns"
        WHEN 3 THEN "Sniper Rifles"
        WHEN 4 THEN "Anti-Material Rifles "
        ELSE "Machine Guns" END as arms_eqpt_category,
concat("Cat-#S0 " , CHAR(65+ FLoor(RAND()*4)), FLOOR(RAND()*965)+765) as arms_eqpt_sub_category,
'' as arms_eqpt_type,
 CASE (FLOOR(RAND()*100) + 20)%5
		WHEN 0 THEN "Already Deployed and Active"
        WHEN 1 THEN "In Inventory"
        WHEN 2 THEN "Deployed and present in Inventory"
        WHEN 3 THEN "Ready for deployment"
        ELSE "Under Deployment and Inactive" END as arms_eqpt_status,
 (FLOOR(RAND()*1000) + 200) as arms_eqpt_count,
FLOOR(RAND()*1002020)+ 772327 as arms_eqpt_quantity,
concat("#B0Ae- " , CHAR(65+ FLoor(RAND()*24)),FLOOR(RAND()*87)*154389,CHAR(65+ FLoor(RAND()*24))) as arms_eqpt_body_number,
'Bullets 0.9mm and 7.62mm' as arms_eqpt_details,
(SELECT p.name FROM personnel p ORDER BY RAND() LIMIT 1) as created_by,
(SELECT p.unit FROM personnel p ORDER BY RAND() LIMIT 1) as created_by_unit,
DATE_ADD('2001-11-23', INTERVAL FLOOR(RAND() * 365) DAY) as created_at,
CASE (FLOOR(RAND()*100) + 20)%5
		WHEN 0 THEN "Deployed Security Force"
        WHEN 1 THEN "Survelliance Force"
        WHEN 2 THEN "AV-Zone Force"
        ELSE "UOM-Force" END as updated_by,
now() as updated_at;
set counter = counter +1;
END WHILE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `company_crpf` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `company_crpf`()
BEGIN
Declare counter int default 0;

WHILE counter<13 DO
INSERT INTO `claros`.`company`
(`sno`,`name`,`description`,`created_by`,`created_at`,`updated_by`,`updated_at`)
Select counter,
		CASE counter
		WHEN 0 THEN 'Bihar Regiment' WHEN 1 THEN 'Delhi Regiment' WHEN 2 THEN 'Assam Regiment'
        WHEN 3 THEN 'Mahar Regiment' When 4 then 'Madras Regiment' 
        WHEN 5 THEN "Dogra Regiment" WHEN 6 THEN "Jammu & Kashmir Regiment" 
        WHEN 7 THEN "The Grenadiers Regiment" WHEN 8 THEN "Jat Regiment" WHEN 9 THEN "Rapid Air Force"
        WHEN 10 THEN 'Mahilla Battalions' WHEN 11 THEN 'CoBRA'
        WHEN 12 THEN 'Parachute Regiment' END,
        "Details",
        CASE counter
        WHEN counter%3 THEN "System"
        WHEN counter%5 THEN "Manual"
        ELSE "Officer" END,
        DATE_ADD('1976-01-01', INTERVAL FLOOR(RAND() * 1065) DAY) , 
        '',
		DATE_ADD('2020-01-01', INTERVAL FLOOR(RAND() * 1065) DAY);
        set counter = counter+1;
END WHILE;
set counter =1;
WHILE counter<100 DO
INSERT INTO `claros`.`country`
(`id`,
`name`,
`status`)
        Select counter,
            CASE counter
                WHEN 1 THEN 'Afghanistan'
                WHEN 2 THEN 'Albania'
                WHEN 3 THEN 'Algeria'
                WHEN 4 THEN 'Andorra'
                WHEN 5 THEN 'Angola'
                WHEN 6 THEN 'Antigua and Barbuda'
                WHEN 7 THEN 'Argentina'
                WHEN 8 THEN 'Armenia'
                WHEN 9 THEN 'Australia'
                WHEN 10 THEN 'Austria'
                WHEN 11 THEN 'Azerbaijan'
                WHEN 12 THEN 'Bahamas'
                WHEN 13 THEN 'Bahrain'
                WHEN 14 THEN 'Bangladesh'
                WHEN 15 THEN 'Barbados'
                WHEN 16 THEN 'Belarus'
                WHEN 17 THEN 'Belgium'
                WHEN 18 THEN 'Belize'
                WHEN 19 THEN 'Benin'
                WHEN 20 THEN 'Bhutan'
                WHEN 21 THEN 'Bolivia'
                WHEN 22 THEN 'Bosnia and Herzegovina'
                WHEN 23 THEN 'Botswana'
                WHEN 24 THEN 'Brazil'
                WHEN 25 THEN 'Brunei'
                WHEN 26 THEN 'Bulgaria'
                WHEN 27 THEN 'Burkina Faso'
                WHEN 28 THEN 'Burundi'
                WHEN 29 THEN 'Cabo Verde'
                WHEN 30 THEN 'Cambodia'
                WHEN 31 THEN 'Cameroon'
                WHEN 32 THEN 'Canada'
                WHEN 33 THEN 'Central African Republic'
                WHEN 34 THEN 'Chad'
                WHEN 35 THEN 'Chile'
                WHEN 36 THEN 'China'
                WHEN 37 THEN 'Colombia'
                WHEN 38 THEN 'Comoros'
                WHEN 39 THEN 'Congo, Democratic Republic of the'
                WHEN 40 THEN 'Congo, Republic of the'
                WHEN 41 THEN 'Costa Rica'
                WHEN 42 THEN 'Croatia'
                WHEN 43 THEN 'Cuba'
                WHEN 44 THEN 'Cyprus'
                WHEN 45 THEN 'Czech Republic'
                WHEN 46 THEN 'Denmark'
                WHEN 47 THEN 'Djibouti'
                WHEN 48 THEN 'Dominica'
                WHEN 49 THEN 'Dominican Republic'
                WHEN 50 THEN 'Ecuador'
                WHEN 51 THEN 'Egypt'
                WHEN 52 THEN 'El Salvador'
                WHEN 53 THEN 'Equatorial Guinea'
                WHEN 54 THEN 'Eritrea'
                WHEN 55 THEN 'Estonia'
                WHEN 56 THEN 'Eswatini'
                WHEN 57 THEN 'Ethiopia'
                WHEN 58 THEN 'Fiji'
                WHEN 59 THEN 'Finland'
                WHEN 60 THEN 'France'
                WHEN 61 THEN 'Gabon'
                WHEN 62 THEN 'Gambia'
                WHEN 63 THEN 'Georgia'
                WHEN 64 THEN 'Germany'
                WHEN 65 THEN 'Ghana'
                WHEN 66 THEN 'Greece'
                WHEN 67 THEN 'Grenada'
                WHEN 68 THEN 'Guatemala'
                WHEN 69 THEN 'Guinea'
                WHEN 70 THEN 'Guinea-Bissau'
                WHEN 71 THEN 'Guyana'
                WHEN 72 THEN 'Haiti'
                WHEN 73 THEN 'Honduras'
                WHEN 74 THEN 'Hungary'
                WHEN 75 THEN 'Iceland'
                WHEN 76 THEN 'India'
                WHEN 77 THEN 'Indonesia'
                WHEN 78 THEN 'Iran'
                WHEN 79 THEN 'Iraq'
                WHEN 80 THEN 'Ireland'
                WHEN 81 THEN 'Israel'
                WHEN 82 THEN 'Italy'
                WHEN 83 THEN 'Jamaica'
                WHEN 84 THEN 'Japan'
                WHEN 85 THEN 'Jordan'
                WHEN 86 THEN 'Kazakhstan'
                WHEN 87 THEN 'Kenya'
                WHEN 88 THEN 'Kiribati'
                WHEN 89 THEN 'Korea, North'
                WHEN 90 THEN 'Korea, South'
                WHEN 91 THEN 'Kosovo'
                WHEN 92 THEN 'Kuwait'
                WHEN 93 THEN 'Kyrgyzstan'
                WHEN 94 THEN 'Laos'
                WHEN 95 THEN 'Latvia'
                WHEN 96 THEN 'Lebanon'
                WHEN 97 THEN 'Lesotho'
                WHEN 98 THEN 'Liberia'
                WHEN 99 THEN 'Libya'
                WHEN 100 THEN 'Liechtenstein'
                ELSE 'Unknown'END,
                CASE counter%3
                WHEN 0 THEN 1
                Else 0 END;
                set counter=counter+1;
END WHILE;
INSERT INTO `claros`.`crpf_location`
(`id`,`event_id`,`location`,`lat`,`log`,`company`)
Select
e.sno,
e.event_id,
concat(e.state,"",e.district),
e.latitude,
e.longitude,
(Select x.name from company x ORDER BY RAND() LIMIT 1) from events e;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `deployment` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `deployment`()
BEGIN
DECLARE counter INT DEFAULT 1;
DECLARE done INT DEFAULT FALSE;
DECLARE x VARCHAR(50);
DECLARE y VARCHAR(50);

 DECLARE column1_value VARCHAR(255); -- Change data type as needed
    DECLARE column2_value VARCHAR(255); -- Change data type as needed

    -- Declare cursor
    DECLARE cur CURSOR FOR SELECT state, district FROM events;
    
    -- Declare handler for end of cursor
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- Open cursor
    OPEN cur;

    -- Loop to fetch each row
    read_loop: LOOP
        FETCH cur INTO column1_value, column2_value;
        
        IF done THEN
            LEAVE read_loop;
        END IF;
 set x = (Select e.zone from village e ORDER BY RAND() LIMIT 1);
 set y = (Select e.district from events e ORDER BY RAND() LIMIT 1);
	INSERT INTO `claros`.`deployment`
(`sno`,`dep_id`,`theatre`,`dte`,`zone`,`sector`,
`range`,`unit`,`latitude`,`longitude`,`place`,`nature_of_duty`,
`viewed`,`created_at`,`created_by`,`updated_at`,`updated_by`)
Select 
counter,
concat("DEP#00",counter),
(Select e.theatre from events e ORDER BY RAND() LIMIT 1),
concat("Dte-",counter,CHAR(65 + counter%26)),
(Select e.zone from village e where e.zone = x LIMIT 1),
(Select e.sector  from village e where e.zone = x LIMIT 1),
(Select e.`range`  from village e where e.zone = x LIMIT 1),
(Select e.unit from event_unitinvolved e ORDER BY RAND() LIMIT 1),
(Select e.`latitude`  from events e where e.district =column2_value LIMIT 1), 
(Select e.`longitude`  from events e where e.district =column2_value LIMIT 1),
concat(column1_value," , ",column2_value)  ,
CASE counter%(FLOOR(RAND()*8)+2)
WHEN 0 THEN "Unknown Nature"
ELSE concat('Nature ',CHAR(65 +FLOOR(RAND()*8)+2)) END,
CASE counter%3 
WHEN 0 THEN 1
ELSE 0 END,
 DATE_ADD('2002-01-01', INTERVAL FLOOR(RAND() * 3265) DAY), 
 '',
 now(),
 '';
 set counter = counter + 1;
      END LOOP;

    -- Close cursor
    CLOSE cur;
-- -------------------------------------------------------------------------------------------------------
-- -------------------------------------------------------------------------------------------------------

INSERT INTO claros.dep_deployed (
	sno, dep_id, row_order, 
    ops_jurisdiction, date_from, date_to, order_no, order_date, 
    remark, place_location, latitude, 
    longitude, state, district, police_station, 
    res_state, res_district, date_time_from, date_time_to, 
    nature_of_duty, static_guard, vip_security, created_at, created_by, updated_at, 
    updated_by, sub_dep_id) 
   Select 
    d.sno,d.dep_id, d.sno%20, 
    concat("ops_jurisdiction",CHAR(65 + counter%26)), 
    DATE_ADD('2020-01-01', INTERVAL FLOOR(RAND() * 365) DAY), 
    DATE_ADD('2021-05-06', INTERVAL FLOOR(RAND() * 365) DAY), 
    concat("Ord-ID ",d.sno), 
    DATE_ADD('2022-01-01', INTERVAL FLOOR(RAND() * 365) DAY), 
    'Remarks-R12deAfSx', 
	d.place, 
	d.latitude, 
    d.longitude, 
    (Select e.state from village e where e.state like concat("%",LEFT(d.place,3),"%") LIMIT 1), 
    (Select e.district from village e where e.state like concat("%",LEFT(d.place,3),"%") LIMIT 1), 
    (Select e.police_station from village e where e.state like concat("%",LEFT(d.place,3),"%") LIMIT 1), 
    '', 
    '', 
    now(), 
    current_timestamp,
   d.nature_of_duty, 
    concat("Static Guard -",CHAR(FLOOR(RAND()*26)+65)),
    concat("VIP ",CHAR(FLOOR(RAND()*5)+85)) , 
    d.created_at, 
    d.created_by,
    d.updated_at, 
    '', 
    concat("SDEP-000",d.dep_id) from deployment d;
    
    
    INSERT INTO claros.dep_um_food_details(
    sno, dep_id, sub_dep_id, row_id, proposed_food_halt_irctc, 
    food_category, actual_halt_food_was_provided, no_of_food_packets_demanded, 
    reports, remark, rec_officer_force_no, rec_officer_name, 
    rec_officer_rank, rec_officer_unit, rec_officer_phone, rec_officer_email
) Select 
  d.sno, 
    d.dep_id AS dep_id,
    d.sub_dep_id AS sub_dep_id,
   concat("rowid@-",d.row_order) AS row_id,
     CONCAT("proposed_food_halt_irctc-", 
           CHAR(FLOOR(RAND() * 26) + 65), 
           CHAR(FLOOR(RAND() * 26) + 65), 
           FLOOR(RAND() * 9000 + 1000)) AS proposed_food_halt_irctc, 
    CONCAT("Food Category FC#: ", CHAR(65 + counter % 5)) AS food_category,
    CONCAT("actual_halt_food_was_provided-", 
           CHAR(FLOOR(RAND() * 26) + 65), 
           CHAR(FLOOR(RAND() * 26) + 65), 
           FLOOR(RAND() * 9000 + 1000)) AS actual_halt_food_was_provided,
    (d.sno * 230) % 300 AS no_of_food_packets_demanded,
    '' AS reports,
    'Remarks-R12deAfSx' AS remark,
   concat("RF-", FLOOR(RAND() * 9000 + 1000)) AS rec_officer_force_no,
    concat(
		CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Sg.' WHEN 1 THEN 'Hg.' WHEN 2 THEN 'Rg.'
        ELSE 'Fg.' END," ",
		CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Luxedo' WHEN 1 THEN 'Minsube' WHEN 2 THEN 'Bishtori'
        WHEN 3 THEN 'Rishkula' When 4 then 'Mannhaur' ELSE 'Samson' END," ",
        CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'ferrosko' WHEN 1 THEN 'Lubia' WHEN 2 THEN 'Alex'
        WHEN 3 THEN 'Frixido' When 4 then 'Nirankar' ELSE 'Extorio' END) AS rec_officer_name,
    x  AS rec_officer_rank,
    (Select p.`unit` from personnel p where p.`rank` = x)  AS rec_officer_unit,
      CONCAT(FLOOR(100 + RAND() * 900), FLOOR(100 + RAND() * 900),FLOOR(1000 + RAND() * 9000) ) AS rec_officer_phone,
    concat('rec_',(Select p.`rank` from personnel p ORDER BY -1 LIMIT 1),FLOOR(RAND()*200) ,'@example.com') AS rec_officer_email
    from dep_deployed d where x = (Select p.`rank` from personnel p ORDER BY RAND() LIMIT 1);

    
    INSERT INTO claros.dep_details (
    sno ,dep_id, row_order, coy, coy_commander, nature_of_duty, coy_commander_mob, 
    platoon, section, halfsection, is_halfsection, place_location, latitude, 
    longitude, state, district, police_station, available_strength, available_go, 
    available_so, available_or, dep_status, dep_sub_status, created_at, created_by, 
    updated_at, updated_by
) Select
		d.sno, 
        d.dep_id, 
        d.row_order, 
		concat(CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'ferrosko' WHEN 1 THEN 'Lubia' WHEN 2 THEN 'Alex'
        WHEN 3 THEN 'Frixido' When 4 then 'Nirankar' ELSE 'Extorio' END
		,' Coy'), 
        concat(
		CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Luxedo' WHEN 1 THEN 'Minsube' WHEN 2 THEN 'Bishtori'
        WHEN 3 THEN 'Rishkula' When 4 then 'Mannhaur' ELSE 'Samson' END," ",
        CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'ferrosko' WHEN 1 THEN 'Lubia' WHEN 2 THEN 'Alex'
        WHEN 3 THEN 'Frixido' When 4 then 'Nirankar' ELSE 'Extorio' END), 
        d.nature_of_duty, 
		CONCAT(FLOOR(100 + RAND() * 900), FLOOR(100 + RAND() * 900),FLOOR(1000 + RAND() * 9000) ), 
		concat("pl-xAefd ",CHAR((FLOOR(RAND()*100))%6+65)), 
		concat("Sec-",300+ FLOOR(RAND()*100)," ",CHAR((FLOOR(RAND()*100))%6+65)), 
		concat("Half-sec ",CHAR((FLOOR(RAND()*100))%6+65)), 
    CASE (FLOOR(RAND()*100))%6
    WHEN 0 THEN "Yes"
    ELSE "No" END , 
		d.place_location, 
		d.latitude, 
		d.longitude, 
		d.state, 
        d.district, 
		d.police_station, 
		"100%", 
		"(100-x) %", 
		"((100-x)-y) %", 
		"Remaining z%", 
    CASE (FLOOR(RAND()*100))%6
    WHEN 0 THEN "Deployed"
    WHEN 1 THEN "Not Ready For Deployment"
    WHEN 2 THEN "Pending"
    WHEN 3 THEN "Completed & Ready for Deployment"
    ELSE "In Deployement" 
    END , 
		concat("From ", 83.5 +(Floor(RAND()*20) +1), "% to ", 84.5 +(Floor(RAND()*10) +1),"%"), 
		d.created_at, 
		d.created_by, 
		d.updated_at, 
		'' 
        from dep_deployed d;
    
    INSERT INTO claros.dep_nature_of_deployment(
    `sno`,`dep_id`,`sub_dep_id`,`duty_type`,
    `prepoll_duty`,`during_poll_duty`,
	`post_poll_duty`,`date_time_from`,`date_time_to`,`created_at`,`created_by`)
	Select
	d.sno , d.dep_id,
    d.sub_dep_id,
	concat("D-Type ",CHAR(FLOOR(RAND()*25)+65)),concat("Prepoll D-Type ",CHAR(FLOOR(RAND()*25)+65)),
	" * * ",
    concat("PostPoll D-Type",CHAR(FLOOR(RAND()*25)+65)),
    DATE_ADD('2022-01-01', INTERVAL FLOOR(RAND() * 365) DAY) , 
	DATE_ADD('2023-05-06', INTERVAL FLOOR(RAND() * 365) DAY),
    d.created_at,d.created_by from dep_deployed d;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `dep_food` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `dep_food`()
BEGIN
DECLARE x varchar(50);
INSERT INTO claros.dep_um_food_details(
    sno, dep_id, sub_dep_id, row_id, proposed_food_halt_irctc, 
    food_category, actual_halt_food_was_provided, no_of_food_packets_demanded, 
    reports, remark, rec_officer_force_no, rec_officer_name, 
    rec_officer_rank, rec_officer_unit, rec_officer_phone, rec_officer_email
) Select 
  d.sno, 
    d.dep_id AS dep_id,
    d.sub_dep_id AS sub_dep_id,
   concat("rowid@-",d.row_order) AS row_id,
     CONCAT("proposed_food_halt_irctc-", 
           CHAR(FLOOR(RAND() * 26) + 65), 
           CHAR(FLOOR(RAND() * 26) + 65), 
           FLOOR(RAND() * 9000 + 1000)) AS proposed_food_halt_irctc, 
    CONCAT("Food Category FC#: ", CHAR(65 + FLOOR(RAND() * 26) % 5)) AS food_category,
    CONCAT("actual_halt_food_was_provided-", 
           CHAR(FLOOR(RAND() * 26) + 65), 
           CHAR(FLOOR(RAND() * 26) + 65), 
           FLOOR(RAND() * 9000 + 1000)) AS actual_halt_food_was_provided,
    (d.sno * 230) % 300 AS no_of_food_packets_demanded,
    '' AS reports,
    'Remarks-R12deAfSx' AS remark,
   concat("RF-", FLOOR(RAND() * 9000 + 1000)) AS rec_officer_force_no,
    concat(
		CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Sg.' WHEN 1 THEN 'Hg.' WHEN 2 THEN 'Rg.'
        ELSE 'Fg.' END," ",
		CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Luxedo' WHEN 1 THEN 'Minsube' WHEN 2 THEN 'Bishtori'
        WHEN 3 THEN 'Rishkula' When 4 then 'Mannhaur' ELSE 'Samson' END," ",
        CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'ferrosko' WHEN 1 THEN 'Lubia' WHEN 2 THEN 'Alex'
        WHEN 3 THEN 'Frixido' When 4 then 'Nirankar' ELSE 'Extorio' END) AS rec_officer_name,
    x  AS rec_officer_rank,
    (Select p.`unit` from personnel p where p.`rank` = x)  AS rec_officer_unit,
      CONCAT(FLOOR(100 + RAND() * 900), FLOOR(100 + RAND() * 900),FLOOR(1000 + RAND() * 9000) ) AS rec_officer_phone,
    concat('rec_',(Select p.`rank` from personnel p ORDER BY -1 LIMIT 1),FLOOR(RAND()*200) ,'@example.com') AS rec_officer_email
    from dep_deployed d where x = (Select p.`rank` from personnel p ORDER BY RAND() LIMIT 1);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `eventUnitInvolved` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `eventUnitInvolved`()
BEGIN
DECLARE x varchar(50);
INSERT INTO `claros`.`event_unitinvolved`
(`sno`,
`event_id`,
`party_id`,
`unit`,
`company`,
`unit_control_room_no`,
`irla_force_no`,
`commander_name`,
`commander_rank`,
`commander_mobile_no`,
`strength_of_party`,
`created_at`,
`created_by`,
`updated_at`,
`updated_by`)
SELECT 
e.sno,
e.event_id,
e.party_id,
e.created_by_unit,
(Select c.name from company c order by RAND() LIMIT 1),
FLOOR(100+RAND()*200),
concat("F-irla#",e.sno),
(Select p.name from personnel p ORDER BY RAND() LIMIT 1),
'','',
'',
e.created_at,
e.created_by,
e.updated_at,
e.updated_by from events e;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `eventvictim` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `eventvictim`()
BEGIN
INSERT INTO `claros`.`eventvictim`
(`sno`,
`event_id`,
`victim_type`,
`victim_irla`,
`victim_rank`,
`victim_unit`,
`victim_doj`,
`name`,
`gender`,
`isdeadorinjured`,
`is_medical_aid_provided`,
`is_dead_body_disposed`,
`maritalstatus`,
`reason`,
`religion`,
`nationality`,
`occupation`,
`dob`,
`fathername`,
`victim_financial_assistance`,
`victim_financial_assistance_value`,
`victim_nok`,
`victim_post_mortem`,
`nickname`,
`contact`,
`compensationpaid`,
`details`,
`remarks`,
`createdby`,
`created_at`,
`updatedby`,
`updated_at`)
Select e.sno%300,
e.event_id , 
concat(e.eventtype , "-victim"),
e.event_irla_number,
'',
e.created_by_unit,
'',
(Select p.name from personnel p ORDER BY RAND() LIMIT 1),
             CASE WHEN (FLOOR(RAND()*20 + 1) % 6) = 0 THEN "MALE" ELSE "FEMALE" END,
              case e.eventtype
        WHEN e.eventtype = 'PropertyDamage' OR e.eventtype = "FIR" THEN 'Injured' 
        WHEN 'IED' THEN "DEAD" END,
             '',
              CASE WHEN (FLOOR(RAND()*20 + 1) % 6) = 0 THEN "YES" ELSE "NO" END,
              CASE WHEN (FLOOR(RAND()*20 + 1) % 6) = 0 THEN "SINGLE" ELSE "MARRIED" END,
              '',
               (SELECT v.religion FROM village_other_information v ORDER BY RAND() LIMIT 1),
               'INDIAN',
                Case (FLOOR(RAND()*20 + 1) % 6)
       WHEN 0 THEN 'BusinessMan' WHEN 1 THEN 'Service Employee' WHEN 2 THEN 'Shopkeeper'
        WHEN 3 THEN 'Vendor and Dealer' When 4 then 'Broker' ELSE 'Labour/Mechanic' END,
        '',
        '',
        case e.eventtype
        WHEN 'PropertyDamage' THEN 'Yes Provided in terms of money' 
        WHEN 'IED' THEN "Compensation provided" 
        ELSE 'No Assistance provided' END,
        case e.eventtype
        WHEN 'PropertyDamage' THEN concat(10+ RAND()*15," Lakh by government") 
        WHEN 'IED' THEN concat(1+ RAND()*5," Lakh") 
        ELSE 'No financial assistance' END,
        '',
        '',
        Case (FLOOR(RAND()*20 + 1) % 13)
		WHEN 0 THEN 'Gullu' WHEN 1 THEN 'Babloo' WHEN 2 THEN 'Raamu'
        WHEN 3 THEN 'Laado' When 4 then 'Dholu' ELSE null END,
        '',
        '',
        '',
        '' ,
        e.created_by ,
        e.created_at,
        e.updated_by ,
        e.updated_at from events e ORDER BY 1 LIMIT 150;
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `event_arms_eqpt` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `event_arms_eqpt`()
BEGIN
INSERT INTO `claros`.`event_arms_eqpt`
(`sno`,
`event_id`,
`arms_eqpt_id`,
`remarks`,
`createdby`,
`created_at`,
`updatedby`,
`updated_at`)
SELECT e.sno,
e.event_id,
(Select arms_eqpt_id from arms_eqpt order by rand() LIMIT 1),
(Select concat(arms_eqpt_category,' ',arms_eqpt_type) from arms_eqpt order by rand() LIMIT 1),
e.created_by,
e.created_at,
e.updated_by,
e.updated_at from events e;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `fir` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `fir`()
BEGIN

-- UPDATE `claros`.`fir`
-- SET
-- `ionumber` = CONCAT("IO-", 113 * 5656533)
-- WHERE `ioname` = 'SHO Mr. Jayant Khanna';
-- SELECT * FROM fir;


INSERT INTO `claros`.`fir`
(
    `fir_id`,
    `firnumber`,
    `firdate`,
    `undersection`,
    `description`,
    `ioname`,
    `ionumber`,
    `status`,
    `firplace`,
    `policestation`,
    `pos_state`,
    `pos_district`,
    `typeofcrime`,
    `warrented_name`,
    `warrented_age`,
    `warrented_cast`,
    `warrented_father`,
    `warrented_issue_date`,
    `warrented_ration`,
    `warrented_address`,
    `createdby`,
    `fir_copy`,
    `viewed`,
    `created_at`,
    `updatedby`,
    `created_by_unit`,
    `updated_at`
)
SELECT 
    RIGHT(e.fir_id, 3) + FLOOR(RAND()*208809),  -- fir_id
    e.fir_id,  -- firnumber
    e.created_at,  -- firdate
    CONCAT("Sec-", CHAR(FLOOR(RAND() * 25 + 65)), FLOOR(RAND() * 200) + 100),  -- undersection
    "Description of the crime",  -- description
    concat(
		CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Off. Mr.' WHEN 1 THEN 'IPS Mr.' WHEN 2 THEN 'DPS Mr.'
        WHEN 3 THEN 'SHO Mr.' When 4 then 'Const. Mr.' ELSE 'IG Mr.' END," ",
		CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Jayant' WHEN 1 THEN 'Dhirendra' WHEN 2 THEN 'Mayank'
        WHEN 3 THEN 'Harshit' When 4 then 'JaiRaj' ELSE 'Atiksh' END," ",
        CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'Malhotra' WHEN 1 THEN 'Khanna' WHEN 2 THEN 'Singh'
        WHEN 3 THEN 'Kumar' When 4 then 'Bishnoi' ELSE 'Gupta' END) ,  -- ioname
    '',  -- ionumber
    CASE (FLOOR(RAND()*200))%FLOOR(RAND()*4 + 1)
		WHEN 0 THEN 'Pending' WHEN 1 THEN 'Case Handled' WHEN 2 THEN 'In process' ELSE "Completed"END,  -- status
    (Select concat(ei.state,", ",ei.district) from events ei where ei.event_id = e.event_id),  -- firplace
   (Select ei.police_station from events ei where ei.event_id = e.event_id),  -- policestation
    (Select ei.state from events ei where ei.event_id = e.event_id),  -- pos_state
    (Select ei.district from events ei where ei.event_id = e.event_id),  -- pos_district
    (Select ei.typeofincident from events ei where ei.event_id = e.event_id),  -- typeofcrime
   concat(CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Jayant' WHEN 1 THEN 'Jamul' WHEN 2 THEN 'Abhay'
        WHEN 3 THEN 'Harshit' When 4 then 'Kamal' ELSE 'Atiksh' END," ",
        CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'Malhotra' WHEN 1 THEN 'Khan' WHEN 2 THEN 'Singh'
        WHEN 3 THEN 'Kumar' When 4 then 'Ahmed' ELSE 'Gupta' END ," ", FLOOR(RAND() * 20) ) ,
    FLOOR(RAND() * 40 + 20),  -- warrented_age (random age between 20 and 60)
    "Cast",  -- warrented_cast
    concat(CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Mannu' WHEN 1 THEN 'Babloo' WHEN 2 THEN 'Amit'
        WHEN 3 THEN 'Kishore' When 4 then 'Kamal' ELSE 'Akshit' END," ",
        CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'Malhotra' WHEN 1 THEN 'Khan' WHEN 2 THEN 'Singh'
        WHEN 3 THEN 'Raj' When 4 then 'Kumar' ELSE 'Gupta' END ," ", FLOOR(RAND()*20) ) ,  -- warrented_father
    NOW(),  -- warrented_issue_date
   CONCAT(
    CHAR(FLOOR(RAND() * 26) + 65), -- Random uppercase letter
    CHAR(FLOOR(RAND() * 26) + 65), -- Random uppercase letter
    FLOOR(RAND() * 900000 + 100000) -- Random 6-digit number
),  -- warrented_ration
    " ",  -- warrented_address
    e.createdby,  -- createdby
    "XXXXXXXXX",  -- fir_copy
    CASE FLOOR(RAND()*2)
    WHEN 0 or 1 THEN 1
    ELSE 0 END,  -- viewed (assuming it's an integer, defaulting to 0)
    e.created_at,  -- created_at
    " ",  -- updatedby
    (SELECT p.unit from personnel p ORDER BY RAND() LIMIT 1) as created_by_unit,  -- created_by_unit
    NOW()  -- updated_at
FROM eventfir e;

INSERT INTO `claros`.`firstatus`
(`sno`,
`fir_id`,
`status`,
`remarks`,
`createdby`,
`created_at`,
`updatedby`,
`updated_at`)
Select f.fir_id,
f.firnumber,
f.status,
'',
f.createdby,
f.created_at,
'',
f.updated_at from fir f;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `forpropertydamageevent` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `forpropertydamageevent`()
BEGIN
-- DECLARE counter INT 
-- WHILE counter <= 1000 DO
   INSERT INTO claros.eventpropertydamaged (sno, event_id, affected_type, property_type, description, 
   approxvalue, remarks, country, state, zipcode, address1, address2, 
   financial_assistance_value, financial_assistance, vehicle_number, name_of_driver, 
   force_no_of_driver, vehicle_type, vehicle_model, createdby, created_at, updatedby, updated_at) 
SELECT NULL AS sno, 
e.event_id AS event_id, 
CASE e.sno%5
		WHEN 0 THEN concat("Type APD-",e.sno%10)
        WHEN 1 THEN concat("Type BPD-",e.sno%15)
        WHEN 2 THEN concat("Type CPD-",e.sno%20)
        WHEN 3 THEN concat("Type DPD-",e.sno%33) 
        ELSE "Other Type" END  AS affected_type, 
CASE e.sno%8
		WHEN 0 THEN concat(e.sno%100," Acres Plot")
        WHEN 1 THEN concat(e.sno%5," BHK Residential Flat")
        WHEN 2 THEN concat(e.sno%1000," sq. yards area")
        ELSE "Shop Damage "END AS property_type, 
CASE e.sno%8
		WHEN 0 THEN "DAMAGE DUE TO CALAMITY/NATURAL DISASTER"
        WHEN 1 THEN "ACCIDENTAL CAUSE / DISASTER CAUSE"
        WHEN 2 THEN "FUEL/GAS BLASTING , OTHER HAPPENING "
        ELSE "Riots / Natural Disaster "END AS description, 
        CASE e.sno%8
        WHEN 1 THEN concat(16+FLOOR(RAND() * 10000) %45," Lakhs") 
        ELSE concat(16+FLOOR(RAND() * 10000) %45," Crores")  END AS approxvalue, 
"Heavy Damage" AS remarks, 
"INDIA" AS country, 
e.state AS state, 
(10000 + FLOOR(RAND() * 10000) *15) AS zipcode, 
concat(e.state," ",e.district," " ,"Street ",CHAR(65+FLOOR(RAND() * 10000) %26))  AS address1,
 "" AS address2, 
concat(3.5 + FLOOR(RAND() * 10000) %80,"% percent of damage")  AS financial_assistance_value, 
'' AS financial_assistance, 
concat( LEFT(e.state,2) ,e.sno%10," CX-",(FLOOR(RAND() * 10000)+1000) %1000) AS vehicle_number, 
CASE e.sno%7
		WHEN 0 THEN concat("Lallan Kumar -",e.sno%11)
        WHEN 1 THEN concat("Abhijeet Kaur",e.sno%12)
        WHEN 2 THEN concat("Pradyuman Lal",e.sno%18)
        WHEN 3 THEN concat("Biwas Bobbey",e.sno%19) 
        ELSE "Other Type" END AS name_of_driver, 
FLOOR(RAND() * 10000) *2454 AS force_no_of_driver, 
CASE e.sno%7
		WHEN 0 THEN concat("SUV to Compact SUV",e.sno%11)
        WHEN 1 THEN concat("Bus or Traveller",e.sno%12) 
        ELSE "Hatchback to Sedan" END AS vehicle_type, 
concat("VX-Model ",CHAR(69+FLOOR(RAND() * 10000) %11))  AS vehicle_model, 
e.created_by AS createdby, 
e.created_at AS created_at, 
e.updated_by AS updatedby, 
e.updated_at AS updated_at 
FROM events e
WHERE eventtype = 'PropertyDamage';

-- SET counter = counter + 1;
-- END WHILE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Insertevents` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `Insertevents`()
BEGIN
DECLARE counter INT DEFAULT 1;
DECLARE random_date DATETIME;
 WHILE counter <= 500 DO

   INSERT INTO claros.events (eventtype ,sno,event_id, event_irla_number, event_datetime, 
   infotype, reporttype, typeofincident,typeofinput,
   theatre, `subject`, state, district, police_station, 
   latitude, longitude, 
   description, remarks, viewed , 
   any_ops_launched,
   whether_event_based_on_any_opsplan, 
   ops_plan_id, 
   priority,
   party_id, 
   any_action_taken, 
   any_ir, 
   ir_id, 
   k9_id, 
   k9_name, 
   breed_of_k9, 
   k9_handler_f_no, 
   k9_handler_f_name, 
   k9_asst_handler_f_no, 
   k9_asst_handler_f_name, 
   input_shared, grade, 
   ready_to_approve, 
   ready_to_approve_date, is_approved,
   created_by_unit , created_by,
   created_at, updated_by , updated_at)

Select CASE counter%6
		WHEN 0 THEN "IED"
        WHEN 1 THEN "Insurgent"
        WHEN 2 THEN "FIR"
        WHEN 3 THEN "PropertyDamage"
        ELSE "Other Type" END as eventtype , 
counter*1988 as sno,
concat("EV-ID#",counter*1988), -- eventid
concat("IRLA-0",counter*1432), -- event_irla
DATE_ADD('2002-01-01', INTERVAL FLOOR(RAND() * 365) DAY) as event_datetime, 
concat("Information type " , CHAR(65+(FLOOR(RAND()*100) + 20)%6)), 
concat("Report type " , CHAR(65+(FLOOR(RAND()*100) + 20)%4) ,  CHAR(70+counter%5),  CHAR(75+(FLOOR(RAND()*100) + 20)%6)), 
 CASE counter%6
		WHEN 0 THEN "IED BLASTS / Explosive Blasts"
        WHEN 1 THEN "Insurgent/Illegal Migration"
        WHEN 2 THEN "Robbery / Crime Investigation"
        WHEN 3 THEN "Natural Disaster/Riots"
        ELSE "Unknown" END,
CASE (FLOOR(RAND()*100) + 20)%6
		WHEN 0 THEN "Manual"
        WHEN 4 THEN "System"
        ELSE "Reported Input" END,
concat("Theatre " , CHAR(65+(FLOOR(RAND()*100) + 20)%6)), 
CASE counter%6
		WHEN 0 THEN "Explosive blasts in city"
        WHEN 1 THEN "Insurgent Found"
        WHEN 2 THEN "Robbery / Murder in city"
        WHEN 3 THEN "Natural Disaster/Riots nearby city"
        ELSE "Unknown Subject" END, 
CASE counter%9
		WHEN 0 THEN "Mahrashtra"
        WHEN 1 THEN "Delhi"
        WHEN 2 THEN "Assam"
        WHEN 3 THEN "Meghalya"
        WHEN 4 THEN "Gujarat"
        WHEN 5 THEN "Karnatka"
        WHEN 6 THEN "Punjab"
        WHEN 7 THEN "Uttar Pradesh"
        ELSE "Kerela" END, 
concat("District " ,  CHAR(65+(FLOOR(RAND()*100) + 20)%13)), 
concat("P.S#D-" , CHAR(65+(FLOOR(RAND()*100) + 20)%13)," " , counter%17), 
(RAND() * 180 - 90) AS latitude,
(RAND() * 360 - 180) AS longitude,
concat('Detailed description of the event of ',
		CASE counter%6
		WHEN 0 THEN "Explosive blasts in city"
        WHEN 1 THEN "Insurgent Found"
        WHEN 2 THEN "Robbery / Murder in city"
        WHEN 3 THEN "Natural Disaster/Riots nearby city"
        ELSE "Unknown Subject" END
        ) as description, 
' ', 
CASE (FLOOR(RAND()*100) + 20)%4
		WHEN 0 THEN 1
        WHEN 1 THEN 0
        ELSE 0 END as viewed,
"",
CASE (FLOOR(RAND()*100) + 20)%4
		WHEN 0 THEN "YES"
        WHEN 1 THEN "NO"
        ELSE "MAYBE" END, 
CASE (FLOOR(RAND()*100) + 20)%6
		WHEN 0 THEN "Might"
        WHEN 1 THEN "No"
        ELSE "Yes" END, -- ##########################################
        CASE counter%6
		WHEN 0 THEN "Very High"
        WHEN 1 THEN "High"
        WHEN 2 THEN "Moderate"
        WHEN 3 THEN "Low"
        ELSE "Undefined" END,
concat("party-id#",counter),
        
CASE (FLOOR(RAND()*100) + 20)%4
		WHEN 0 THEN concat("Action Taken ",CHAR(65 + counter%3),CHAR(70 + counter%3))
        WHEN 1 THEN concat("Action Taken ",CHAR(70 + counter%3),CHAR(65 + counter%3))
        ELSE concat("Action Taken ",CHAR(75 + counter%3),"X") END, 
 CHAR(65 + counter%26), 
 concat("IR#00" , counter*1000), 
 concat("K9#01$" , counter*1000), 
 concat (CASE (FLOOR(RAND()*100) + 20)%6 WHEN 0 THEN "Jai " WHEN 1 THEN "Morico " WHEN 2 THEN "Xavier "
		WHEN 3 THEN "Cham Cham "  ELSE "Madurai " END,
        CASE counter%4
		WHEN 0 THEN "Radhey"
        WHEN 1 THEN "Xender"
        WHEN 2 THEN "Rocky"
        ELSE "Swami" END), 
 concat("Breed " ,  CHAR(65+(FLOOR(RAND()*100) + 20)%6)), 
 concat("File-F00" , counter*132), 
 CASE counter%8
		WHEN 0 THEN "Duxedo Miller"
        WHEN 1 THEN "Alex Rana"
        WHEN 2 THEN "Ciago Chicixo"
        WHEN 3 THEN "Rendico Mauriti"
        WHEN 4 THEN "Daulat Rai Chand"
        WHEN 5 THEN "Amisha Patil" 
        ELSE "Mariyam Iqbal" END, 
 concat("F-F00" , counter%17,counter),
  CASE (FLOOR(RAND()*100) + 20)%8
		WHEN 0 THEN concat("As A#",counter%17)
        WHEN 1 THEN concat("As B#",counter%13)
        WHEN 2 THEN concat("As C#",counter%11)
       ELSE concat("As D#",counter%23) END, 
 CHAR(counter%26 + 65), 
 CASE (FLOOR(RAND()*100) + 20)%3
		WHEN 0 THEN concat("Grade ",CHAR(65 + counter%6))
        WHEN 1 THEN concat("Grade ",CHAR(68 + counter%7))
        WHEN 2 THEN concat("Grade ",CHAR(69 + counter%8)) END,
 CASE (FLOOR(RAND()*100) + 20)%3
		WHEN 0 THEN 'Y'
        WHEN 1 THEN 'N'
        WHEN 2 THEN 'X' END ,
 DATE_ADD('2014-11-01', INTERVAL FLOOR(RAND() * 2975) DAY), 
 CASE counter%3
		WHEN 0 THEN 1
        WHEN 1 THEN 0
        ELSE 0 END, 
 (SELECT LEFT(p.unit,5) from personnel p ORDER BY RAND() LIMIT 1) as created_by_unit,
 CASE (FLOOR(RAND()*100) + 20)%3
		WHEN 0 THEN "Manual"
        WHEN 1 THEN "System"
        ELSE "Officer" END,
DATE_ADD('2014-11-01', INTERVAL FLOOR(RAND() * 2975) DAY), 
 '',
 now();
         SET counter = counter + 1;
    END WHILE;
    
    
INSERT INTO claros.eventied (
    sno,event_id, ied_id, ied_state, ied_district, 
    ied_police_station, ied_location, ied_latitude, ied_longitude, 
    ied_status, ied_date_time, ied_position, depth_of_burial, 
    pattern_of_placcement, type_of_terrain, type_of_explosive, type_of_aligment, 
    mechanism_of_ied, length_of_wire, device_used_rx, device_used_tx, 
    no_of_ied, quantity_of_ied, type_of_detonator, length_ied_wire, 
    distance_from_camp, container_of_ied, ied_recovered_from, mode_disposal_of_ied, 
    ied_mode_of_detection, ied_residual_item, dimensions_of_creator, 
    aiming_point_used, distanct_from_ied, no_of_spikes, distance_from_camp_spike, 
    ied_details, desc_of_crator, desc_of_spikes, created_at, updated_at,created_by) 
 Select
    e.sno,e.event_id, e.sno*28376, e.state, e.district, 
    e.police_station,concat('Loc-',(FLOOR(RAND()*100) + 20)*123), e.latitude , e.longitude, 
    CASE (FLOOR(RAND()*100) + 20)%8
		WHEN 0 THEN "Occured in past weeks"
        WHEN 1 THEN "Inactive"
        WHEN 2 THEN "Ongoing"
		ELSE "Active" END, DATE_ADD('2014-11-01', INTERVAL FLOOR(RAND() * 2975) DAY), 
        concat('Pos-','{',(FLOOR(RAND()*100) + 20)%3.22,'}',(FLOOR(RAND()*100) + 20)%4.3,'}'),  concat((FLOOR(RAND()*100) + 20)%12 , "feet"), 
		concat("Pattern ",CHAR(65 + (FLOOR(RAND()*100) + 20)%7)), concat("Terrain ",CHAR(69 + (FLOOR(RAND()*100) + 20)%7)),  
        CASE (FLOOR(RAND()*100) + 20)%8
		WHEN 0 THEN "Trinitrotoluol (TNT)"
        WHEN 1 THEN "Ammonium nitrate"
        WHEN 2 THEN "Nitrocellulose"
        WHEN 3 THEN "Picric acid"
        WHEN 5 THEN "Detonating primers"
       ELSE "Polymer bonded explosive (PBX) " END, 
       concat("AT#00 ",100+(FLOOR(RAND()*100) + 20)%23,CHAR(65 + (FLOOR(RAND()*100) + 20)%7)),
       concat("M#M-",100+(FLOOR(RAND()*100) + 20)%180,CHAR(65 + (FLOOR(RAND()*100) + 20)%7),(FLOOR(RAND()*100) + 20)*67822,CHAR(76+(FLOOR(RAND()*100) + 20)%7)),
       concat(((FLOOR(RAND()*100) + 20)*400)%397 ,"m"),  concat("Rx Device R#",198+(FLOOR(RAND()*100) + 20)%10,CHAR(69 + (FLOOR(RAND()*100) + 20)%7)),  concat("Tx Device-",212+(FLOOR(RAND()*100) + 20)%3,CHAR(65 + (FLOOR(RAND()*100) + 20)%7)), 
    (FLOOR(RAND()*100) + 20)%20, concat((FLOOR(RAND()*100) + 20)%64,"kg") , concat("Detonator-",CHAR(65 + (FLOOR(RAND()*100) + 20)%7)),  concat((FLOOR(RAND()*100) + 20)%30,"m"), 
     concat((FLOOR(RAND()*100) + 20)%13,'km'), concat("Container ",CHAR(65 + (FLOOR(RAND()*100) + 20)%3)) ,concat("Recovered from Loc-",(FLOOR(RAND()*100) + 20)*123),  
    concat("Dis-M#01$",CHAR(67 + (FLOOR(RAND()*100) + 20)%2),CHAR(87+(FLOOR(RAND()*100) + 20)%3),(FLOOR(RAND()*100) + 20)*234,CHAR(70+(FLOOR(RAND()*100) + 20)%4)),
    concat("Detection mode ",CHAR(65 + (FLOOR(RAND()*100) + 20)%7)), concat("Residual Item-R00",(FLOOR(RAND()*100) + 20)), 
    concat( (1+(FLOOR(RAND()*100) + 20)%32) ," X " ,1+(FLOOR(RAND()*100) + 20)%16), 
    CASE (FLOOR(RAND()*100) + 20)%8
		WHEN 0 THEN "Aiming Point North"
        WHEN 1 THEN "Aiming Point East"
        WHEN 2 THEN "Aiming Point South"
        ELSE "Aiming Point West" END, 
        concat((FLOOR(RAND()*100) + 20)%23,'m'), (FLOOR(RAND()*100) + 20)%10, 
    concat((FLOOR(RAND()*100) + 20)%10,'km'), 
    "Components of IEDs
Any IED has five basic components –
(i) A switch (Trigger or activator):
A trigger or Activator is basically a switch or some other direct or indirect
means of setting the device off, such as a radio signal, trip wire, cell phone,
timer or firing button that someone presses.
(ii) Power source (battery):
Power supply is often provided by car batteries or alkaline flashlight
batteries.
(iii) An initiator (fuse or detonator):
A detonator is a small explosive charge that sets off the main charge.
Detonators are usually electrical, like those used for explosions in
construction (blasting caps).
(iv) Charge (explosive):
A main charge is the primary explosive body which is mainly responsible for
creating the blast wave.
(v) A container (body to hold everything together):
A container is used to hold everything together. The container may be designed
to force the blast in a specific direction.", 
concat("Description of Cater A086",(FLOOR(RAND()*100) + 20),CHAR(65 + (FLOOR(RAND()*100) + 20)%7)) , 
concat("Description of Spikes S086",(FLOOR(RAND()*100) + 20),CHAR(65 + (FLOOR(RAND()*100) + 20)%7)) , e.created_at, e.updated_at,e.created_by
from events e where e.eventtype='IED';   
    
    INSERT INTO claros.ied (
   ied_id, ied_state, ied_district, ied_police_station, ied_location, ied_latitude, ied_longitude, 
    ied_status, ied_date_time, ied_position, depth_of_burial, pattern_of_placcement, type_of_terrain, 
    type_of_explosive, type_of_aligment, mechanism_of_ied, length_of_wire, device_used_rx, device_used_tx, 
    no_of_ied, quantity_of_ied, type_of_detonator, length_ied_wire, distance_from_camp, container_of_ied, 
     ied_recovered_from, mode_disposal_of_ied, ied_mode_of_detection, ied_residual_item, 
    dimensions_of_creator, aiming_point_used, distanct_from_ied, no_of_spikes, distance_from_camp_spike, 
    ied_details, desc_of_crator, desc_of_spikes, created_at, updated_at,created_by) 
    Select 
    ei.sno, 
    ei.ied_state, 
    ei.ied_district, 
    ei.ied_police_station, 
    ei.ied_location, 
    ei.ied_latitude, 
    ei.ied_longitude, 
    ei.ied_status, 
    ei.ied_date_time, 
    ei.ied_position, 
    ei.depth_of_burial, 
    ei.pattern_of_placcement, 
    ei.type_of_terrain, 
    ei.type_of_explosive, 
    ei.type_of_aligment, 
    ei.mechanism_of_ied, 
    ei.length_of_wire, 
    ei.device_used_rx, 
    ei.device_used_tx, 
    ei.no_of_ied, 
    ei.quantity_of_ied, 
    ei.type_of_detonator, 
    ei.length_ied_wire, 
    ei.distance_from_camp, 
    ei.container_of_ied, 
	ei.ied_recovered_from, 
	ei.mode_disposal_of_ied, 
    ei.ied_mode_of_detection, 
	ei.ied_residual_item, 
    ei.dimensions_of_creator, 
    ei.aiming_point_used, 
    ei.distanct_from_ied, 
    ei.no_of_spikes, 
    ei.distance_from_camp_spike, 
    ei.ied_details, 
    ei.desc_of_crator, 
    ei.desc_of_spikes, 
    ei.created_at, 
    ei.updated_at,
    ei.created_by from eventied ei;   

    
INSERT INTO `claros`.`eventfir`
(`sno`,
`event_id`,
`fir_id`,
createdby,
`created_at`,
`updated_at`)
Select 
e.sno ,e.event_id,concat("FIR-#00",e.sno),e.created_by,e.created_at, e.updated_at from events e where e.eventtype='FIR';    
        
INSERT INTO `claros`.`eventinsurgentdetail` (sno,
    `event_id`, `insurgent_information_type`, `insurgent_specific_target`, `insurjent_theatre`, `insurgent_orgname`, 
    `insurgent_location`, `insurgent_topographical_detail`, `insurgent_camp_type`, `insurgent_leader_name`, 
    `insurgent_traning_nature`, `insurgent_camp_strength`, `insurgent_wepons_type`, `insurgent_number_of_weapon`, 
    `insurgent_eqp_type`, `insurgent_number_of_eqpt`, `insurgent_foreign_agency`, `insurgent_place_of_infiltration`, 
    `insurgent_route_of_infiltration`, `insurgent_destination_of_infiltration`, `insurgent_communication_station`, 
    `communication_control_station`, `insurgent_communication_station_loc`, `insurgent_sat_mob_no`, `insurgent_detail_sat_mob`, 
    `insurgent_communication_schedule`, `insurgent_freq_radio`, `insurgent_email`, `insurgent_website`, `insurgent_amount_demanded`, 
    `insurgent_amount_demanded_from`, `created_at`, `updated_at`,createdby)
 Select 
 e.sno,
    e.event_id, 
    concat("Information type " , CHAR(65+(FLOOR(RAND()*100) + 20)%6)), 
    concat("Target-T00A",CHAR(65+(FLOOR(RAND()*100) + 20)%26), CHAR(65+(FLOOR(RAND()*100) + 20)%6)), 
    e.theatre, 
    CASE (FLOOR(RAND()*100) + 20)%8
		WHEN 0 THEN "Al-Shabaab"
        WHEN 1 THEN "Abu Sayyaf"
        WHEN 2 THEN "Boko Haram"
        ELSE "All Tripura Tiger Force / National Liberation Front of Tripura" END, 
    concat(e.state ," ", e.district), 
    concat("Topographical Detail " , CHAR(65+(FLOOR(RAND()*100) + 20)%6)), 
    concat("camp-c",(FLOOR(RAND()*100) + 20)), 
      CASE (FLOOR(RAND()*100) + 20)%8
		WHEN 0 THEN "Mullah Omar"
        WHEN 1 THEN "Akhtar Monsour"
        WHEN 2 THEN "Hibatullah Akhundzada"
        WHEN 3 THEN "Haafiz Khamzaada"
        ELSE "Hamid Sayyaf" END,
    concat("Training Nature" , CHAR(65+(FLOOR(RAND()*100) + 20)%26)), 
    (FLOOR(RAND()*100) + 20)%60, 
    CASE (FLOOR(RAND()*100) + 20)%5
		WHEN 0 THEN "AkM , Ak-47 / Ak-203 / M4 Carbine / AR-M1"
        WHEN 1 THEN "P6/Micro-Uzi/SAF-Carbine/ASMI/Thormet MP9"
        WHEN 2 THEN "12 Bore PAG"
        WHEN 3 THEN "Dragunov SVD/ Koch PSG1 / Mauser SP66"
        WHEN 4 THEN "Barrett M82/M95 / OSV-96 "
        ELSE "MG 2A1 , 5A , 6A / M2 Browning" 
        END, (FLOOR(RAND()*100) + 20)%20, 
    CASE (FLOOR(RAND()*100) + 20)%5
		WHEN 0 THEN "Assault Rifles (ARs)"
        WHEN 1 THEN "Sub Machine Guns (SMGs)"
        WHEN 2 THEN "ShotGuns"
        WHEN 3 THEN "Sniper Rifles"
        WHEN 4 THEN "Anti-Material Rifles "
        ELSE "Machine Guns" 
        END, (FLOOR(RAND()*100) + 20)%10, concat("FA# " , CHAR(65+(FLOOR(RAND()*100) + 20)%6)), concat("INF-P013dfe " , CHAR(65+(FLOOR(RAND()*100) + 20)%6)), 
    concat("From " ,e.state , " , ",LEFT(e.district,3), " To ",CHAR(66 + (FLOOR(RAND()*100) + 20)%6)), 
    concat("DES " , (FLOOR(RAND()*100) + 20)), 
    concat("C#S- " , CHAR(65+(FLOOR(RAND()*100) + 20)%4)), 
    concat("CCon#S- " , CHAR(65+(FLOOR(RAND()*100) + 20)%6)), 
    concat("SLoc- " ,(FLOOR(RAND()*100) + 20)),
    12344753*(FLOOR(RAND()*100) + 20), 
    concat("Details satellite  " , 
    CHAR(65+(FLOOR(RAND()*100) + 20)%6)), 
    CASE (FLOOR(RAND()*100) + 20)%9
		WHEN 0 THEN concat("Communication Schedule-" , CHAR(65+(FLOOR(RAND()*100) + 20)%4))
        WHEN 1 THEN concat("Communication Schedule-" , CHAR(70+(FLOOR(RAND()*100) + 20)%4))
        WHEN 2 THEN concat("Communication Schedule-" , CHAR(75+(FLOOR(RAND()*100) + 20)%4))
		ELSE concat("Communication Schedule-" , CHAR(85+(FLOOR(RAND()*100) + 20)%4)) END, 
       
        CASE (FLOOR(RAND()*100) + 20)%9
		WHEN 0 THEN concat('Freq Radio-' , CHAR(65+(FLOOR(RAND()*100) + 20)%6))
        WHEN 1 THEN concat('Freq Radio-', CHAR(70+(FLOOR(RAND()*100) + 20)%6))
        WHEN 2 THEN concat('Freq Radio-' , CHAR(75+(FLOOR(RAND()*100) + 20)%6))
		ELSE concat('Freq Radio-', CHAR(85+(FLOOR(RAND()*100) + 20)%6)) END, 
		'email@example.com', 
        
		'www.example.com', 
		(FLOOR(RAND()*100) + 20)*86842, 
		concat("Demanded from " , CHAR(65+(FLOOR(RAND()*100) + 20)%6)), e.created_at, e.updated_at,e.created_by
        from events e where e.eventtype = 'Insurgent';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertPersonnel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `InsertPersonnel`()
BEGIN
DECLARE counter INT DEFAULT 1;
DECLARE x VARCHAR(200);
 WHILE counter <= 1000 DO
 SET x = concat(CASE counter%9
		WHEN 0 THEN 'Jayankar' WHEN 1 THEN 'Pratibha' WHEN 2 THEN 'Lalit'
        WHEN 3 THEN 'Kanika' When 4 then 'Deepesh' WHEN 5 THEN "Madhuri" 
        WHEN 6 THEN "Mansuk" WHEN 7 THEN "Arohi" WHEN 8 THEN "Prajwal" 
        ELSE 'Manupriya' END,' ',
        CASE counter%8
		WHEN 0 THEN 'Venkat Rao' WHEN 1 THEN 'Khanna' WHEN 2 THEN 'Shrotri'
        WHEN 3 THEN 'Deol' When 4 then 'Maninder' ELSE 'Sharma' END) ;
    INSERT INTO claros.personnel (
            id, user_name,`rank`, `name`, dob, `f_no`, contact_no, alt_contact_no, 
            email, unit, `status`, substatus, url, created_by, updated_by, created_at, updated_at
        ) SELECT
            counter , 
            CASE counter%6
		WHEN 0 THEN concat("m-",x,"@e-",counter)
        WHEN 1 THEN concat("s-",x,"@e",counter)
        WHEN 2 THEN concat("d-",x,"@e",counter)
        WHEN 3 THEN concat("kuma-",x,"@e",counter)
        When 4 then concat("gauds-",x,"@e",counter)
        ELSE concat("ss-",x,"@e",counter)END, 
       CASE counter%11
		WHEN 0 THEN "Director General"
        WHEN 1 THEN "Special Director General"
        WHEN 2 THEN "Additional Director General"
        WHEN 3 THEN "Inspector General"
        When 4 then "Deputy Inspector General"
        WHEN 5 THEN "Commandant"
        WHEN 6 THEN "Second – in – Command"
        WHEN 7 THEN "Deputy Commandant"
        WHEN 9 THEN "Assistant Commandant"
        WHEN 10 THEN "Sub Inspector"
        WHEN 11 THEN "Assistant Sub Inspector"
        WHEN 12 THEN "Subedar Major"
        ELSE "Inspector" END , 
		x, 
        DATE_ADD('1985-01-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY),
       concat("F-",counter,counter%100), 
      CONCAT(FLOOR(100 + RAND() * 900), FLOOR(100 + RAND() * 900), FLOOR(1000 + RAND() * 9000), FLOOR(100 + RAND() * 900)), 
       null, 
            concat(x,counter,"@gmail.com") as email, 
            CASE counter%12
		WHEN 0 THEN 'Un-A' WHEN 1 THEN 'Un-B' WHEN 2 THEN 'Un-C'
        WHEN 3 THEN 'Un-D' When 4 then 'Un-F' WHEN 5 THEN 'Un-G'
        WHEN 7 THEN 'Un-H' WHEN 8 THEN 'Un-I' WHEN 9 THEN 'Un-J'
        ELSE 'Un-E' END, 
        CASE counter%4
        WHEN 0 THEN "Suspended"
        ELSE concat("Active in ",CHAR(65+ FLOOR(RAND()*25))," branch") END, 
        CASE counter%4
        WHEN 0 THEN "InActive"
        ELSE "Active" END, 
        "https://example.com", 
        "", 
        "", 
       DATE_ADD('2018-12-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY), 
       DATE_ADD('2019-12-01', INTERVAL (FLOOR(RAND() * 785305) + 1600000) MINUTE);
        
         SET counter = counter + 1;
    END WHILE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `InsertVillage` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `InsertVillage`()
BEGIN
DECLARE counter INT DEFAULT 1;
 WHILE counter <= 1000 DO
	
   INSERT INTO `claros`.`village`
(`sno`, `zone`, `sector`, `range`, `unit`, `company`, `state`, `tehsil_district`, 
`theatre`, `district`, `police_station`, `sub_division`, `village`, `mohalla_colony`, 
`lat`, `lng`, `number_of_houses_village`, `total_population`, `male_population`, `female_population`, 
`religion`, `caste`, `number_of_voters`, `militancy_incidents`, `militant_sympathizers`, 
 `created_at`, `updated_at`) 
SELECT counter*2564, 
concat("ZONE ",CHAR(65 + counter%26)), 
concat("Sector ",CHAR(65 + counter%26),'-',counter%51), 
concat("Range ", counter%8), 
(Select p.unit from personnel p ORDER BY RAND() LIMIT 1), 
        '', CASE (Floor(RAND()*20)+1)%9
		WHEN 0 THEN "Mahrashtra"
        WHEN 1 THEN "Delhi"
        WHEN 2 THEN "Assam"
        WHEN 3 THEN "Meghalya"
        WHEN 4 THEN "Gujarat"
        WHEN 5 THEN "Karnatka"
        WHEN 6 THEN "Punjab"
        WHEN 7 THEN "Uttar Pradesh"
        ELSE "Kerela" END, 
        concat("Tehsil- ",CHAR(65+ (Floor(RAND()*20)+1)%16)), 
		concat("Theatre",CHAR(65 + (Floor(RAND()*20)+1)%6)), 
		concat("District " ,  CHAR(65+(Floor(RAND()*20)+1)%13)), 
		concat("P.S#D-" , CHAR(65+(Floor(RAND()*20)+1)%13)," " , counter%17), 
		concat("S-Div ",CHAR(65 + (Floor(RAND()*20)+1)%5)), 
       CASE (Floor(RAND()*20)+1)%9
		WHEN 0 THEN concat("MaleGaon-",counter%(Floor(RAND()*20)+1))
        WHEN 1 THEN concat("DholakPur-",counter%(Floor(RAND()*20)+1))
        WHEN 2 THEN concat("Kimchaami-",counter%(Floor(RAND()*20)+1))
        WHEN 3 THEN concat("Nathora-",counter%(Floor(RAND()*20)+1))
        WHEN 4 THEN concat("Jigweshwar-",counter%(Floor(RAND()*20)+1))
        WHEN 5 THEN concat("Alyaliva-",counter%(Floor(RAND()*20)+1))
        WHEN 6 THEN concat("Mohatti-",counter%(Floor(RAND()*20)+1))
        WHEN 7 THEN concat("Wasseypur-",counter%(Floor(RAND()*20)+1))
        ELSE concat("OdePode-",counter%(Floor(RAND()*20)+1)) END,  
        concat("Colony M-",counter%(Floor(RAND()*20)+1)),
		(RAND() * 180 - 90), (RAND() * 360 - 180), 
        counter*(FLOOR(RAND()*20)+1)*100, 
        counter*550, counter*281, counter*269, 
        CASE (Floor(RAND()*20)+1)%9
		WHEN 0 THEN "Hinduism"
        WHEN 1 THEN "Christianity"
        WHEN 2 THEN "Sikhism"
        WHEN 3 THEN "Judaism" 
        ELSE "OTHER" END, 
        '', 
        counter*432,  
        counter%5, 
        counter%12,  
        DATE_ADD('2002-01-01', INTERVAL FLOOR(RAND() * 3265) DAY), 
        now();
set counter = counter+1;
END WHILE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `persons` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `persons`()
BEGIN
    DECLARE counter INT DEFAULT 1;
    DECLARE x VARCHAR(200);
    DECLARE statelocation VARCHAR(150);
    
    WHILE counter <= 200 DO
    SET statelocation = (SELECT v.state FROM village v ORDER BY RAND() LIMIT 1);
    SET x =  concat(
                CASE counter % 9
                    WHEN 0 THEN 'Tarun' WHEN 1 THEN 'Kajol' WHEN 5 THEN 'Priya'
                    WHEN 3 THEN 'Amrita' WHEN 4 THEN 'Parag' WHEN 2 THEN 'Mayank'
                    WHEN 6 THEN 'Vishal' WHEN 7 THEN 'Amruta' WHEN 8 THEN 'Rakesh' END, ' ',
                CASE floor(rand()*20) % 8
                    WHEN 0 THEN 'Choubey' WHEN 1 THEN 'Khandelwal' WHEN 2 THEN 'Bhardwaj'
                    WHEN 3 THEN 'Sharma' WHEN 4 THEN 'Chaurasia' ELSE 'Verma' END
            );
        INSERT INTO `claros`.`person`(
            `sno`, `p_id`, `name`, `forcenumber`, `rank`, `fathername`, 
            `emailaddress`, `gender`, `age`, `dob`, `birthplace`, 
            `profile_status`, `profile_status_date`, `alias`, `aadhar_no`, 
            `pannumber`, `voter_card_no`, `ration_card_no`, `address`, 
            `theatre`, 
            `orgname`, `org_sub_zone`, `state`, `district`, 
            `tehsil`, `postoffice`, `village`, `pincode`, `latitude`, 
            `longitude`, `person_of_intrst`, `height`, `face_shape`, 
            `distance_between_eyes`, `complexion`, `build_type`, 
            `eye_colour`, `hair_colour`, `identification_marks`, 
            `eye_brows_type`, `eye_brows_thickness`, `eye_meeting`, 
            `nose`, `mouth`, `lips`, `fingers`, `chin`, `ears`, 
            `other_mark`, `beard`, `mustache`, `caste`, `category`, 
            `grade`, `arrested_on`, `status`, `nationality`, `phonenumber`, 
            `religion`, `reward`, `attachment_file_type`, `details_of_attachment`, 
            `url`, `viewed`, `edu_qualification`, `address1`, `remark`, 
            `wepon_held`, `specialhabbit`, `agency_innvolved`, 
            `person_of_interest`, `reason_for_monitoring`, `pecularities`, 
            `deformity`, `is_approved`, `ready_to_approve`, `ready_to_approve_date`, 
            `created_by`, `created_by_unit`, `created_at`, `updated_by`, `updated_at`
        ) 
        SELECT
            counter,
            CASE WHEN counter < 100 THEN concat("#Prs$@", counter*233) ELSE concat("#Pes$@", counter*23) END,
           x,
            concat("F#XX-", counter*233), 
            (SELECT LEFT(p.`rank`,20) FROM personnel p ORDER BY RAND() LIMIT 1),
            concat(
                CASE floor(rand()*20) % 10
                    WHEN 0 THEN 'Mithun' WHEN 1 THEN 'Byomesh' WHEN 2 THEN 'Lallan' WHEN 3 THEN 'Triple H' WHEN 4 THEN 'Dhankar'
                    WHEN 5 THEN "Kamal" WHEN 6 THEN "Kingfoso" WHEN 7  THEN "Jagdish" WHEN 8 THEN "JohnCena" ELSE 'Lamao' END, " ",
                CASE floor(rand()*20) % 8
                    WHEN 0 THEN 'Choubey' WHEN 1 THEN 'Khandelwal' WHEN 2 THEN 'Bhardwaj' WHEN 3 THEN 'Sharma' WHEN 4 THEN 'Chaurasia' ELSE 'Verma' END,
                floor(rand()*20)
            ),
            concat(x,'-',counter, "@gmail.com"),
            CASE WHEN (counter % 9) % 2 = 0 THEN "MALE" ELSE "FEMALE" END,
            20 + counter % 40,
            date_sub(current_date(), INTERVAL 20 + counter % 40 YEAR),
            (SELECT concat(v.village, " ", v.state) FROM village v where v.state = statelocation LIMIT 1),
            'unknown',
            DATE_ADD('2000-12-01', INTERVAL (FLOOR(RAND() * 200000) + 700000) Minute), 
            '',
            CONCAT(FLOOR(100 + RAND() * 900), FLOOR(100 + RAND() * 900), FLOOR(1000 + RAND() * 9000), FLOOR(100 + RAND() * 900)),
            CONCAT(
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 25) + 65),
                FLOOR(1000 + RAND() * 1000),
                CHAR(FLOOR(RAND() * 25) + 65)
            ),
            CONCAT(
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 26) + 65),
                FLOOR(10000 + RAND() * 1000),
                CHAR(FLOOR(RAND() * 26) + 65)
            ),
            CONCAT(CHAR(FLOOR(RAND() * 26) + 65), FLOOR(100900 + RAND() * 10000)),
            CONCAT(
                CASE (FLOOR(RAND() * 20) + 1) % 9
                    WHEN 0 THEN "Maharashtra" WHEN 1 THEN "Delhi" WHEN 2 THEN "Assam"
                    WHEN 3 THEN "Meghalaya" WHEN 4 THEN "Gujarat" WHEN 5 THEN "Karnataka"
                    WHEN 6 THEN "Punjab" WHEN 7 THEN "Uttar Pradesh" ELSE "Haryana" END, ' ',
                CASE (FLOOR(RAND() * 20) + 1) % 9
                    WHEN 0 THEN concat("Jamjoori-", counter % (FLOOR(RAND() * 20) + 1)) WHEN 1 THEN concat("Karolpuri-", counter % (FLOOR(RAND() * 20) + 1))
                    WHEN 2 THEN concat("Himtaani-", counter % (FLOOR(RAND() * 20) + 1)) WHEN 3 THEN concat("Lankoora-", counter % (FLOOR(RAND() * 20) + 1))
                    WHEN 4 THEN concat("Myaneshwar-", counter % (FLOOR(RAND() * 20) + 1)) WHEN 5 THEN concat("Nikunj Nagar-", counter % (FLOOR(RAND() * 20) + 1))
                    WHEN 6 THEN concat("Leporiski-", counter % (FLOOR(RAND() * 20) + 1)) WHEN 7 THEN concat("Hasanpur-", counter % (FLOOR(RAND() * 20) + 1))
                    ELSE concat("Kurukshetra-", counter % (FLOOR(RAND() * 20) + 1)) END, FLOOR(10000 + RAND() * 10000)
            ),
            (SELECT v.theatre FROM village v where v.state = statelocation LIMIT 1),
            CONCAT("ORG-", CHAR(FLOOR(RAND() * 25 + 65))),
            (SELECT CONCAT("Org S.ZONE-", v.zone) FROM village v ORDER BY RAND() LIMIT 1),
            (SELECT v.state FROM village v where v.state = statelocation LIMIT 1),
            (SELECT v.district FROM village v where v.state = statelocation LIMIT 1),
            (SELECT v.tehsil_district FROM village v where v.state = statelocation LIMIT 1),
            CONCAT("PSO-", CHAR(FLOOR(RAND() * 25 + 65))),
            CASE counter % 3
                WHEN 0 THEN (SELECT v.village FROM village v where v.state = statelocation LIMIT 1)
                ELSE CONCAT("Village ", CHAR(FLOOR(RAND() * 25 + 65))) END,
            FLOOR(10000 + RAND() * 10000),
            '', '', '',
            concat(FLOOR(4 + RAND() * 2), " ft", FLOOR(2 + RAND() * 10), " in"), -- height
            CASE counter % 5 WHEN 0 THEN "Oval" WHEN 1 THEN "Square" WHEN 2 THEN "Round" ELSE "Elliptical" END,
            concat(2 + FLOOR(RAND() * 5), " cm"),
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "DARK" WHEN 1 THEN "FAIR" ELSE "VERY FAIR" END,
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "Muscular" WHEN 1 THEN "Regular" ELSE "Unfit/Obesity" END,
            CASE FLOOR(RAND() * 6) WHEN 0 THEN "BLUE" WHEN 1 THEN "GREEN" WHEN 2 THEN "BROWN" WHEN 3 THEN "GREY" ELSE "BLACK" END,
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "BLACK" WHEN 1 THEN "BROWN" ELSE "GREYISH/WHITE" END,
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "No Marks" WHEN 1 THEN "Marks on Hand" ELSE "Mole on Body part" END,
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "Thick" WHEN 1 THEN "Thin" ELSE "Moderate" END,
            CONCAT(counter % 3, " mm"),
            '', '','',
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "Thick" WHEN 1 THEN "Sleek" ELSE "Smoky" END,
            '',
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "Double Chin" ELSE "Regular chin" END,
            '',
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "YES BUT UNKNOWN" WHEN 1 THEN "NO" ELSE "YES ON FOREHEAD" END,
            '', '',
            CASE FLOOR(RAND() * 5)
                WHEN 0 THEN "General" WHEN 1 THEN "OBC" WHEN 2 THEN "SC" WHEN 3 THEN "ST" ELSE "OTHERS" END,
            '', '',
            CASE counter % 4
                WHEN 0 THEN DATE_ADD('2000-12-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY)
                ELSE "Not Arrested" END,
            '',
            "Indian",
            CONCAT(FLOOR(100 + RAND() * 900), FLOOR(100 + RAND() * 900), FLOOR(1000 + RAND() * 9000)),
            (SELECT v.religion FROM village_other_information v ORDER BY RAND() LIMIT 1),
            '',
            'attachment.minio', 'details.attachment.doc', 'url.com', 1,
            CASE FLOOR(RAND() * 5)
                WHEN 0 THEN "Graduated" WHEN 1 THEN "10th Pass" WHEN 2 THEN "12th Pass" WHEN 3 THEN "Uneducated but Course Certified" ELSE "Uneducated" END,
            '', '',
           (SELECT a.arms_eqpt_type FROM arms_eqpt a ORDER BY RAND() LIMIT 1),
            '', '', '', '', '', '', '', '', '', '',
            concat("unit-",statelocation,CHAR(FLOOR(25*RAND()) +65)),
            DATE_ADD('2000-12-01', INTERVAL (FLOOR(RAND() * 2000000) + 1000000) SECOND), 
            '',
            now();
        SET counter = counter + 1;
    END WHILE;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `personsbasedonpersonnel` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `personsbasedonpersonnel`()
BEGIN
 INSERT INTO `claros`.`person`(
            `sno`, `p_id`, `name`, `forcenumber`, `rank`, `fathername`, 
            `emailaddress`, `gender`, `age`, `dob`, `birthplace`, 
            `profile_status`, `profile_status_date`, `alias`, `aadhar_no`, 
            `pannumber`, `voter_card_no`, `ration_card_no`, `address`, 
            `theatre`, 
            `orgname`, `org_sub_zone`, `state`, `district`, 
            `tehsil`, `postoffice`, `village`, `pincode`, `latitude`, 
            `longitude`, `person_of_intrst`, `height`, `face_shape`, 
            `distance_between_eyes`, `complexion`, `build_type`, 
            `eye_colour`, `hair_colour`, `identification_marks`, 
            `eye_brows_type`, `eye_brows_thickness`, `eye_meeting`, 
            `nose`, `mouth`, `lips`, `fingers`, `chin`, `ears`, 
            `other_mark`, `beard`, `mustache`, `caste`, `category`, 
            `grade`, `arrested_on`, `status`, `nationality`, `phonenumber`, 
            `religion`, `reward`, `attachment_file_type`, `details_of_attachment`, 
            `url`, `viewed`, `edu_qualification`, `address1`, `remark`, 
            `wepon_held`, `specialhabbit`, `agency_innvolved`, 
            `person_of_interest`, `reason_for_monitoring`, `pecularities`, 
            `deformity`, `is_approved`, `ready_to_approve`, `ready_to_approve_date`, 
            `created_by`, `created_by_unit`, `created_at`, `updated_by`, `updated_at`
        ) 
        SELECT
            v.id*101,
			concat("#Prs$@",  FLOOR(13 + RAND()*10000)*233),
            v.name,
            concat("F#XX-",  FLOOR(RAND()*10000)*233), 
           'Personnel',
            concat(
                CASE floor(rand()*20) % 6
                    WHEN 0 THEN 'Chooran' WHEN 1 THEN 'Nicholas' WHEN 2 THEN 'Happy' WHEN 3 THEN 'Rey Mysterio' WHEN 4 THEN 'Kamal' ELSE 'Jind Mahal' END, " ",
                CASE floor(rand()*20) % 8
                    WHEN 0 THEN 'Nayan' WHEN 1 THEN 'Ali' WHEN 2 THEN 'Alexander' WHEN 3 THEN 'Raikoti' WHEN 4 THEN 'Singh' ELSE 'Gaud' END,
                floor(rand()*20)
            ),
            v.email,
            CASE WHEN ( FLOOR(RAND()*10000)% 6) = 0 THEN "MALE" ELSE "FEMALE" END,
            timestampdiff(YEAR , v.dob , curdate()),
            v.dob,
            (SELECT concat(vi.village, " ", vi.state) FROM village vi ORDER BY RAND() LIMIT 1),
            'unknown',
            DATE_ADD('2000-12-01', INTERVAL (FLOOR(RAND() * 1000) + 2000) DAY), 
            '',
            CONCAT(FLOOR(100 + RAND() * 900), FLOOR(100 + RAND() * 900), FLOOR(1000 + RAND() * 9000), FLOOR(100 + RAND() * 900)),
            CONCAT(
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 25) + 65),
                FLOOR(1000 + RAND() * 1000),
                CHAR(FLOOR(RAND() * 25) + 65)
            ),
            CONCAT(
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 25) + 65),
                CHAR(FLOOR(RAND() * 26) + 65),
                FLOOR(10000 + RAND() * 1000),
                CHAR(FLOOR(RAND() * 26) + 65)
            ),
            CONCAT(CHAR(FLOOR(RAND() * 26) + 65), FLOOR(100900 + RAND() * 10000)),
            CONCAT(
                CASE (FLOOR(RAND() * 20) + 1) % 9
                    WHEN 0 THEN "MadhyaPradesh" WHEN 1 THEN "Sikkim" WHEN 2 THEN "Telengana"
                    WHEN 3 THEN "Manipur" WHEN 4 THEN "Bihar" WHEN 5 THEN "Odisha"
                    WHEN 6 THEN "Andhra Pradesh" WHEN 7 THEN "Chandigarh" ELSE "Goa" END, ' ',
                CASE (FLOOR(RAND() * 20) + 1) % 9
                    WHEN 0 THEN concat("Jimjana-",  FLOOR(RAND()*10000) % (FLOOR(RAND() * 20) + 1)) WHEN 1 THEN concat("Karolpuri-",  FLOOR(RAND()*10000) % (FLOOR(RAND() * 20) + 1))
                    WHEN 2 THEN concat("Lakari-",  FLOOR(RAND()*10000) % (FLOOR(RAND() * 20) + 1)) WHEN 3 THEN concat("Lankoora-",  FLOOR(RAND()*10000) % (FLOOR(RAND() * 20) + 1))
                    WHEN 4 THEN concat("Hyuktaara-",  FLOOR(RAND()*10000) % (FLOOR(RAND() * 20) + 1)) WHEN 5 THEN concat("Nikunj Nagar-",  FLOOR(RAND()*10000) % (FLOOR(RAND() * 20) + 1))
                    WHEN 6 THEN concat("Kannakora-",  FLOOR(RAND()*10000) % (FLOOR(RAND() * 20) + 1)) WHEN 7 THEN concat("Hasanpur-",  FLOOR(RAND()*10000) % (FLOOR(RAND() * 20) + 1))
                    ELSE concat("malkova-",  FLOOR(RAND()*10000) % (FLOOR(RAND() * 20) + 1)) END, FLOOR(10000 + RAND() * 10000)
            ),
            (SELECT vi.theatre  FROM village vi ORDER BY RAND() LIMIT 1),
            CONCAT("ORG-", CHAR(FLOOR(RAND() * 25 + 65))),
            (SELECT CONCAT("Org S.ZONE-", vi.zone)FROM village vi ORDER BY RAND() LIMIT 1),
            (SELECT vi.state FROM village vi ORDER BY RAND() LIMIT 1),
            (SELECT vi.district FROM village vi ORDER BY RAND() LIMIT 1),
            (SELECT vi.tehsil_district FROM village vi ORDER BY RAND() LIMIT 1),
            CONCAT("PSO-", CHAR(FLOOR(RAND() * 25 + 65))),
            CASE  FLOOR(RAND()*10000) % 3
                WHEN 0 THEN (SELECT vi.village FROM village vi ORDER BY RAND() LIMIT 1)
                ELSE CONCAT("Village ", CHAR(FLOOR(RAND() * 25 + 65))) END,
            FLOOR(10000 + RAND() * 10000),
            '', '', '',
            concat(FLOOR(4 + RAND() * 2), " ft", FLOOR(2 + RAND() * 10), " in"), -- height
            CASE  FLOOR(RAND()*10000) % 5 WHEN 0 THEN "Oval" WHEN 1 THEN "Square" WHEN 2 THEN "Round" ELSE "Elliptical" END,
            concat(2 + FLOOR(RAND() * 5), " cm"),
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "DARK" WHEN 1 THEN "FAIR" ELSE "VERY FAIR" END,
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "Muscular" WHEN 1 THEN "Regular" ELSE "Lean" END,
            CASE FLOOR(RAND() * 6) WHEN 0 THEN "BLUE" WHEN 1 THEN "GREEN" WHEN 2 THEN "BROWN" WHEN 3 THEN "GREY" ELSE "BLACK" END,
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "BLACK" WHEN 1 THEN "BROWN" ELSE "GREYISH/WHITE" END,
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "No Marks" WHEN 1 THEN "Marks on Hand" ELSE "Mole on Body part" END,
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "Thick" WHEN 1 THEN "Thin" ELSE "Moderate" END,
            CONCAT(1+ FLOOR(RAND()*10) % 3, " mm"),
            '', '','',
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "Thick" WHEN 1 THEN "Sleek" ELSE "Smoky" END,
            '',
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "Double Chin" ELSE "Regular chin" END,
            '',
            CASE FLOOR(RAND() * 3) WHEN 0 THEN "YES BUT UNKNOWN" WHEN 1 THEN "NO" ELSE "YES ON FOREHEAD" END,
            '', '',
            CASE FLOOR(RAND() * 5)
                WHEN 0 THEN "General" WHEN 1 THEN "OBC" WHEN 2 THEN "SC" WHEN 3 THEN "ST" ELSE "OTHERS" END,
            '', '',
            CASE  FLOOR(RAND()*10000) % 4
                WHEN 0 THEN DATE_ADD('2000-12-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY)
                ELSE "Not Arrested" END,
            '',
            "Indian",
            CONCAT(FLOOR(100 + RAND() * 900), FLOOR(100 + RAND() * 900), FLOOR(1000 + RAND() * 9000)),
            'Hindu',
            '',
            'attachment.minio', 'details.attachment.doc', 'url.com', 1,
            CASE FLOOR(RAND() * 5)
                WHEN 0 THEN "Graduated" WHEN 1 THEN "10th Pass" WHEN 2 THEN "12th Pass" WHEN 3 THEN "Uneducated but Course Certified" ELSE "Uneducated" END,
            '', '',
         ( SELECT a.arms_eqpt_type FROM arms_eqpt a ORDER BY RAND() LIMIT 1),
            '', '', '', '', '', '', '', '', '', '',
            v.unit,
            v.created_at, 
            '',
            now() from personnel v;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `vilageothers` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `vilageothers`()
BEGIN
INSERT INTO `claros`.`village_collage_details`
(`sno`,
`college_name`,
`staff_name`,
`mobile_number`,
`created_at`,
`created_by`,
`village_id`)
Select 
v.sno , 
CASE (FLOOR(RAND() * 30)+4)%9
WHEN 0 THEN concat("Abhudaay College-" , (FLOOR(RAND() * 30)+4)%10)
WHEN 1 THEN concat("Ramjas College-" , (FLOOR(RAND() * 30)+4)%10)
WHEN 2 THEN concat("Raneeksha College-" , (FLOOR(RAND() * 30)+4)%10)
WHEN 3 THEN concat("WungSu Fang College-" , (FLOOR(RAND() * 30)+4)%10)
WHEN 4 THEN concat("Kemyoski College-" , (FLOOR(RAND() * 30)+4)%10)
WHEN 5 THEN concat("Lameta lal College-" , (FLOOR(RAND() * 30)+4)%10)
WHEN 6 THEN concat("Sanjeevani Bhavan College-" , (FLOOR(RAND() * 30)+4)%10)
WHEN 7 THEN concat("Minoxio College-" , (FLOOR(RAND() * 30)+4)%10)
ELSE concat("Jujutsu College-" , (FLOOR(RAND() * 30)+4)%10) END,
concat(
CASE (FLOOR(RAND() * 30)+4)%9
WHEN 0 THEN "Kamal " 
WHEN 1 THEN "Mintu " 
WHEN 2 THEN "Priyanka " 
WHEN 3 THEN "Preksha " 
WHEN 4 THEN "Lalita " 
WHEN 5 THEN "Jayant " 
WHEN 6 THEN "Bhuvam " 
WHEN 7 THEN "Halluram "
ELSE "Shaazia" END,
CASE (FLOOR(RAND()*20)+1)%5
WHEN 0 THEN concat("Raj-", FLOOR(RAND()*20)+1)
WHEN 1 THEN concat("Sachdeva-", FLOOR(RAND()*20)+1)
WHEN 2 THEN concat("Choudhary-", FLOOR(RAND()*20)+1)
ELSE concat("Thakur-", FLOOR(RAND()*20)+1) END),
987676887*FLOOR(RAND()*20)+1,
v.created_at,
'',
v.village_id from village_other_information v;

INSERT INTO `claros`.`village_festival`
(`sno`,
`village_id`,
`name`,
`date_from`,
`date_to`,
`created_by`,
`created_at`,
`updated_by`,
`updated_at`)
Select v.sno,
v.village_id,
CASE v.religion 
WHEN "Hinduism" THEN "Diwali" 
WHEN "Judaism" THEN "Yaweh Festival"
WHEN "Sikhism" THEN "Lohri"
WHEN "Christianity" THEN "Christmas"
Else  "Unknown" END,
DATE_ADD('2018-08-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY),
DATE_ADD('2018-12-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY),
'',
v.created_at,
v.updated_by,
v.updated_at from village_other_information v;

INSERT INTO `claros`.`village_govt_department_details`
(`sno`,
`govt_servant_name`,
`govt_department_name`,
`created_at`,
`created_by`,
`village_id`)
Select v.sno,
concat(
CASE (FLOOR(RAND() * 30)+4)%9
WHEN 0 THEN "JayShankar " 
WHEN 1 THEN "Rinku " 
WHEN 2 THEN "Biwani " 
WHEN 3 THEN "Anuraadha " 
WHEN 4 THEN "Sonu " 
WHEN 5 THEN "Paritosh " 
WHEN 6 THEN "Abhijeet " 
WHEN 7 THEN "Lucifer "
ELSE "Daya" END,
CASE (FLOOR(RAND()*20)+1)%5
WHEN 0 THEN concat("Nigam-", FLOOR(RAND()*20)+1)
WHEN 1 THEN concat("Khanna-", FLOOR(RAND()*20)+1)
WHEN 2 THEN concat("Sharma-", FLOOR(RAND()*20)+1)
ELSE concat("Bundelwal-", FLOOR(RAND()*20)+1) END),
concat(
CASE (FLOOR(RAND() * 30)+4)%6
WHEN 0 THEN "Institute of " 
WHEN 1 THEN "National Agency of " 
WHEN 2 THEN "Indian Group of " 
WHEN 3 THEN "State Bank of "
ELSE "Regional government office of " END,
CASE (FLOOR(RAND()*20)+1)%5
WHEN 0 THEN concat("Banking-", FLOOR(RAND()*20)+1)
WHEN 1 THEN concat("Affair Ministry-", FLOOR(RAND()*20)+1)
WHEN 2 THEN concat("Agencies-", FLOOR(RAND()*20)+1)
ELSE concat("Services-", FLOOR(RAND()*20)+1) END),
v.created_at,
'',
v.village_id from village_other_information v;

INSERT INTO `claros`.`village_hospital_details`
(`sno`,
`hospital_name`,
`hospital_staff`,
`mobile_number`,
`created_at`,
`created_by`,
`village_id`)
Select v.sno,
concat(CASE (FLOOR(RAND() * 30)+4)%6
WHEN 0 THEN "Hospital of " 
WHEN 1 THEN "National Research Institute of " 
WHEN 2 THEN "All India Institute of  " 
WHEN 3 THEN "XYZ Hospital of "
ELSE "General Goverment Hospital of " END,
CASE (FLOOR(RAND()*20)+1)%5
WHEN 0 THEN concat("Heart Surgery-", FLOOR(RAND()*20)+1)
WHEN 1 THEN concat("Medical Sciences-", FLOOR(RAND()*20)+1)
WHEN 2 THEN concat("Surgical Services-", FLOOR(RAND()*20)+1)
ELSE concat("Operational Services-", FLOOR(RAND()*20)+1) END),
concat("Doctors - ",FLOOR(RAND()*200)+1 , ", Nurse Staff - ",FLOOR(RAND()*400)+100,", Rooms - ", FLOOR(RAND()*200)+10),
FLOOR(RAND()*2029889866)+109980989,
v.created_at,
'',
v.village_id from village_other_information v;

INSERT INTO `claros`.`village_informer_details`
(`sno`,
`sympathizer_of_polic`,
`mobile_informer`,
`created_at`,
`created_by`,
`village_id`)
Select v.sno,
"Yes",
"Yes",
DATE_ADD('2018-08-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY),
'',
v.village_id from village_other_information v where (v.religion = 'Hinduism' or v.religion = 'Judaism') AND (v.sno%3=0);


INSERT INTO `claros`.`village_institution`
(`sno`,
`type_of_institution`,
`village_id`,
`member_id`,
`sub_type_of_institution`,
`name_of_institution`,
`date_from`,
`date_to`,
`rank`,
`created_by`,
`created_at`,
`updated_by`,
`updated_at`)
SELECT v.sno,
CASE (FLOOR(RAND())+v.sno)%6
WHEN 0 THEN concat("Inst Type ",CHAR(FLOOR(RAND()*26) +65))
WHEN 1 THEN concat("Inst Type ",CHAR(FLOOR(RAND()*26) +65))
WHEN 2 THEN concat("Inst Type ",CHAR(FLOOR(RAND()*26) +65))
WHEN 3 THEN concat("Inst Type ",CHAR(FLOOR(RAND()*26) +65))
WHEN 4 THEN concat("Inst Type ",CHAR(FLOOR(RAND()*26) +65))
ELSE concat("Inst Type ",CHAR(FLOOR(RAND()*26) +65)) END,
v.village_id,
concat("Mem#",v.sno),
 CASE (FLOOR(RAND())+v.sno)%6
WHEN 0 THEN concat("ISub-i",CHAR(FLOOR(RAND()*26) +65))
WHEN 1 THEN concat("ISub-i",CHAR(FLOOR(RAND()*26) +65))
WHEN 2 THEN concat("ISub-i",CHAR(FLOOR(RAND()*26) +65))
WHEN 3 THEN concat("ISub-i",CHAR(FLOOR(RAND()*26) +65))
WHEN 4 THEN concat("ISub-i",CHAR(FLOOR(RAND()*26) +65))
ELSE concat("ISub-i",CHAR(FLOOR(RAND()*26) +65)) END,
concat( CASE (FLOOR(RAND())+v.sno)%6
WHEN 0 THEN "Indian Institute of Military Academy"
WHEN 1 THEN "Institute of War Academics"
WHEN 2 THEN "Officers Training Academy Institute"
WHEN 3 THEN "Armoured Corps Centre and School"
WHEN 4 THEN "Institute of Millitary Engineering" 
ELSE "Institute of Foreign War Relations" END,
CASE  (FLOOR(RAND())+v.sno)%6
WHEN 0 THEN ", Gujarat"
WHEN 1 THEN ", Chennai"
WHEN 2 THEN ", Madhav Garh"
WHEN 3 THEN ", Delhi"
WHEN 4 THEN ", Ahemdabad"
ELSE ", Lucknow" END),
DATE_ADD('1986-12-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY), 
CASE FLOOR(RAND())%2
 WHEN 1 THEN DATE_ADD('2018-12-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY)
 ELSE "Currently present" END,
 concat("Rank Category 1",(FLOOR(RAND())+v.sno)%6),
'',
DATE_ADD('2022-12-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY), 
'',
now() from village_other_information v;

INSERT INTO `claros`.`village_location`
(`sno`,
`village_id`,
`type_of_location`,
`sub_type_of_location`,
`lat`,
`lng`,
`remarks`,
`created_by`,
`created_at`,
`updated_by`,
`updated_at`)

Select v.sno,
v.village_id,
 CASE (FLOOR(RAND())+v.sno)%6
WHEN 0 THEN concat("Loc-Type ",CHAR(FLOOR(RAND()*6)+65),"#LC",CHAR(FLOOR(RAND()*6)+65))
WHEN 1 THEN concat("Loc-Type ",CHAR(FLOOR(RAND()*6)+85),"#HX",CHAR(FLOOR(RAND()*6)+76))
WHEN 2 THEN concat("Loc-Type ",CHAR(FLOOR(RAND()*6)+75),"#BX",CHAR(FLOOR(RAND()*6)+66))
ELSE concat("Loc-Type ",CHAR(FLOOR(RAND()*6)+70 ),"#CC",CHAR(FLOOR(RAND()*6)+81)) END,
 CASE (FLOOR(RAND())+v.sno)%6
WHEN 0 THEN concat("Sub-#FF",CHAR(FLOOR(RAND()*6)+65))
WHEN 1 THEN concat("Sub-#EE",CHAR(FLOOR(RAND()*6)+76))
WHEN 2 THEN concat("Sub-#EE",CHAR(FLOOR(RAND()*6)+66))
ELSE concat("Sub-#CC",CHAR(FLOOR(RAND()*6)+81)) END,
(Select vi.lat from village vi where v.sno=vi.sno) as lat,
(Select vi.lng from village vi where v.sno=vi.sno) as lng,
'',
 CASE (FLOOR(RAND())+v.sno)%3
WHEN 0 THEN "Manual"
WHEN 1 THEN "System"
ELSE "" END,
DATE_ADD('2022-10-11', INTERVAL (FLOOR(RAND() * 100) + 365) DAY), 
'',
now() from village_other_information v;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `villageMember` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `villageMember`()
BEGIN
INSERT INTO `claros`.`village_operational_information`
(
    `sno`,
    `village_id`,
    `village_area_name`,
    `area_with_coordinates`,
    `operational_history`,
    `terrorist_type`,
    `details_of_terrorist`,
    `list_ogws`,
    `vulnerable_areas`,
    `l_and_o_history`,
    `number_of_stone_pelters`,
    `flash_point`,
    `created_by`,
    `created_at`,
    `updated_by`,
    `updated_at`
)
SELECT 
    v.sno,
    v.village_id,
    (SELECT CONCAT(vi.state, ", ", vi.village) FROM village vi WHERE v.sno = vi.sno LIMIT 1),
    (SELECT CONCAT(vi.state, ", ", vi.village, "{", vi.lat, ", ", vi.lng, "}") FROM village vi WHERE v.sno = vi.sno LIMIT 1),
    CONCAT("OPERATIONAL HISTORY #", LEFT(v.sno * 112, 6)),
    CONCAT("TYPE-T#", FLOOR(RAND() * 100), CHAR(FLOOR(RAND() * 10 + 75)), CHAR(FLOOR(RAND() * 10 + 75))),
    CONCAT("Details of Terrorist", CHAR(FLOOR(RAND() * 10 + 75))),
    -- (SELECT GROUP_CONCAT(vo.name_of_ogw SEPARATOR ', ') FROM village_ogw_information vo WHERE vo.village_id = v.village_id),
    '',
    '',  -- vulnerable_areas
    '',  -- l_and_o_history
    (SELECT COUNT(*) FROM village_stonepelters_information vs WHERE vs.village_id = v.village_id),
    '',  -- flash_point
    '',  -- created_by
    v.created_at,
    '',  -- updated_by
    NOW()
FROM village_other_information v;




INSERT INTO `claros`.`village_member`
(`sno`,
`village_id`,
`house_no`,
`name`,
`member_type`,
`mobile`,
`aadhar_card`,
`age`,
`photo`,
`lat`,
`lng`,
`address`,
`remarks`,
`operational_details_of_house`,
`family_members_settled_absoad`,
`foreign_country_visit`,
`terror_links_of_family`,
`any_previsous_encounter_in_the_house`,
`created_by`,
`created_at`,
`updated_by`,
`updated_at`)
Select 
v.sno,
v.village_id,
concat(CHAR(FLOOR(RAND()*25) + 65),"- ",v.sno%(FLOOR(RAND()*2000)+1000)),
concat(CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Raveena' WHEN 1 THEN 'Jamul' WHEN 2 THEN 'Kanishk'
        WHEN 3 THEN 'Haider' When 4 then 'Rakesh' ELSE 'Ajay' END," ",
        CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'Diggaj' WHEN 1 THEN 'Khan' WHEN 2 THEN 'Singh'
        WHEN 3 THEN 'Kumar' When 4 then 'Ahmed' ELSE 'Ali' END) ,
        concat("MEM#-T ",CHAR(FLOOR(RAND()*10) + 65)),
        CONCAT(FLOOR(100 + RAND() * 900), FLOOR(100 + RAND() * 900),FLOOR(1000 + RAND() * 9000) ),
        CONCAT(FLOOR(100 + RAND() * 900), FLOOR(100 + RAND() * 900),FLOOR(1000 + RAND() * 9000) ,FLOOR(100 + RAND() * 900)),
        FLOOR(RAND()*50) + 20,
        'url/image.jpeg',
        (Select vi.lat from village vi where v.sno=vi.sno LIMIT 1) as lat,
		(Select vi.lng from village vi where v.sno=vi.sno LIMIT 1) as lng,
        (Select concat(vi.village," ",vi.state) from village vi where vi.sno = v.sno LIMIT 1),
        '',
        (Select operational_history from village_operational_information vi where vi.village_id = v.village_id LIMIT 1),
        FLOOR(RAND()*50) + 10,
       concat("{ ",CASE (FLOOR(RAND()*200))%FLOOR(RAND()*6 + 1)
		WHEN 0 THEN 'Australia' WHEN 1 THEN 'South Africa' WHEN 2 THEN 'Pakistan'
        WHEN 3 THEN 'Afghanistan' When 4 then 'USA' ELSE 'Malaysia' END," ",
        CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'Singapore' WHEN 1 THEN 'China' WHEN 2 THEN 'Oman'
        WHEN 3 THEN 'Abu Dhabi' When 4 then 'Saudi Arabia' ELSE 'Iraq' END,"}") ,
         CASE (FLOOR(RAND()*100) + 20)%8
		WHEN 0 THEN "With Al-Shabaab"
        WHEN 1 THEN "With Abu Sayyaf"
        WHEN 2 THEN "With Boko Haram"
        WHEN 3 THEN "With ISIS"
        WHEN 4 THEN "With (NLTF)National Liberation Front of Tripura"
        ELSE "With (ATTF)All Tripura Tiger Force " END,
        '',
        '',
        v.created_at,
        '',
        now() From village_other_information v ORDER BY -1 LIMIT 50;

        
        
        
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `villageotherdetails` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `villageotherdetails`()
BEGIN

INSERT INTO `claros`.`village_other_information`
(`sno`,
`village_id`,
`religion`,
`worship_place_type`,
`name_of_place`,
`coordinates`,
`img_worship`,
`number_of_worship`,
`number_of_madrassas`,
`number_of_yateem_khana`,
`prominent_religious_leaders`,
`created_by`,
`created_at`,
`updated_by`,
`updated_at`)
Select v.sno ,
concat("V-iD#01",RIGHT(v.sno,3)),
v.religion,
CASE v.religion 
WHEN "Hinduism" THEN "Temple"
WHEN "Christianity" THEN "Church"
WHEN "OTHER" THEN "Mosque or Unknown"
WHEN "Sikhism" THEN "Gurudwara"
ELSE "Yahweh Place" END,

CASE v.religion 
WHEN "Hinduism" THEN concat("Temple-" , (FLOOR(RAND()*20)+1))
WHEN "Christianity" THEN concat("Church-" ,(FLOOR(RAND()*20)+1))
WHEN "OTHER" THEN "Unknown"
WHEN "Sikhism" THEN concat("Gurudwara-" ,(FLOOR(RAND()*20)+1))
ELSE concat("Yahweh-" ,(FLOOR(RAND()*20)+1)) END,
'',
'',
CASE v.religion 
WHEN "Hinduism" THEN (FLOOR(RAND()*200)+1000)
ELSE (FLOOR(RAND()*200)+655) END,
CASE v.religion 
WHEN "OTHER" THEN (FLOOR(RAND()*20)+100) END,
CASE v.religion 
WHEN "OTHER" THEN (FLOOR(RAND()*20)+100) END,
CASE v.religion 
WHEN "Hinduism" THEN concat("Amber Dev-" , (FLOOR(RAND()*20)+1))
WHEN "Christianity" THEN concat("Ismail Brugenza-" ,(FLOOR(RAND()*20)+1))
WHEN "OTHER" THEN concat("Yatim Aslam Khan-" ,(FLOOR(RAND()*20)+1))
WHEN "Sikhism" THEN concat("Amritpal Singh-" ,(FLOOR(RAND()*20)+1))
ELSE concat("Yuletide Zenix-" ,(FLOOR(RAND()*20)+1)) END,
v.created_by,
v.created_at,
v.updated_by,
v.updated_at from village v;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `villagestonepelters` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `villagestonepelters`()
BEGIN

declare counter int default 13;

		INSERT INTO `claros`.`village_stonepelters_information`
(`sno`,
`village_id`,
`name_of_stonepelters`,
`age_of_stonepelters`,
`profession_of_stonepelters`,
`address_of_stonepelters`,
`active_since_of_stonepelters`,
`anti_national_activities`,
`created_by`,
`created_at`,
`updated_by`,
`updated_at`)
Select
v.sno*counter%10000,
v.village_id,
concat(
CASE ((v.sno*counter)+FLOOR(RAND()*200))%6
		WHEN 0 THEN 'Aatif' WHEN 1 THEN 'Ismail' WHEN 2 THEN 'Khwaja'
        WHEN 3 THEN 'Qaasir' When 4 then 'Altaaf' ELSE 'Abdul' END,
        CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'Bari' WHEN 1 THEN 'Khan' WHEN 2 THEN 'Modi'
        WHEN 3 THEN 'Gandhi' When 4 then 'Ahmed' ELSE 'Ali' END) ,
        (15+FLOOR(RAND()*200))%50,
       Case ((v.sno*counter)+FLOOR(RAND()*200))%6
       WHEN 0 THEN 'BusinessMan' WHEN 1 THEN 'Service Employee' WHEN 2 THEN 'Shopkeeper'
        WHEN 3 THEN 'Vendor and Dealer' When 4 then 'Broker' ELSE 'Labour/Mechanic' END,
        (Select concat(vi.state ," ", vi.village) from village vi where vi.sno = v.sno),
           concat(((v.sno*counter)+FLOOR(RAND()*200))%20 + 1, " years"),
        Case ((v.sno*counter)+FLOOR(RAND()*200))%6
       WHEN 0 THEN 'Terror Attacks' WHEN 1 THEN 'Bomb Blasting' WHEN 2 THEN 'Human Trafficking'
        WHEN 3 THEN 'Weapon Smuggling' When 4 then 'Terror Linkage' ELSE 'Unknown' END,
        '',
        DATE_ADD('2010-01-01', INTERVAL (FLOOR(RAND() * 2000) + 1000) DAY), 
        '',
        now() 
        from village_other_information v ORDER BY 1 LIMIT 100 ;        

INSERT INTO `claros`.`village_ogw_information`
(`sno`,
`village_id`,
`type`,
`name_of_ogw`,
`age_of_ogw`,
`profession_of_ogw`,
`address_of_ogw`,
`active_since_of_ogw`,
`affiliation_of_ogw`,
`anti_national_activities`,
`created_by`,
`created_at`,
`updated_by`,
`updated_at`)

Select v.sno*counter%10000,
v.village_id,
concat("TYPE-" ,CHAR(FLOOR(RAND()*10)+65)),
concat(
CASE ((v.sno*counter)+FLOOR(RAND()*200))%6
		WHEN 0 THEN 'Aatif' WHEN 1 THEN 'Ismail' WHEN 2 THEN 'Khwaja'
        WHEN 3 THEN 'Qaasir' When 4 then 'Altaaf' ELSE 'Abdul' END,
        CASE FLOOR(RAND()*200 + 10)%8
		WHEN 0 THEN 'Bari' WHEN 1 THEN 'Khan' WHEN 2 THEN 'Modi'
        WHEN 3 THEN 'Gandhi' When 4 then 'Ahmed' ELSE 'Ali' END) ,
        FLOOR(RAND()*200 + 30)%50,
         Case ((v.sno*counter)+FLOOR(RAND()*200))%6
       WHEN 0 THEN 'BusinessMan' WHEN 1 THEN 'Service Employee' WHEN 2 THEN 'Shopkeeper'
        WHEN 3 THEN 'Vendor and Dealer' When 4 then 'Broker' ELSE 'Labour/Mechanic' END,
         (Select concat(vi.state ," ", vi.village) from village vi where vi.sno = v.sno),
         concat(((v.sno*counter)+FLOOR(RAND()*200))%20 + 1, " years"),
         CASE (FLOOR(RAND()*100) + 20)%8
		WHEN 0 THEN "Al-Shabaab"
        WHEN 1 THEN "Abu Sayyaf"
        WHEN 2 THEN "Boko Haram"
        WHEN 3 THEN "ISIS"
        WHEN 4 THEN "(NLTF)National Liberation Front of Tripura"
        ELSE "(ATTF)All Tripura Tiger Force " END,
         Case ((v.sno*counter)+FLOOR(RAND()*200))%6
       WHEN 0 THEN 'Terror Attacks' WHEN 1 THEN 'Bomb Blasting' WHEN 2 THEN 'Human Trafficking'
        WHEN 3 THEN 'Weapon Smuggling' When 4 then 'Terror Linkage' ELSE 'Unknown' END,
        '',
        v.created_at,
        '',
        now() from village_other_information v ORDER BY 1 LIMIT 100 ;



END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-10 15:28:39
