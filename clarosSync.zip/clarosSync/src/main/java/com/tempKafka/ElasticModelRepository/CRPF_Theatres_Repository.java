package com.tempKafka.ElasticModelRepository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.tempKafka.ElasticModel.CRPF_Theatres;

public interface CRPF_Theatres_Repository extends ElasticsearchRepository<CRPF_Theatres, String>{
}
