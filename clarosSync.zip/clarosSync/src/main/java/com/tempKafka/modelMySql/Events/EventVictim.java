package com.tempKafka.modelMySql.Events;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "eventvictim")
public class EventVictim {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sno;
	String name;
	@Column(name="event_id")
	String eventid;
	String district;
	
	
	
	
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public EventVictim() {
		super();
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getEventid() {
		return eventid;
	}
	public void setEventid(String eventid) {
		this.eventid = eventid;
	}
	@Override
	public String toString() {
		return "EventVictim [sno=" + sno + ", name=" + name + ", event_id=" + eventid + "]";
	}
	
	
	
}
