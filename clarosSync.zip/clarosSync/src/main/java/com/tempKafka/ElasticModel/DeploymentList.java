package com.tempKafka.ElasticModel;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.tempKafka.MySqlRepo.deploymentRepository.ArmsEquipmentRepository;
//import com.tempKafka.modelMySql.deployment.ArmsEquipments;
//import com.tempKafka.modelMySql.deployment.Dep_um_food_details;
//import com.tempKafka.modelMySql.deployment.Deploymentdetails;
//import com.tempKafka.modelMySql.deployment.Event_arms_equipment;
//import com.tempKafka.modelMySql.deployment.Personnel;
//

import java.util.List;

import com.tempKafka.modelMySql.deployment.Dep_um_food_details;
import com.tempKafka.modelMySql.deployment.Deploymentdetails;

public class DeploymentList {
	
//	
//	Crpf_processor cp = new Crpf_processor();
//	
	private List<Deploymentdetails> det;
	private List<Dep_um_food_details> dem;
//	private List<Personnel> pers;
//	private List<Event_arms_equipment> li2;
//	
//	@Autowired
//	private ArmsEquipmentRepository armsrepo;
//	
//	public List<Personnel> getPers() {
//		return pers;
//	}
//	public void setPers(List<Personnel> pers) {
//		this.pers = pers;
//		for(Personnel per : pers) {
//		this.cp.setPersonnelDetails(per.getPersonnelName(),per.getPersonnelrank(),per.getUnit());
	
	public List<Deploymentdetails> getDet() {
		return det;
	}
	public void setDet(List<Deploymentdetails> det) {
		this.det = det;
	}
	public List<Dep_um_food_details> getDem() {
		return dem;
	}
	public void setDem(List<Dep_um_food_details> dem) {
		this.dem = dem;
	}
	}
//	}
//	
//	public List<Event_arms_equipment> getLi2() {
//		return li2;
//	}
//	public void setLi2(List<Event_arms_equipment> li2) {
//		this.li2 = li2;
//		for(Event_arms_equipment eventarms : li2) {
//			ArmsEquipments ae = armsrepo.findByArmsEqptId(Integer.valueOf(eventarms.getArmsEqptId()));
//			this.cp.setArmsDetails(ae.getArmsEqptCategory() , ae.getArmsEqptType());
//		}
//	}
//	public List<Deploymentdetails> getDet() {
//		return det;
//	}
//	public void setDet(List<Deploymentdetails> det) {
//		this.det = det;
//		
//	}
//	public List<Dep_um_food_details> getDem() {
//		return dem;
//	}
//	public void setDem(List<Dep_um_food_details> dem) {
//		this.dem = dem;
//		for(Dep_um_food_details depfood : dem) {
//			this.cp.setDepFoodDetails(depfood.getFoodCategory(),depfood.getRecOfficerName(),depfood.getRecOfficerUnit(),depfood.getRecOfficerRank());
//		}
//	}
//	public DeploymentList(List<Deploymentdetails> det, List<Dep_um_food_details> dem) {
//		super();
//		this.det = det;
//		this.dem = dem;
//	}
//	public DeploymentList() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//	public Crpf_processor getCp() {
//		return cp;
//	}
//	public void setCp(Crpf_processor cp) {
//		this.cp = cp;
//	}
//	
//	
//	
//	
//
//}
