package com.tempKafka.MultiThreadStructure;

public class SubDeploymentThread extends Thread {
	


}
