-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 3.7.32.64    Database: claros
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `deployment`
--

DROP TABLE IF EXISTS `deployment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deployment` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `dep_id` varchar(200) NOT NULL,
  `theatre` varchar(200) NOT NULL,
  `dte` varchar(200) NOT NULL,
  `zone` varchar(200) NOT NULL,
  `sector` varchar(200) NOT NULL,
  `range` varchar(200) NOT NULL,
  `unit` varchar(200) NOT NULL,
  `latitude` varchar(20) NOT NULL,
  `longitude` varchar(20) NOT NULL,
  `place` varchar(200) NOT NULL,
  `nature_of_duty` varchar(500) NOT NULL,
  `viewed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(200) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `updated_by` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deployment`
--

LOCK TABLES `deployment` WRITE;
/*!40000 ALTER TABLE `deployment` DISABLE KEYS */;
INSERT INTO `deployment` VALUES (1,'DEP#001','Theatre A','Dte-1B','ZONE X','Sector X-23','Range 7','Un-B','64.74736570822762','28.496088505253283','Delhi , District F','Nature D',0,'2024-07-03 11:35:12','','2024-07-03 11:31:34',''),(3,'DEP#003','Theatre B','Dte-3D','ZONE G','Sector G-6','Range 6','Un-H','60.75281736511067','91.58006443789236','Meghalya , District K','Nature H',1,'2007-06-07 00:00:00','','2024-07-03 11:31:34',''),(4,'DEP#004','Theatre A','Dte-4E','ZONE L','Sector L-37','Range 5','Un-H','67.66573551824851','-77.28931547821435','Gujarat , District I','Nature G',0,'2010-07-06 00:00:00','','2024-07-03 11:31:34',''),(5,'DEP#005','Theatre E','Dte-5F','ZONE X','Sector X-23','Range 7','Un-J','58.75317974831273','144.66317426847587','Karnatka , District B','Nature J',0,'2009-08-22 00:00:00','','2024-07-03 11:31:34',''),(7,'DEP#007','Theatre B','Dte-7H','ZONE O','Sector O-14','Range 6','Un-I','-55.10279302029199','-48.77006157186821','Uttar Pradesh , District G','Nature E',0,'2008-06-03 00:00:00','','2024-07-03 11:31:34',''),(9,'DEP#009','Theatre A','Dte-9J','ZONE Z','Sector Z-25','Range 1','Un-I','-37.042560546698574','0.512175690859749','Mahrashtra , District E','Nature H',1,'2007-03-27 00:00:00','','2024-07-03 11:31:34',''),(10,'DEP#0010','Theatre C','Dte-10K','ZONE B','Sector B-1','Range 1','Un-A','-52.86099920315761','-145.80101997200495','Delhi , District D','Nature G',0,'2024-07-03 11:35:12','','2024-07-03 11:31:34',''),(13,'DEP#0013','Theatre F','Dte-13N','ZONE Y','Sector Y-24','Range 0','Un-F','24.22649312226706','111.71405603337479','Gujarat , District A','Nature D',0,'2024-07-03 11:35:13','','2024-07-03 11:31:34',''),(18,'DEP#0018','Theatre C','Dte-18S','ZONE E','Sector E-4','Range 4','Un-C','79.68076390184532','24.218042906576784','Mahrashtra , District C','Unknown Nature',1,'2004-06-17 00:00:00','','2024-07-03 11:31:34',''),(22,'DEP#0022','Theatre F','Dte-22W','ZONE Q','Sector Q-16','Range 0','Un-G','50.476038456406485','125.34598270929047','Gujarat , District J','Nature G',0,'2002-11-30 00:00:00','','2024-07-03 11:31:34',''),(30,'DEP#0030','Theatre C','Dte-30E','ZONE N','Sector N-13','Range 5','Un-D','1.137737828435121','36.66586616697339','Meghalya , District L','Nature D',1,'2010-08-27 00:00:00','','2024-07-03 11:31:34',''),(41,'DEP#0041','Theatre F','Dte-41P','ZONE D','Sector D-3','Range 3','Un-D','-55.479640705026355','39.276244285773714','Karnatka , District M','Nature I',0,'2003-05-03 00:00:00','','2024-07-03 11:31:34',''),(44,'DEP#0044','Theatre A','Dte-44S','ZONE Q','Sector Q-16','Range 0','Un-E','-69.35051901205492','-75.82180080546235','Kerela , District H','Unknown Nature',0,'2009-07-08 00:00:00','','2024-07-03 11:31:34','');
/*!40000 ALTER TABLE `deployment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-10 15:27:22
