package com.tempKafka.dto;

public class RupaUserInfo {

}
