package com.tempKafka.MySqlRepo.EventsRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.Events.Events;

public interface EventsRepoJ  extends JpaRepository<Events,Integer> {

	List<Events> findFirst3ByOrderByCreatedAtDesc();

	List<Events> findFirst1000ByOrderByCreatedAtDesc();

	List<Events> findFirst100ByOrderByCreatedAtDesc();

	List<Events> findByEventid(String eventId);
	List<Events> findByEventidIn(List<String> eventid);

	List<Events> findFirst100ByOrderByInfotype();



}
