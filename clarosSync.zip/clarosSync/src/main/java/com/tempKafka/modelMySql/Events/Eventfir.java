package com.tempKafka.modelMySql.Events;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "eventfir")
public class Eventfir {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sno; // AI PK means Auto Increment Primary Key

    @Column(name = "event_id", length = 200)
    private String eventId;

    @Column(name = "fir_id", length = 200)
    private String firId;

    @Column(name = "remarks", length = 500)
    private String remarks;

    @Column(name = "createdby", length = 200)
    private String createdBy;

    @Column(name = "created_at")
    private Timestamp createdAt;

    @Column(name = "updatedby", length = 200)
    private String updatedBy;

    @Column(name = "updated_at")
    private String updatedAt;

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getFirId() {
		return firId;
	}

	public void setFirId(String firId) {
		this.firId = firId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	@Override
	public String toString() {
		return "Eventfir [sno=" + sno + ", eventId=" + eventId + ", firId=" + firId + ", remarks=" + remarks
				+ ", createdBy=" + createdBy + ", createdAt=" + createdAt + ", updatedBy=" + updatedBy + ", updatedAt="
				+ updatedAt + "]";
	}

	public Eventfir(int sno, String eventId, String firId, String remarks, String createdBy, Timestamp createdAt,
			String updatedBy, String updatedAt) {
		super();
		this.sno = sno;
		this.eventId = eventId;
		this.firId = firId;
		this.remarks = remarks;
		this.createdBy = createdBy;
		this.createdAt = createdAt;
		this.updatedBy = updatedBy;
		this.updatedAt = updatedAt;
	}

	public Eventfir() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}
