package com.tempKafka.ElasticModelRepository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.tempKafka.ElasticModel.CRPF_Deployment;

public interface CRPF_DeploymentRepository extends ElasticsearchRepository<CRPF_Deployment, String> {

}
