package com.tempKafka.modelMySql.deployment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import javax.persistence.Id;

@Entity
@Table(name = "crpf_location")
public class crpf_location {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	 private int crpf_id; // AI PK means Auto Increment Primary Key
	
	@Column(name = "event_id")
	    private String eventId;
	
	    private String location;
	    private float lat;
	    private float log; // Assuming this is longitude
	    private String company;
		public int getCrpf_id() {
			return crpf_id;
		}
		public void setCrpf_id(int crpf_id) {
			this.crpf_id = crpf_id;
		}
		public String getEventId() {
			return eventId;
		}
		public void setEventId(String eventId) {
			this.eventId = eventId;
		}
		public String getLocation() {
			return location;
		}
		public void setLocation(String location) {
			this.location = location;
		}
		public float getLat() {
			return lat;
		}
		public void setLat(float lat) {
			this.lat = lat;
		}
		public float getLog() {
			return log;
		}
		public void setLog(float log) {
			this.log = log;
		}
		public String getCompany() {
			return company;
		}
		public void setCompany(String company) {
			this.company = company;
		}
		public crpf_location(int crpf_id, String eventId, String location, float lat, float log, String company) {
			super();
			this.crpf_id = crpf_id;
			this.eventId = eventId;
			this.location = location;
			this.lat = lat;
			this.log = log;
			this.company = company;
		}
		@Override
		public String toString() {
			return "crpf_location [crpf_id=" + crpf_id + ", eventId=" + eventId + ", location=" + location + ", lat="
					+ lat + ", log=" + log + ", company=" + company + "]";
		}
		public crpf_location() {
			super();
			// TODO Auto-generated constructor stub
		}
	    
	    
}
