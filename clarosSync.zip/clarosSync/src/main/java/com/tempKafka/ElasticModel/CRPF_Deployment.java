package com.tempKafka.ElasticModel;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;
import org.springframework.data.elasticsearch.annotations.GeoPointField;

import com.tempKafka.MySqlRepo.deploymentRepository.Dep_um_food_details_Repo;
import com.tempKafka.dto.GeoPoint;
import com.tempKafka.modelMySql.deployment.Dep_um_food_details;
import com.tempKafka.modelMySql.deployment.Deploymentdetails;
import com.tempKafka.modelMySql.deployment.Event_arms_equipment;
import com.tempKafka.modelMySql.deployment.Personnel;
import com.tempKafka.modelMySql.deployment.eventUnitInvolved;

@Document(indexName = "crpf_deployment", createIndex = true)
public class CRPF_Deployment {

	@Id
	private String id;
	
	@GeoPointField
	private GeoPoint location;
	@SuppressWarnings("deprecation")
	@Field(type = FieldType.Date, format = DateFormat.custom, pattern = "uuuu-MM-dd'T'HH:mm:ss.SSS")
	private Date time;
	private String district;
	private String companyname;
	private String unit;
	private String unit_commander_name;
	private String unit_commander_rank;
	private String coy_commander;
	private String depStatus;
	private String coy;
	private String personnel_name;
	private String personnel_rank;
	private String event_equipment_category;
	private String event_equipment_type;
	private String food_category;
	private String rec_officer_name;
	private String rec_officer_rank;
	private String rec_officer_unit;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public GeoPoint getLocation() {
		return location;
	}
	public void setLocation(GeoPoint location) {
		this.location = location;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public String getUnit_commander_name() {
		return unit_commander_name;
	}
	public void setUnit_commander_name(String unit_commander_name) {
		this.unit_commander_name = unit_commander_name;
	}
	public String getUnit_commander_rank() {
		return unit_commander_rank;
	}
	public void setUnit_commander_rank(String unit_commander_rank) {
		this.unit_commander_rank = unit_commander_rank;
	}
	public String getCoy_commander() {
		return coy_commander;
	}
	public void setCoy_commander(String coy_commander) {
		this.coy_commander = coy_commander;
	}
	public String getPersonnel_name() {
		return personnel_name;
	}
	public void setPersonnel_name(String personnel_name) {
		this.personnel_name = personnel_name;
	}
	public String getPersonnel_rank() {
		return personnel_rank;
	}
	public void setPersonnel_rank(String personnel_rank) {
		this.personnel_rank = personnel_rank;
	}
	public String getEvent_equipment_category() {
		return event_equipment_category;
	}
	public void setEvent_equipment_category(String event_equipment_category) {
		this.event_equipment_category = event_equipment_category;
	}
	public String getEvent_equipment_type() {
		return event_equipment_type;
	}
	public void setEvent_equipment_type(String event_equipment_type) {
		this.event_equipment_type = event_equipment_type;
	}
	public String getFood_category() {
		return food_category;
	}
	public void setFood_category(String food_category) {
		this.food_category = food_category;
	}
	public String getRec_officer_name() {
		return rec_officer_name;
	}
	public void setRec_officer_name(String rec_officer_name) {
		this.rec_officer_name = rec_officer_name;
	}
	public String getRec_officer_rank() {
		return rec_officer_rank;
	}
	public void setRec_officer_rank(String rec_officer_rank) {
		this.rec_officer_rank = rec_officer_rank;
	}
	public String getRec_officer_unit() {
		return rec_officer_unit;
	}
	public void setRec_officer_unit(String rec_officer_unit) {
		this.rec_officer_unit = rec_officer_unit;
	}
	public String getDepStatus() {
		return depStatus;
	}
	public void setDepStatus(String depStatus) {
		this.depStatus = depStatus;
	}
	public String getCoy() {
		return coy;
	}
	public void setCoy(String coy) {
		this.coy = coy;
	}
		
}
