package com.tempKafka.Controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tempKafka.MySqlRepo.PersonJRepo;
import com.tempKafka.MySqlRepo.EventsRepository.EventVictimJRepo;
import com.tempKafka.MySqlRepo.EventsRepository.EventsRepoJ;
import com.tempKafka.Repo.AlertRepo;
import com.tempKafka.Repo.ClarosUsersRepo;
import com.tempKafka.Repo.CrimeRepo;
import com.tempKafka.Repo.Sentt;
import com.tempKafka.dto.InformationDTO;
import com.tempKafka.elastic.ElasticService;
import com.tempKafka.model.Alerts;
import com.tempKafka.model.ClarosUsers;
import com.tempKafka.model.Sntt;
import com.tempKafka.modelMySql.PersonJ;
import com.tempKafka.modelMySql.Events.Events;

@RestController
@RequestMapping("/clarosUsecases")
public class MySqlController2 {

	@Autowired
	EventsRepoJ eventsJRepo;
	@Autowired
	EventVictimJRepo eventVicRepo;
	@Autowired
	Sentt sntRepo;
	@Autowired
	CrimeRepo crimeRepo;
	@Autowired
	AlertRepo alertRepo;

	@Autowired
	PersonJRepo personJRepo;
	
	@Autowired
	private ClarosUsersRepo cUserRepo;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");

	@DeleteMapping("/clearDB")
	public ResponseEntity<?> clearEDB() {
		sntRepo.deleteAll();
		return null;
		
	}
	
	public int createSignal(Events a, String name, String userid, Date date) {
		try {
			Sntt signal = new Sntt(null, a.getDescription(), a.getEventtype(), null, a.getCreatedAt(), date.getTime());

			signal.setUserNames(Arrays.asList(name));
			signal.setUserids(Arrays.asList(userid));

			System.out.println("Signal: " + sntRepo.save(signal).getId());
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		return 1;

	}
	
	public int createAlert(Events a, String name, Date date, String userid) {
		try {
			System.out.println("Alert");
			Alerts b = new Alerts("High", "DB", a.getDescription(), date, a.getCreatedAt(), date.getTime(),
					new ArrayList<>());
			b.setUsernames(Arrays.asList(name));
			b.setUserid(Arrays.asList(userid));
			b.setFileobjects(new ArrayList<>());
			b.setType(a.getEventtype());
			b.setGis(a.getLatitude() + ":" + a.getLongitude());
			if (a.getInformationsource() != null && a.getInformationsource().length() > 0)
				b.setSourceofalert(a.getInformationsource());
			b.setPriority(a.getPriority());
			System.out.println(alertRepo.save(b).getId());
			System.out.println("Alert: " + alertRepo.save(b).getId());
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		}
		return 1;

	}
	
	public String getAlphaNumericString(int n) {

		// choose a Character random from this String
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789" + "abcdefghijklmnopqrstuvxyz";
		StringBuilder sb = new StringBuilder(n); // create StringBuffer size of AlphaNumericString

		for (int i = 0; i < n; i++) {
			 // generate a random number between
			int index = (int) (AlphaNumericString.length() * Math.random());	// 0 to AlphaNumericString variable length
			sb.append(AlphaNumericString.charAt(index));       // add Character one by one in end of sb
		}
		return sb.toString();
	}
	
	
	public String createUser(PersonJ a) {

		System.out.println("CreateUser");
		ClarosUsers cUser = new ClarosUsers(a.getName().replace(" ", "_"), a.getPid(), a.getAge());
		Optional<ClarosUsers> findByUserid = cUserRepo.findByUserid(a.getPid());
		if (findByUserid.isPresent()) {
			System.out.println("UserExist: " + a.getName() + ":" + a.getPid());
			return a.getPid();
		}

//		
		InformationDTO info = new InformationDTO(a.getName(), a.getGender(), a.getEyecolor(), a.getAddress(),
				"" + a.getAge(), "");
		cUser.setInformation(info);
		cUser.setDescription(cUser.getDescription() + ":" + "fatherName: " + a.getFatherName());
		String uId = cUserRepo.save(cUser).getUserid();
		System.out.println("cuserSave" + uId);
		return uId;

	}

	@Autowired
	ElasticService elasticService;

	public Date psDateS(String dateS) {
		Date date = new Date();
		try {
			if (dateS != null) {
				if (dateS.contains("T") && dateS.length() <= 19) {
					String[] split = dateS.split(":");
					if (split.length == 3)
						dateS = dateS + ".000000";
					else if (split.length == 2)
						dateS = dateS + ":00.000000";
					else if (split.length == 1)
						dateS = dateS + ":00:00:00.000000";
					date = sdf.parse(dateS);

				} else if (dateS.contains(" ")) {

					String[] split = dateS.split(":");
					if (split.length == 3)
						dateS = dateS + ".000000";
					else if (split.length == 2)
						dateS = dateS + ":00.000000";
					else if (split.length == 1)
						dateS = dateS + ":00:00:00.000000";
					date = sdf.parse(dateS.replace(" ", "T"));
				}

			}

		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return date;
	}

	@PostMapping("/syncUserRev")
	public ResponseEntity<?> syncUserRev() {
		int i = 0;
		try {
			List<PersonJ> findAllPerson = personJRepo.findAll();

			for (PersonJ personJ : findAllPerson) {

				String userid = createUser(personJ);
				i++;

			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return new ResponseEntity<>(i, HttpStatus.OK);
	}
	
	
	
}
