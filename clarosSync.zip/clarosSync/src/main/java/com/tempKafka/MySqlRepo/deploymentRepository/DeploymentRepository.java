package com.tempKafka.MySqlRepo.deploymentRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.deployment.Deployment;

public interface DeploymentRepository extends JpaRepository<Deployment, Integer> {
	
//	List<Deployment> findByUnit(String unit);
//	Deployment findByLatitude(String latitude);
	
	Optional<List<Deployment>> findByLatitude(String latitude);

}
