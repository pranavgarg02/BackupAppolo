package com.tempKafka.ElasticModel;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import com.tempKafka.modelMySql.Events.Eventied;

@Document(indexName = "iedblastsdetails", createIndex  = true)
public class IedBlasts_details {
	@Id
	private String id;
	private Eventied iedobject;
	private String eventType;
    private String eventSubType;
    private String eventRelatedTo;
    private String sisterAgency;
    private String organization;
    private String orgSubZone;
    
    
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Eventied getIedobject() {
		return iedobject;
	}
	public void setIedobject(Eventied iedobject) {
		this.iedobject = iedobject;
	}
	public String getEventSubType() {
		return eventSubType;
	}
	public void setEventSubType(String eventSubType) {
		this.eventSubType = eventSubType;
	}
	public String getEventRelatedTo() {
		return eventRelatedTo;
	}
	public void setEventRelatedTo(String eventRelatedTo) {
		this.eventRelatedTo = eventRelatedTo;
	}
	public String getSisterAgency() {
		return sisterAgency;
	}
	public void setSisterAgency(String sisterAgency) {
		this.sisterAgency = sisterAgency;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getOrgSubZone() {
		return orgSubZone;
	}
	public void setOrgSubZone(String orgSubZone) {
		this.orgSubZone = orgSubZone;
	}
	public IedBlasts_details(Eventied iedobject, String eventSubType, String eventRelatedTo, String sisterAgency,
			String organization, String orgSubZone) {
		super();
		this.iedobject = iedobject;
		this.eventSubType = eventSubType;
		this.eventRelatedTo = eventRelatedTo;
		this.sisterAgency = sisterAgency;
		this.organization = organization;
		this.orgSubZone = orgSubZone;
	}
	public IedBlasts_details() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}
