package com.tempKafka.modelMySql.Events;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "eventpropertydamaged")
public class Eventpropertydamage {
	
	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
	 	private int sno; // AI PK means Auto Increment Primary Key

	    @Column(name = "event_id", length = 50, nullable = false)
	    private String eventId;

	    @Column(name = "affected_type", length = 100, nullable = false)
	    private String affectedType;

	    @Column(name = "property_type", length = 200, nullable = false)
	    private String propertyType;

	    @Column(name = "description", length = 500, nullable = false)
	    private String description;

	    @Column(name = "approxvalue", length = 100, nullable = false)
	    private String approxValue;

	    @Column(name = "remarks", length = 500, nullable = false)
	    private String remarks;

	    @Column(name = "country", length = 200, nullable = false)
	    private String country;

	    @Column(name = "state", length = 200, nullable = false)
	    private String state;

	    @Column(name = "zipcode", length = 200, nullable = false)
	    private String zipcode;

	    @Column(name = "address1", length = 300, nullable = false)
	    private String address1;

	    @Column(name = "address2", length = 300, nullable = false)
	    private String address2;

	    @Column(name = "financial_assistance_value", length = 300, nullable = false)
	    private String financialAssistanceValue;

	    @Column(name = "financial_assistance", length = 3, nullable = false)
	    private String financialAssistance;

	    @Column(name = "vehicle_number", length = 200, nullable = false)
	    private String vehicleNumber;

	    @Column(name = "name_of_driver", length = 200, nullable = false)
	    private String nameOfDriver;

	    @Column(name = "force_no_of_driver", length = 200, nullable = false)
	    private String forceNoOfDriver;

	    @Column(name = "vehicle_type", length = 200, nullable = false)
	    private String vehicleType;

	    @Column(name = "vehicle_model", length = 200, nullable = false)
	    private String vehicleModel;

//	    @Column(name = "createdby", length = 200, nullable = false)
//	    private String createdBy;
//
//	    @Column(name = "created_at", nullable = false)
//	    private String createdAt;
//
//	    @Column(name = "updatedby", length = 200, nullable = false)
//	    private String updatedBy;
//
//	    @Column(name = "updated_at", nullable = false)
//	    private String updatedAt;

		public int getSno() {
			return sno;
		}

		public void setSno(int sno) {
			this.sno = sno;
		}

		public String getEventId() {
			return eventId;
		}

		public void setEventId(String eventId) {
			this.eventId = eventId;
		}

		public String getAffectedType() {
			return affectedType;
		}

		public void setAffectedType(String affectedType) {
			this.affectedType = affectedType;
		}

		public String getPropertyType() {
			return propertyType;
		}

		public void setPropertyType(String propertyType) {
			this.propertyType = propertyType;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getApproxValue() {
			return approxValue;
		}

		public void setApproxValue(String approxValue) {
			this.approxValue = approxValue;
		}

		public String getRemarks() {
			return remarks;
		}

		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}

		public String getCountry() {
			return country;
		}

		public void setCountry(String country) {
			this.country = country;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getZipcode() {
			return zipcode;
		}

		public void setZipcode(String zipcode) {
			this.zipcode = zipcode;
		}

		public String getAddress1() {
			return address1;
		}

		public void setAddress1(String address1) {
			this.address1 = address1;
		}

		public String getAddress2() {
			return address2;
		}

		public void setAddress2(String address2) {
			this.address2 = address2;
		}

		public String getFinancialAssistanceValue() {
			return financialAssistanceValue;
		}

		public void setFinancialAssistanceValue(String financialAssistanceValue) {
			this.financialAssistanceValue = financialAssistanceValue;
		}

		public String getFinancialAssistance() {
			return financialAssistance;
		}

		public void setFinancialAssistance(String financialAssistance) {
			this.financialAssistance = financialAssistance;
		}

		public String getVehicleNumber() {
			return vehicleNumber;
		}

		public void setVehicleNumber(String vehicleNumber) {
			this.vehicleNumber = vehicleNumber;
		}

		public String getNameOfDriver() {
			return nameOfDriver;
		}

		public void setNameOfDriver(String nameOfDriver) {
			this.nameOfDriver = nameOfDriver;
		}

		public String getForceNoOfDriver() {
			return forceNoOfDriver;
		}

		public void setForceNoOfDriver(String forceNoOfDriver) {
			this.forceNoOfDriver = forceNoOfDriver;
		}

		public String getVehicleType() {
			return vehicleType;
		}

		public void setVehicleType(String vehicleType) {
			this.vehicleType = vehicleType;
		}

		public String getVehicleModel() {
			return vehicleModel;
		}

		public void setVehicleModel(String vehicleModel) {
			this.vehicleModel = vehicleModel;
		}

//		public String getCreatedBy() {
//			return createdBy;
//		}
//
//		public void setCreatedBy(String createdBy) {
//			this.createdBy = createdBy;
//		}
//
//		public String getCreatedAt() {
//			return createdAt;
//		}
//
//		public void setCreatedAt(String createdAt) {
//			this.createdAt = createdAt;
//		}
//
//		public String getUpdatedBy() {
//			return updatedBy;
//		}
//
//		public void setUpdatedBy(String updatedBy) {
//			this.updatedBy = updatedBy;
//		}
//
//		public String getUpdatedAt() {
//			return updatedAt;
//		}
//
//		public void setUpdatedAt(String updatedAt) {
//			this.updatedAt = updatedAt;
//		}

		@Override
		public String toString() {
			return "Eventpropertydamage [sno=" + sno + ", eventId=" + eventId + ", affectedType=" + affectedType
					+ ", propertyType=" + propertyType + ", description=" + description + ", approxValue=" + approxValue
					+ ", remarks=" + remarks + ", country=" + country + ", state=" + state + ", zipcode=" + zipcode
					+ ", address1=" + address1 + ", address2=" + address2 + ", financialAssistanceValue="
					+ financialAssistanceValue + ", financialAssistance=" + financialAssistance + ", vehicleNumber="
					+ vehicleNumber + ", nameOfDriver=" + nameOfDriver + ", forceNoOfDriver=" + forceNoOfDriver
					+ ", vehicleType=" + vehicleType + ", vehicleModel=" + vehicleModel + "]" ;
//			
//			", createdBy=" + createdBy
//					+ ", createdAt=" + createdAt + ", updatedBy=" + updatedBy + ", updatedAt=" + updatedAt + "]";
		}

		public Eventpropertydamage() {
			super();
			// TODO Auto-generated constructor stub
		}


	
}
