package com.tempKafka.MySqlRepo.deploymentRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.deployment.Dep_um_food_details;
import java.util.List;



public interface Dep_um_food_details_Repo extends JpaRepository<Dep_um_food_details, Integer> {

	 List<Dep_um_food_details> findByDepIdIn(List<String> depId);
	 }
