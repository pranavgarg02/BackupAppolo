-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 3.7.32.64    Database: claros
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dep_deployed`
--

DROP TABLE IF EXISTS `dep_deployed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dep_deployed` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `dep_id` varchar(200) DEFAULT NULL,
  `row_order` tinyint(1) DEFAULT NULL,
  `ops_jurisdiction` varchar(200) DEFAULT NULL,
  `date_from` date DEFAULT NULL,
  `date_to` date DEFAULT NULL,
  `order_no` varchar(200) DEFAULT NULL,
  `order_date` varchar(200) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `place_location` varchar(200) DEFAULT NULL,
  `latitude` varchar(200) DEFAULT NULL,
  `longitude` varchar(200) DEFAULT NULL,
  `state` varchar(200) DEFAULT NULL,
  `district` varchar(200) DEFAULT NULL,
  `police_station` varchar(200) DEFAULT NULL,
  `res_state` varchar(200) DEFAULT NULL,
  `res_district` varchar(200) DEFAULT NULL,
  `date_time_from` datetime DEFAULT NULL,
  `date_time_to` datetime DEFAULT NULL,
  `nature_of_duty` varchar(500) DEFAULT NULL,
  `static_guard` varchar(200) DEFAULT NULL,
  `vip_security` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(200) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `updated_by` varchar(200) DEFAULT NULL,
  `sub_dep_id` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dep_deployed`
--

LOCK TABLES `dep_deployed` WRITE;
/*!40000 ALTER TABLE `dep_deployed` DISABLE KEYS */;
INSERT INTO `dep_deployed` VALUES (1,'DEP#001',1,'ops_jurisdictionH','2020-01-16','2021-06-12','Ord-ID 1','2022-05-20','Remarks-R12deAfSx','Delhi , District F','64.74736570822762','28.496088505253283','Delhi','District F','P.S#D-L 4','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature D','Static Guard -P','VIP Y','2005-01-03 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#001'),(3,'DEP#003',3,'ops_jurisdictionH','2020-04-14','2021-09-05','Ord-ID 3','2022-10-27','Remarks-R12deAfSx','Meghalya , District K','60.75281736511067','91.58006443789236','Meghalya','District F','P.S#D-H 1','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature H','Static Guard -C','VIP Y','2007-06-07 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#003'),(4,'DEP#004',4,'ops_jurisdictionH','2020-08-31','2021-09-19','Ord-ID 4','2022-11-15','Remarks-R12deAfSx','Gujarat , District I','67.66573551824851','-77.28931547821435','Gujarat','District D','P.S#D-D 7','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature G','Static Guard -G','VIP W','2010-07-06 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#004'),(5,'DEP#005',5,'ops_jurisdictionH','2020-02-08','2022-03-06','Ord-ID 5','2022-11-12','Remarks-R12deAfSx','Karnatka , District B','58.75317974831273','144.66317426847587','Karnatka','District E','P.S#D-E 13','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature J','Static Guard -V','VIP W','2009-08-22 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#005'),(7,'DEP#007',7,'ops_jurisdictionH','2020-08-25','2021-10-08','Ord-ID 7','2022-03-05','Remarks-R12deAfSx','Uttar Pradesh , District G','-55.10279302029199','-48.77006157186821','Uttar Pradesh','District L','P.S#D-D 8','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature E','Static Guard -P','VIP W','2008-06-03 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#007'),(9,'DEP#009',9,'ops_jurisdictionH','2020-07-26','2022-02-01','Ord-ID 9','2022-01-02','Remarks-R12deAfSx','Mahrashtra , District E','-37.042560546698574','0.512175690859749','Mahrashtra','District H','P.S#D-D 2','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature H','Static Guard -U','VIP Y','2007-03-27 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#009'),(10,'DEP#0010',10,'ops_jurisdictionH','2020-05-22','2021-06-09','Ord-ID 10','2022-04-20','Remarks-R12deAfSx','Delhi , District D','-52.86099920315761','-145.80101997200495','Delhi','District F','P.S#D-L 4','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature G','Static Guard -F','VIP U','2007-12-02 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#0010'),(13,'DEP#0013',13,'ops_jurisdictionH','2020-01-01','2022-02-27','Ord-ID 13','2022-01-27','Remarks-R12deAfSx','Gujarat , District A','24.22649312226706','111.71405603337479','Gujarat','District D','P.S#D-D 7','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature D','Static Guard -X','VIP V','2010-02-01 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#0013'),(18,'DEP#0018',18,'ops_jurisdictionH','2020-02-08','2021-07-16','Ord-ID 18','2022-09-02','Remarks-R12deAfSx','Mahrashtra , District C','79.68076390184532','24.218042906576784','Mahrashtra','District H','P.S#D-D 2','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Unknown Nature','Static Guard -T','VIP X','2004-06-17 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#0018'),(22,'DEP#0022',2,'ops_jurisdictionH','2020-11-24','2021-12-23','Ord-ID 22','2022-06-20','Remarks-R12deAfSx','Gujarat , District J','50.476038456406485','125.34598270929047','Gujarat','District D','P.S#D-D 7','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature G','Static Guard -L','VIP X','2002-11-30 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#0022'),(30,'DEP#0030',10,'ops_jurisdictionH','2020-06-16','2021-06-20','Ord-ID 30','2022-04-03','Remarks-R12deAfSx','Meghalya , District L','1.137737828435121','36.66586616697339','Meghalya','District F','P.S#D-H 1','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature D','Static Guard -X','VIP X','2010-08-27 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#0030'),(41,'DEP#0041',1,'ops_jurisdictionH','2020-11-10','2021-08-14','Ord-ID 41','2022-10-16','Remarks-R12deAfSx','Karnatka , District M','-55.479640705026355','39.276244285773714','Karnatka','District E','P.S#D-E 13','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Nature I','Static Guard -D','VIP V','2003-05-03 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#0041'),(44,'DEP#0044',4,'ops_jurisdictionH','2020-10-21','2022-05-05','Ord-ID 44','2022-07-26','Remarks-R12deAfSx','Kerela , District H','-69.35051901205492','-75.82180080546235','Kerela','District F','P.S#D-A 9','','','2024-07-03 11:31:37','2024-07-03 11:31:37','Unknown Nature','Static Guard -V','VIP W','2009-07-08 00:00:00','','2024-07-03 11:31:34','','SDEP-000DEP#0044');
/*!40000 ALTER TABLE `dep_deployed` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-10 15:27:28
