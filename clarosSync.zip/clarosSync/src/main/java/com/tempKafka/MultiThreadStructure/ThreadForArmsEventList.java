package com.tempKafka.MultiThreadStructure;

import java.util.List;

import com.tempKafka.modelMySql.deployment.Event_arms_equipment;

public class ThreadForArmsEventList extends Thread {
	
	
	private List<Event_arms_equipment> eventarmlist;
	
		
	public List<Event_arms_equipment> getListobject() {
		return eventarmlist;
	}

	public void setListobject(List<Event_arms_equipment> eventarmlist) {
		this.eventarmlist = eventarmlist;
	}

	public ThreadForArmsEventList(List<Event_arms_equipment> eventarmlist) {
		super();
		this.eventarmlist = eventarmlist;
	}

	@Override
	public void run() {
		try {
			System.out.println("Arms Event List" + Thread.currentThread().getId());
			System.out.println(Thread.currentThread().getName());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
