package com.tempKafka.MySqlRepo.EventsRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.Events.EventVictim;

public interface EventVictimJRepo extends JpaRepository<EventVictim,Integer> {

	Optional<EventVictim> findByEventid(String eventid);
	List<EventVictim> findFirst100ByName(String username);
	List<EventVictim> findFirstByName(String username);
	List<EventVictim> findByName(String username);
}
