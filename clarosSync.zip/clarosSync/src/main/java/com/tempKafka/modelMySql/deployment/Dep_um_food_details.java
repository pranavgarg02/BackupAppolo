package com.tempKafka.modelMySql.deployment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import javax.persistence.Id;
@Entity
@Table(name = "dep_um_food_details")
public class Dep_um_food_details {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sno;
	
	@Column(name = "dep_id")
	private String depId;
	
	@Column(name = "sub_dep_id")
	private String subDepId;
	@Column(name = "row_id")
	private String rowId;
	@Column(name = "proposed_food_halt_irctc")
	private String proposedFoodHaltIrctc;
	@Column(name = "food_category")
	private String foodCategory;
	
	@Column(name = "actual_halt_food_was_provided")
	private String actualHaltFoodWasProvided;
	
	@Column(name ="no_of_food_packets_demanded")
	private int noOfFoodPacketsDemanded;
	
	@Column(name = "rec_officer_force_no")
    private String recOfficerForceNo;
    
    @Column(name = "rec_officer_name")
    private String recOfficerName;
    
    @Column(name = "rec_officer_rank")
    private String recOfficerRank;
    
    @Column(name = "rec_officer_unit")
    private String recOfficerUnit;
    
    @Column(name = "rec_officer_phone")
    private String recOfficerPhone;
    
    @Column(name = "rec_officer_email")
    private String recOfficerEmail;
	
	String reports;
	String remark;
	public int getDeploymentfoodid() {
		return sno;
	}
	public void setDeploymentfoodid(int deploymentfoodid) {
		this.sno = deploymentfoodid;
	}
	public String getDepId() {
		return depId;
	}
	public void setDepId(String depId) {
		this.depId = depId;
	}
	public String getSubDepId() {
		return subDepId;
	}
	public void setSubDepId(String subDepId) {
		this.subDepId = subDepId;
	}
	public String getRowId() {
		return rowId;
	}
	public void setRowId(String rowId) {
		this.rowId = rowId;
	}
	public String getProposedFoodHaltIrctc() {
		return proposedFoodHaltIrctc;
	}
	public void setProposedFoodHaltIrctc(String proposedFoodHaltIrctc) {
		this.proposedFoodHaltIrctc = proposedFoodHaltIrctc;
	}
	public String getFoodCategory() {
		return foodCategory;
	}
	public void setFoodCategory(String foodCategory) {
		this.foodCategory = foodCategory;
	}
	public String getActualHaltFoodWasProvided() {
		return actualHaltFoodWasProvided;
	}
	public void setActualHaltFoodWasProvided(String actualHaltFoodWasProvided) {
		this.actualHaltFoodWasProvided = actualHaltFoodWasProvided;
	}
	public int getNoOfFoodPacketsDemanded() {
		return noOfFoodPacketsDemanded;
	}
	public void setNoOfFoodPacketsDemanded(int noOfFoodPacketsDemanded) {
		this.noOfFoodPacketsDemanded = noOfFoodPacketsDemanded;
	}
	public String getRecOfficerForceNo() {
		return recOfficerForceNo;
	}
	public void setRecOfficerForceNo(String recOfficerForceNo) {
		this.recOfficerForceNo = recOfficerForceNo;
	}
	public String getRecOfficerName() {
		return recOfficerName;
	}
	public void setRecOfficerName(String recOfficerName) {
		this.recOfficerName = recOfficerName;
	}
	public String getRecOfficerRank() {
		return recOfficerRank;
	}
	public void setRecOfficerRank(String recOfficerRank) {
		this.recOfficerRank = recOfficerRank;
	}
	public String getRecOfficerUnit() {
		return recOfficerUnit;
	}
	public void setRecOfficerUnit(String recOfficerUnit) {
		this.recOfficerUnit = recOfficerUnit;
	}
	public String getRecOfficerPhone() {
		return recOfficerPhone;
	}
	public void setRecOfficerPhone(String recOfficerPhone) {
		this.recOfficerPhone = recOfficerPhone;
	}
	public String getRecOfficerEmail() {
		return recOfficerEmail;
	}
	public void setRecOfficerEmail(String recOfficerEmail) {
		this.recOfficerEmail = recOfficerEmail;
	}
	public String getReports() {
		return reports;
	}
	public void setReports(String reports) {
		this.reports = reports;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Dep_um_food_details(String depId, String subDepId, String rowId,
			String proposedFoodHaltIrctc, String foodCategory, String actualHaltFoodWasProvided,
			int noOfFoodPacketsDemanded, String recOfficerForceNo, String recOfficerName, String recOfficerRank,
			String recOfficerUnit, String recOfficerPhone, String recOfficerEmail, String reports, String remark) {
		super();
//		this.deploymentfoodid = sno;
		this.depId = depId;
		this.subDepId = subDepId;
		this.rowId = rowId;
		this.proposedFoodHaltIrctc = proposedFoodHaltIrctc;
		this.foodCategory = foodCategory;
		this.actualHaltFoodWasProvided = actualHaltFoodWasProvided;
		this.noOfFoodPacketsDemanded = noOfFoodPacketsDemanded;
		this.recOfficerForceNo = recOfficerForceNo;
		this.recOfficerName = recOfficerName;
		this.recOfficerRank = recOfficerRank;
		this.recOfficerUnit = recOfficerUnit;
		this.recOfficerPhone = recOfficerPhone;
		this.recOfficerEmail = recOfficerEmail;
		this.reports = reports;
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "Dep_um_food_details [sno=" + sno + ", depId=" + depId + ", subDepId="
				+ subDepId + ", rowId=" + rowId + ", proposedFoodHaltIrctc=" + proposedFoodHaltIrctc + ", foodCategory="
				+ foodCategory + ", actualHaltFoodWasProvided=" + actualHaltFoodWasProvided
				+ ", noOfFoodPacketsDemanded=" + noOfFoodPacketsDemanded + ", recOfficerForceNo=" + recOfficerForceNo
				+ ", recOfficerName=" + recOfficerName + ", recOfficerRank=" + recOfficerRank + ", recOfficerUnit="
				+ recOfficerUnit + ", recOfficerPhone=" + recOfficerPhone + ", recOfficerEmail=" + recOfficerEmail
				+ ", reports=" + reports + ", remark=" + remark + "]";
	}
	public Dep_um_food_details() {
		super();
		// TODO Auto-generated constructor stub
	}
		

}
