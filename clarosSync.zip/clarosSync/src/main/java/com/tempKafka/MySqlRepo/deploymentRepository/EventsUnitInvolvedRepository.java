package com.tempKafka.MySqlRepo.deploymentRepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.google.common.base.Optional;
import com.tempKafka.modelMySql.deployment.eventUnitInvolved;
import java.util.List;



public interface EventsUnitInvolvedRepository extends JpaRepository<eventUnitInvolved, Integer>{
//		public Optional<eventUnitInvolved>  findByEventId(String eventId);
		
		List<eventUnitInvolved> findByEventId(String eventId);
	
}
