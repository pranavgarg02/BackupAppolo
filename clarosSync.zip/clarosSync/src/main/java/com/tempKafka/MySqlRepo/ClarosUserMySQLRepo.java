package com.tempKafka.MySqlRepo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tempKafka.modelMySql.ClarosUsersJ;

public interface ClarosUserMySQLRepo extends JpaRepository<ClarosUsersJ,Long> {

}
