-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 3.7.32.64    Database: claros
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dep_details`
--

DROP TABLE IF EXISTS `dep_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dep_details` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `dep_id` varchar(200) DEFAULT NULL,
  `row_order` tinyint(1) DEFAULT NULL,
  `coy` varchar(200) DEFAULT NULL,
  `coy_commander` varchar(200) DEFAULT NULL,
  `nature_of_duty` varchar(200) DEFAULT NULL,
  `coy_commander_mob` varchar(20) DEFAULT NULL,
  `platoon` varchar(200) DEFAULT NULL,
  `section` varchar(200) DEFAULT NULL,
  `halfsection` varchar(200) DEFAULT NULL,
  `is_halfsection` varchar(200) DEFAULT NULL,
  `place_location` varchar(200) DEFAULT NULL,
  `latitude` varchar(200) DEFAULT NULL,
  `longitude` varchar(200) DEFAULT NULL,
  `state` varchar(200) DEFAULT NULL,
  `district` varchar(200) DEFAULT NULL,
  `police_station` varchar(200) DEFAULT NULL,
  `available_strength` varchar(500) DEFAULT NULL,
  `available_go` varchar(500) DEFAULT NULL,
  `available_so` varchar(500) DEFAULT NULL,
  `available_or` varchar(500) DEFAULT NULL,
  `dep_status` varchar(200) DEFAULT NULL,
  `dep_sub_status` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(200) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `updated_by` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dep_details`
--

LOCK TABLES `dep_details` WRITE;
/*!40000 ALTER TABLE `dep_details` DISABLE KEYS */;
INSERT INTO `dep_details` VALUES (1,'DEP#001',1,'Nirankar Coy','Luxedo ferrosko','Nature D','5904533948','pl-xAefd D','Sec-331 C','Half-sec A','No','Delhi , District F','64.74736570822762','28.496088505253283','Delhi','District F','P.S#D-L 4','100%','(100-x) %','((100-x)-y) %','Remaining z%','Pending','From 99.5% to 91.5%','2005-01-03 00:00:00','','2024-07-03 11:31:34',''),(3,'DEP#003',3,'Extorio Coy','Bishtori Lubia','Nature H','1108793678','pl-xAefd E','Sec-355 D','Half-sec C','No','Meghalya , District K','60.75281736511067','91.58006443789236','Meghalya','District F','P.S#D-H 1','100%','(100-x) %','((100-x)-y) %','Remaining z%','In Deployement','From 88.5% to 87.5%','2007-06-07 00:00:00','','2024-07-03 11:31:34',''),(4,'DEP#004',4,'Frixido Coy','Mannhaur Nirankar','Nature G','3927416295','pl-xAefd C','Sec-325 D','Half-sec A','No','Gujarat , District I','67.66573551824851','-77.28931547821435','Gujarat','District D','P.S#D-D 7','100%','(100-x) %','((100-x)-y) %','Remaining z%','Not Ready For Deployment','From 99.5% to 86.5%','2010-07-06 00:00:00','','2024-07-03 11:31:34',''),(5,'DEP#005',5,'Nirankar Coy','Minsube Lubia','Nature J','7994797959','pl-xAefd A','Sec-369 A','Half-sec B','No','Karnatka , District B','58.75317974831273','144.66317426847587','Karnatka','District E','P.S#D-E 13','100%','(100-x) %','((100-x)-y) %','Remaining z%','In Deployement','From 91.5% to 93.5%','2009-08-22 00:00:00','','2024-07-03 11:31:34',''),(7,'DEP#007',7,'Nirankar Coy','Rishkula ferrosko','Nature E','5883005349','pl-xAefd C','Sec-329 D','Half-sec D','Yes','Uttar Pradesh , District G','-55.10279302029199','-48.77006157186821','Uttar Pradesh','District L','P.S#D-D 8','100%','(100-x) %','((100-x)-y) %','Remaining z%','Deployed','From 86.5% to 86.5%','2008-06-03 00:00:00','','2024-07-03 11:31:34',''),(9,'DEP#009',9,'Alex Coy','Luxedo Lubia','Nature H','9142249776','pl-xAefd E','Sec-338 A','Half-sec B','No','Mahrashtra , District E','-37.042560546698574','0.512175690859749','Mahrashtra','District H','P.S#D-D 2','100%','(100-x) %','((100-x)-y) %','Remaining z%','Deployed','From 101.5% to 86.5%','2007-03-27 00:00:00','','2024-07-03 11:31:34',''),(10,'DEP#0010',10,'Nirankar Coy','Minsube Extorio','Nature G','8658184975','pl-xAefd D','Sec-374 C','Half-sec F','No','Delhi , District D','-52.86099920315761','-145.80101997200495','Delhi','District F','P.S#D-L 4','100%','(100-x) %','((100-x)-y) %','Remaining z%','Pending','From 103.5% to 90.5%','2007-12-02 00:00:00','','2024-07-03 11:31:34',''),(13,'DEP#0013',13,'Extorio Coy','Luxedo Extorio','Nature D','6593787134','pl-xAefd F','Sec-335 D','Half-sec F','No','Gujarat , District A','24.22649312226706','111.71405603337479','Gujarat','District D','P.S#D-D 7','100%','(100-x) %','((100-x)-y) %','Remaining z%','Completed & Ready for Deployment','From 94.5% to 88.5%','2010-02-01 00:00:00','','2024-07-03 11:31:34',''),(18,'DEP#0018',18,'Lubia Coy','Minsube Extorio','Unknown Nature','9772811739','pl-xAefd C','Sec-378 D','Half-sec C','Yes','Mahrashtra , District C','79.68076390184532','24.218042906576784','Mahrashtra','District H','P.S#D-D 2','100%','(100-x) %','((100-x)-y) %','Remaining z%','Completed & Ready for Deployment','From 96.5% to 91.5%','2004-06-17 00:00:00','','2024-07-03 11:31:34',''),(22,'DEP#0022',2,'Extorio Coy','Minsube Nirankar','Nature G','1333433138','pl-xAefd B','Sec-317 C','Half-sec D','No','Gujarat , District J','50.476038456406485','125.34598270929047','Gujarat','District D','P.S#D-D 7','100%','(100-x) %','((100-x)-y) %','Remaining z%','In Deployement','From 96.5% to 93.5%','2002-11-30 00:00:00','','2024-07-03 11:31:34',''),(30,'DEP#0030',10,'Nirankar Coy','Luxedo Extorio','Nature D','6691966755','pl-xAefd D','Sec-345 A','Half-sec C','Yes','Meghalya , District L','1.137737828435121','36.66586616697339','Meghalya','District F','P.S#D-H 1','100%','(100-x) %','((100-x)-y) %','Remaining z%','Deployed','From 98.5% to 85.5%','2010-08-27 00:00:00','','2024-07-03 11:31:34',''),(41,'DEP#0041',1,'Frixido Coy','Luxedo Alex','Nature I','3329298489','pl-xAefd D','Sec-348 E','Half-sec A','No','Karnatka , District M','-55.479640705026355','39.276244285773714','Karnatka','District E','P.S#D-E 13','100%','(100-x) %','((100-x)-y) %','Remaining z%','In Deployement','From 88.5% to 88.5%','2003-05-03 00:00:00','','2024-07-03 11:31:34',''),(44,'DEP#0044',4,'Frixido Coy','Minsube Alex','Unknown Nature','3132612649','pl-xAefd B','Sec-334 F','Half-sec C','No','Kerela , District H','-69.35051901205492','-75.82180080546235','Kerela','District F','P.S#D-A 9','100%','(100-x) %','((100-x)-y) %','Remaining z%','In Deployement','From 85.5% to 92.5%','2009-07-08 00:00:00','','2024-07-03 11:31:34','');
/*!40000 ALTER TABLE `dep_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-10 15:25:10
