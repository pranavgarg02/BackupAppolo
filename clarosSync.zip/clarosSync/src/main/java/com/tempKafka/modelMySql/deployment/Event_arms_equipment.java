package com.tempKafka.modelMySql.deployment;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import javax.persistence.Id;

@Entity
@Table(name = "event_arms_eqpt")
public class Event_arms_equipment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sno")
    private int sno; // AI PK means Auto Increment Primary Key

    @Column(name = "event_id")
    private String eventId;

    @Column(name = "arms_eqpt_id")
    private String armsEqptId;

    @Column(name = "remarks")
    private String remarks;

    @Column(name = "createdby")
    private String createdBy;

    @Column(name = "created_at")
    private String createdAt;

    @Column(name = "updatedby")
    private String updatedBy;

    @Column(name = "updated_at")
    private String updatedAt;

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		this.eventId = eventId;
	}

	public String getArmsEqptId() {
		return armsEqptId;
	}

	public void setArmsEqptId(String armsEqptId) {
		this.armsEqptId = armsEqptId;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public String getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}

	@Override
	public String toString() {
		return "Event_arms_equipment [sno=" + sno + ", eventId=" + eventId + ", armsEqptId=" + armsEqptId
				+ ", remarks=" + remarks + ", createdBy=" + createdBy + ", createdAt=" + createdAt + ", updatedBy="
				+ updatedBy + ", updatedAt=" + updatedAt + "]";
	}

	public Event_arms_equipment() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    

}
